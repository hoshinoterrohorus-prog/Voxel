# Hoshi no Sato (Godot 4.4, GL Compatibility)
Dunia terbuka anime: kota + desa + sungai + gunung, siang/malam, NPC, kristal, teleport.
Kontrol sentuh: joystick kiri, geser kanan = kamera, LOMPAT (tekan 2x lalu tahan = glide), DASH, LARI, PETA (teleport/grafik).
Credit: sample VRM (pixiv, three-vrm MIT), SFX Kenney (CC0), musik latar sintetis buatan sendiri.

class_name Avatar
extends Node3D
## Karakter VRM: material toon anime + outline + animasi tulang prosedural.

static var shader_char: Shader
static var shader_line: Shader
var skel: Skeleton3D
var model: Node3D
var b := {}            # nama pendek -> index tulang
var init_pose := {}
var grest := {}        # index -> Quaternion global rest
var phase := 0.0
var pitch_target := 0.0
var pitch_cur := 0.0
var mats: Array = []
var hue := 0.0

const NAMES := {
	"hips": "J_Bip_C_Hips", "spine": "J_Bip_C_Spine", "chest": "J_Bip_C_Chest", "neck": "J_Bip_C_Neck", "head": "J_Bip_C_Head",
	"lua": "J_Bip_L_UpperArm", "lla": "J_Bip_L_LowerArm", "rua": "J_Bip_R_UpperArm", "rla": "J_Bip_R_LowerArm",
	"lul": "J_Bip_L_UpperLeg", "lll": "J_Bip_L_LowerLeg", "rul": "J_Bip_R_UpperLeg", "rll": "J_Bip_R_LowerLeg",
	"lta": "J_Aim_L_TopsUpperArm", "rta": "J_Aim_R_TopsUpperArm", "lal": "J_Aim_L_UpperLeg", "ral": "J_Aim_R_UpperLeg",
	"lfoot": "J_Bip_L_Foot", "rfoot": "J_Bip_R_Foot", "lsh": "J_Bip_L_Shoulder", "rsh": "J_Bip_R_Shoulder",
}

func setup(hue_shift := 0.0, sat := 1.0, val := 1.0, outline := true) -> void:
	if shader_char == null:
		shader_char = load("res://shaders/char_toon.gdshader"); shader_line = load("res://shaders/outline.gdshader")
	hue = hue_shift
	model = (load("res://assets/char/hoshi.glb") as PackedScene).instantiate()
	add_child(model)
	skel = model.find_children("*", "Skeleton3D", true, false)[0]
	for k in NAMES:
		var i := skel.find_bone(NAMES[k])
		if i < 0: push_warning("bone hilang: " + NAMES[k])
		b[k] = i
	skel.reset_bone_poses() if false else null
	skel.force_update_all_bone_transforms()
	for i in skel.get_bone_count():
		grest[i] = skel.get_bone_global_pose(i).basis.get_rotation_quaternion()
		init_pose[i] = skel.get_bone_pose_rotation(i)
	var line := ShaderMaterial.new(); line.shader = shader_line
	for mi in model.find_children("*", "MeshInstance3D", true, false):
		var m: MeshInstance3D = mi
		m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		for s in m.mesh.get_surface_count():
			var old := m.mesh.surface_get_material(s) as BaseMaterial3D
			var nm := ShaderMaterial.new(); nm.shader = shader_char
			var nme := old.resource_name if old else ""
			if old and old.albedo_texture: nm.set_shader_parameter("albedo_tex", old.albedo_texture)
			if old: nm.set_shader_parameter("base_col", old.albedo_color)
			var cut: bool = nme.contains("HAIR") or nme.contains("FACE") or nme.contains("EYE") or nme.contains("Hair")
			nm.set_shader_parameter("use_scissor", 1.0 if cut else 0.0)
			nm.set_shader_parameter("hue_shift", hue_shift); nm.set_shader_parameter("sat_mul", sat); nm.set_shader_parameter("val_mul", val)
			if outline and not (nme.contains("EYE") or nme.contains("FACE")):
				nm.next_pass = line
			m.set_surface_override_material(s, nm); mats.append(nm)

func set_night(n: float) -> void:
	for m in mats: m.set_shader_parameter("night", n)

## Putar tulang dengan sumbu global (model-space) relatif pose diam.
func rot(key: String, rg: Quaternion) -> void:
	var i: int = b[key]
	if i < 0: return
	var g: Quaternion = grest[i]
	skel.set_bone_pose_rotation(i, (init_pose[i] as Quaternion) * (g.inverse() * rg * g))

static func qx(a: float) -> Quaternion: return Quaternion(Vector3.RIGHT, a)
static func qy(a: float) -> Quaternion: return Quaternion(Vector3.UP, a)
static func qz(a: float) -> Quaternion: return Quaternion(Vector3.BACK, a)

## state: 0 diam, 1 jalan/lari, 2 lompat/udara, 3 meluncur(glide), 4 dash
func animate(dt: float, state: int, speed: float, vy: float) -> void:
	var t := Time.get_ticks_msec() * 0.001
	var run := clampf((speed - 4.0) / 6.0, 0.0, 1.0)
	var mv := clampf(speed / 3.0, 0.0, 1.0)
	phase += dt * (6.5 + speed * 0.85) * (1.0 if state == 1 else 0.0)
	var breath := sin(t * 1.7) * 0.015
	var lower := 1.28      # lengan turun dari T-pose
	var la := lower; var ra := lower
	var swing := 0.0; var lleg := 0.0; var rleg := 0.0; var lk := 0.0; var rk := 0.0
	var elb := 0.12; var lean := 0.0; var gl_pitch := 0.0
	var sp := sin(phase); var cp := sin(phase + PI)
	match state:
		0:
			lean = breath * 2.0; elb = 0.10 + breath * 3.0
		1:
			var amp := lerpf(0.45, 0.95, run)
			lleg = -sp * amp; rleg = -cp * amp
			lk = maxf(0.0, sin(phase + 0.9)) * amp * 1.3; rk = maxf(0.0, sin(phase + PI + 0.9)) * amp * 1.3
			swing = lerpf(0.5, 0.9, run)
			elb = lerpf(0.25, 1.0, run); lean = lerpf(0.03, 0.22, run)
			lean += absf(sin(phase)) * 0.02
		2:
			var up := clampf(vy / 10.0, -1.0, 1.0)
			lleg = -0.55 - up * 0.2; rleg = 0.25; lk = 0.9; rk = 0.5
			la = lower - 0.9; ra = lower - 0.9; elb = 0.5; lean = 0.08
		3:
			la = 0.15; ra = 0.15; elb = 0.05; gl_pitch = 0.9
			lleg = 0.1; rleg = 0.1; lk = 0.15; rk = 0.15
		4:
			lleg = -0.3; rleg = 0.55; lk = 0.3; rk = 0.8; la = lower + 0.2; ra = lower + 0.2; lean = 0.45; elb = 0.8
	pitch_target = gl_pitch
	pitch_cur = lerpf(pitch_cur, pitch_target, 1.0 - exp(-dt * 8.0))
	model.rotation.x = pitch_cur
	var sw := swing * sp
	rot("hips", qx(lean * 0.4))
	rot("spine", qx(lean * 0.6 + breath))
	rot("chest", qx(lean * 0.5 + breath) * qy(sp * 0.08 * mv))
	rot("head", qx(-lean * 0.9) * qy(-sp * 0.05 * mv))
	# lengan (kiri = +X, kanan = -X); ayun berlawanan dengan kaki
	var qla := qx(sw * 0.9) * qz(-la); var qra := qx(-sw * 0.9) * qz(ra)
	rot("lua", qla); rot("rua", qra); rot("lta", qla); rot("rta", qra)
	rot("lla", qx(-elb - maxf(0.0, sw) * 0.4))
	rot("rla", qx(-elb - maxf(0.0, -sw) * 0.4))
	rot("lul", qx(lleg)); rot("rul", qx(rleg)); rot("lal", qx(lleg)); rot("ral", qx(rleg))
	rot("lll", qx(lk)); rot("rll", qx(rk))
	rot("lfoot", qx(-lk * 0.3 - lleg * 0.15)); rot("rfoot", qx(-rk * 0.3 - rleg * 0.15))

func set_hue(h: float, sat := 1.0, val := 1.0) -> void:
	for m in mats:
		m.set_shader_parameter("hue_shift", h); m.set_shader_parameter("sat_mul", sat); m.set_shader_parameter("val_mul", val)

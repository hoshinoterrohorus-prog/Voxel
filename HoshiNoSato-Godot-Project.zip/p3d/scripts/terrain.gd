class_name Terrain
extends Node3D
## Terrain berbasis peta tinggi di GPU: satu grid mesh dipakai ulang oleh 256 chunk (2 LOD).

const CHUNK := 80.0
var mat: ShaderMaterial
var water: MeshInstance3D
var water_mat: ShaderMaterial
var grass_mat: ShaderMaterial
var grass: MultiMeshInstance3D

static func make_grid(n: int, size: float) -> ArrayMesh:
	# n x n sel + rok di tepi (UV.x = 1 pada vertex rok)
	var verts := PackedVector3Array(); var uvs := PackedVector2Array(); var idx := PackedInt32Array()
	var step := size / n
	var w := n + 1
	for j in w:
		for i in w:
			verts.append(Vector3(i * step, 0, j * step)); uvs.append(Vector2(0, 0))
	for j in n:
		for i in n:
			var a := j * w + i
			idx.append_array([a, a + 1, a + w, a + 1, a + w + 1, a + w])
	# rok
	var edges: Array = []
	for i in n: edges.append([Vector2i(i, 0), Vector2i(i + 1, 0)])
	for i in n: edges.append([Vector2i(i, n), Vector2i(i + 1, n)])
	for j in n: edges.append([Vector2i(0, j), Vector2i(0, j + 1)])
	for j in n: edges.append([Vector2i(n, j), Vector2i(n, j + 1)])
	for e in edges:
		var p0: Vector2i = e[0]; var p1: Vector2i = e[1]
		var base := verts.size()
		verts.append(Vector3(p0.x * step, 0, p0.y * step)); uvs.append(Vector2(1, 0))
		verts.append(Vector3(p1.x * step, 0, p1.y * step)); uvs.append(Vector2(1, 0))
		var a0 := p0.y * w + p0.x; var a1 := p1.y * w + p1.x
		idx.append_array([a0, a1, base, a1, base + 1, base, a1, a0, base, base + 1, a1, base])
	var arr := []; arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts; arr[Mesh.ARRAY_TEX_UV] = uvs; arr[Mesh.ARRAY_INDEX] = idx
	var normals := PackedVector3Array(); normals.resize(verts.size()); normals.fill(Vector3.UP)
	arr[Mesh.ARRAY_NORMAL] = normals
	var m := ArrayMesh.new(); m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	return m

func build() -> void:
	mat = ShaderMaterial.new(); mat.shader = load("res://shaders/terrain.gdshader")
	mat.set_shader_parameter("heightmap", WD.tex_h)
	mat.set_shader_parameter("splat", WD.tex_s)
	mat.set_shader_parameter("half_size", WD.HALF); mat.set_shader_parameter("tex_n", float(WD.N))
	mat.set_shader_parameter("hmin", WD.HMIN); mat.set_shader_parameter("hmax", WD.HMAX)
	var cc: Array = WD.data["city"]["c"]
	mat.set_shader_parameter("city_c", Vector2(cc[0], cc[1]))
	mat.set_shader_parameter("city_cell", float(WD.data["city"]["cell"]))
	mat.set_shader_parameter("city_road", float(WD.data["city"]["road_w"]))
	var near := make_grid(32, CHUNK); var far := make_grid(8, CHUNK)
	var aabb := AABB(Vector3(0, WD.HMIN - 8.0, 0), Vector3(CHUNK, WD.HMAX - WD.HMIN + 16.0, CHUNK))
	var cnt := int(2.0 * WD.HALF / CHUNK)
	for cz in cnt:
		for cx in cnt:
			var pos := Vector3(-WD.HALF + cx * CHUNK, 0, -WD.HALF + cz * CHUNK)
			var a := MeshInstance3D.new(); a.mesh = near; a.material_override = mat; a.position = pos; a.custom_aabb = aabb
			a.visibility_range_end = 240.0; a.gi_mode = GeometryInstance3D.GI_MODE_DISABLED
			add_child(a)
			var b := MeshInstance3D.new(); b.mesh = far; b.material_override = mat; b.position = pos; b.custom_aabb = aabb
			b.visibility_range_begin = 240.0; b.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(b)
	# air: satu bidang besar
	var pm := PlaneMesh.new(); pm.size = Vector2(2.0 * WD.HALF + 2000.0, 2.0 * WD.HALF + 2000.0); pm.subdivide_width = 1; pm.subdivide_depth = 1
	water_mat = ShaderMaterial.new(); water_mat.shader = load("res://shaders/water.gdshader")
	water = MeshInstance3D.new(); water.mesh = pm; water.material_override = water_mat
	water.position.y = WD.WATER_Y; water.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(water)
	_build_grass()

func _build_grass() -> void:
	# bilah rumput: 3 segmen
	var vs := PackedVector3Array(); var ids := PackedInt32Array()
	var ts := [0.0, 0.34, 0.68, 1.0]
	for t in ts:
		var wv: float = 1.0 - t * 0.85
		vs.append(Vector3(-wv, t, 0)); vs.append(Vector3(wv, t, 0))
	for s in 3:
		var a := s * 2
		ids.append_array([a, a + 1, a + 2, a + 1, a + 3, a + 2])
	var nm := PackedVector3Array(); nm.resize(vs.size()); nm.fill(Vector3.UP)
	var arr := []; arr.resize(Mesh.ARRAY_MAX); arr[Mesh.ARRAY_VERTEX] = vs; arr[Mesh.ARRAY_INDEX] = ids; arr[Mesh.ARRAY_NORMAL] = nm
	var bm := ArrayMesh.new(); bm.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	grass_mat = ShaderMaterial.new(); grass_mat.shader = load("res://shaders/grass.gdshader")
	for k in ["heightmap", "splat"]: grass_mat.set_shader_parameter(k, WD.tex_h if k == "heightmap" else WD.tex_s)
	grass_mat.set_shader_parameter("half_size", WD.HALF); grass_mat.set_shader_parameter("tex_n", float(WD.N))
	grass_mat.set_shader_parameter("hmin", WD.HMIN); grass_mat.set_shader_parameter("hmax", WD.HMAX)
	bm.surface_set_material(0, grass_mat)
	var mm := MultiMesh.new(); mm.transform_format = MultiMesh.TRANSFORM_3D
	var n := 150
	mm.instance_count = n * n; mm.mesh = bm
	var buf := PackedFloat32Array(); buf.resize(n * n * 12)
	for i in n * n:
		var o := i * 12
		buf[o] = 1.0; buf[o + 5] = 1.0; buf[o + 10] = 1.0
	mm.buffer = buf
	grass = MultiMeshInstance3D.new(); grass.multimesh = mm
	grass.custom_aabb = AABB(Vector3(-100, -50, -100), Vector3(200, 300, 200))
	grass.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(grass)

func update_focus(cam_pos: Vector3, player_pos: Vector3) -> void:
	grass_mat.set_shader_parameter("cam_pos", cam_pos)
	grass_mat.set_shader_parameter("player_pos", player_pos)
	grass.global_position = Vector3(cam_pos.x, 0, cam_pos.z)  # supaya AABB mengikuti kamera

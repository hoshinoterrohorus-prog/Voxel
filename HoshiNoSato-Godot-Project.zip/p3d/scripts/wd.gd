class_name WD
extends RefCounted
## Data dunia: peta tinggi, splat, json penempatan. Semua query tinggi lewat sini.

static var img_h: Image
static var img_s: Image
static var tex_h: ImageTexture
static var tex_s: ImageTexture
static var data: Dictionary
static var N := 1024
static var HALF := 640.0
static var HMIN := -8.0
static var HMAX := 160.0
static var WATER_Y := -0.6

static func load_all() -> void:
	data = load("res://assets/world/world.json").data
	N = int(data["n"]); HALF = float(data["half"]); HMIN = float(data["hmin"]); HMAX = float(data["hmax"])
	WATER_Y = float(data["water_y"])
	img_h = (load("res://assets/world/height.png") as Texture2D).get_image()
	img_s = (load("res://assets/world/splat.png") as Texture2D).get_image()
	if img_h.is_compressed(): img_h.decompress()
	if img_s.is_compressed(): img_s.decompress()
	img_h.convert(Image.FORMAT_RGB8); img_s.convert(Image.FORMAT_RGBA8)
	tex_h = ImageTexture.create_from_image(img_h)
	tex_s = ImageTexture.create_from_image(img_s)

static func _h_at(i: int, j: int) -> float:
	i = clampi(i, 0, N - 1); j = clampi(j, 0, N - 1)
	var c := img_h.get_pixel(i, j)
	return lerpf(HMIN, HMAX, (roundf(c.r * 255.0) * 256.0 + roundf(c.g * 255.0)) / 65535.0)

static func height(x: float, z: float) -> float:
	var tx := (x + HALF) / (2.0 * HALF) * N - 0.5
	var tz := (z + HALF) / (2.0 * HALF) * N - 0.5
	var i := int(floor(tx)); var j := int(floor(tz))
	var fx := tx - i; var fz := tz - j
	return lerpf(lerpf(_h_at(i, j), _h_at(i + 1, j), fx), lerpf(_h_at(i, j + 1), _h_at(i + 1, j + 1), fx), fz)

static func splat(x: float, z: float) -> Color:
	var i := clampi(int((x + HALF) / (2.0 * HALF) * N), 0, N - 1)
	var j := clampi(int((z + HALF) / (2.0 * HALF) * N), 0, N - 1)
	return img_s.get_pixel(i, j)

static func normal(x: float, z: float) -> Vector3:
	var e := 1.25
	return Vector3(-(height(x + e, z) - height(x - e, z)), 2.0 * e, -(height(x, z + e) - height(x, z - e))).normalized()

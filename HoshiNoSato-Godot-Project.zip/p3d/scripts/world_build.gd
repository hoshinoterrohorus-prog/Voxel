class_name WorldBuild
extends Node3D
## Membangun isi dunia dari world.json: pohon, gedung kota, rumah desa, lampu, jembatan, kuil, kristal.

var mat_prop: ShaderMaterial
var mat_foliage: ShaderMaterial
var mat_bld: ShaderMaterial
var mat_glow: ShaderMaterial
var mat_lamp: ShaderMaterial
var crystals: MultiMeshInstance3D
var crystal_pos: Array = []
var crystal_taken: Array = []
var waypoints: Array = []
var rng := RandomNumberGenerator.new()

const PAL := [Color(0.93,0.90,0.86), Color(0.80,0.88,0.96), Color(0.96,0.84,0.86), Color(0.82,0.93,0.86), Color(0.90,0.86,0.96), Color(0.96,0.93,0.78), Color(0.74,0.80,0.88), Color(0.95,0.78,0.70)]

func _mi(mesh: Mesh, pos := Vector3.ZERO) -> MeshInstance3D:
	var m := MeshInstance3D.new(); m.mesh = mesh; m.position = pos; add_child(m); return m

func _mm(mesh: Mesh, n: int, custom := false) -> MultiMeshInstance3D:
	var mm := MultiMesh.new(); mm.transform_format = MultiMesh.TRANSFORM_3D; mm.use_custom_data = custom; mm.use_colors = true
	mm.mesh = mesh; mm.instance_count = n
	for i in n: mm.set_instance_color(i, Color.WHITE)
	var i := MultiMeshInstance3D.new(); i.multimesh = mm; add_child(i); return i

func build(atmos: Atmos) -> void:
	rng.seed = 7
	mat_prop = ShaderMaterial.new(); mat_prop.shader = load("res://shaders/toon_vcol.gdshader")
	mat_foliage = ShaderMaterial.new(); mat_foliage.shader = load("res://shaders/toon_vcol.gdshader"); mat_foliage.set_shader_parameter("sway_amt", 0.07)
	mat_lamp = ShaderMaterial.new(); mat_lamp.shader = load("res://shaders/toon_vcol.gdshader")
	mat_glow = ShaderMaterial.new(); mat_glow.shader = load("res://shaders/toon_vcol.gdshader")
	mat_glow.set_shader_parameter("night", 1.0); mat_glow.set_shader_parameter("emit_c", Color(0.5, 0.95, 1.0))
	mat_bld = ShaderMaterial.new(); mat_bld.shader = load("res://shaders/building.gdshader")
	var pal := PackedColorArray(); for c in PAL: pal.append(c)
	mat_bld.set_shader_parameter("pal", pal)
	atmos.mats.append_array([mat_prop, mat_foliage, mat_bld, mat_lamp])
	_trees(); _city(); _village(); _lamps(); _bridge(); _shrine(); _waypoints(); _crystals()

func ground(x: float, z: float) -> float:
	return WD.height(x, z)

# ---------- pohon ----------
func _tree_mesh(kind: int) -> ArrayMesh:
	var b := MB.new()
	var trunk := Color(0.48, 0.34, 0.26)
	if kind == 0:   # sakura
		b.cyl(Vector3(0, 1.3, 0), 0.22, 0.34, 2.6, trunk, 0.0, 7)
		b.cyl(Vector3(0.5, 2.8, 0), 0.10, 0.18, 1.7, trunk, 0.0, 6, Basis(Vector3(0, 0, 1), -0.8))
		b.cyl(Vector3(-0.5, 2.7, 0.1), 0.10, 0.18, 1.6, trunk, 0.0, 6, Basis(Vector3(0, 0, 1), 0.8))
		var pk := [Color(1.0, 0.76, 0.84), Color(1.0, 0.68, 0.80), Color(1.0, 0.85, 0.90), Color(0.98, 0.72, 0.84)]
		var offs := [Vector3(0, 4.3, 0), Vector3(1.5, 3.7, 0.3), Vector3(-1.5, 3.8, -0.2), Vector3(0.3, 5.0, 0.9), Vector3(-0.4, 4.2, -1.3), Vector3(0.9, 4.4, -1.0), Vector3(-1.0, 4.6, 1.0)]
		for i in offs.size(): b.sphere(offs[i], 1.45 - (i % 3) * 0.15, pk[i % 4], 1.0, 0.85, 8, 5)
	elif kind == 1:  # cemara
		b.cyl(Vector3(0, 1.0, 0), 0.2, 0.3, 2.0, trunk, 0.0, 6)
		var g := [Color(0.20, 0.46, 0.38), Color(0.24, 0.52, 0.40), Color(0.28, 0.58, 0.42), Color(0.32, 0.62, 0.44)]
		for i in 4: b.cyl(Vector3(0, 2.6 + i * 1.8, 0), 0.0, 2.3 - i * 0.5, 2.6, g[i], 1.0, 8)
	else:            # pohon bulat
		b.cyl(Vector3(0, 1.4, 0), 0.24, 0.36, 2.8, trunk, 0.0, 7)
		var gg := [Color(0.40, 0.72, 0.34), Color(0.34, 0.66, 0.34), Color(0.50, 0.80, 0.38)]
		var offs2 := [Vector3(0, 4.4, 0), Vector3(1.3, 3.8, 0.2), Vector3(-1.3, 3.9, -0.3), Vector3(0.1, 5.5, 0.3), Vector3(0.2, 3.9, 1.3)]
		for i in offs2.size(): b.sphere(offs2[i], 1.7 - (i % 2) * 0.25, gg[i % 3], 1.0, 0.9, 8, 5)
	return b.build(mat_foliage)

func _trees() -> void:
	var by := [[], [], []]
	for t in WD.data["trees"]: by[int(t[2])].append(t)
	for st in WD.data["street_trees"]: by[2 if rng.randf() < 0.55 else 0].append([st[0], st[1], 2, 0.7])
	for k in 3:
		var lst: Array = by[k]
		var inst := _mm(_tree_mesh(k), lst.size(), true)
		for i in lst.size():
			var t: Array = lst[i]
			var x: float = t[0]; var z: float = t[1]; var s: float = t[3]
			var y := ground(x, z) - 0.15
			var basis := Basis(Vector3.UP, rng.randf() * TAU) * Basis.from_scale(Vector3(s, s * rng.randf_range(0.9, 1.15), s))
			inst.multimesh.set_instance_transform(i, Transform3D(basis, Vector3(x, y, z)))
			var tint := rng.randf_range(0.86, 1.08)
			inst.multimesh.set_instance_custom_data(i, Color(tint, tint * rng.randf_range(0.95, 1.05), tint, 1.0))
			Coll.add_circle(x, z, 0.5 * s + 0.1)
		inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		inst.visibility_range_end = 420.0

# ---------- kota ----------
func _city() -> void:
	var bl: Array = WD.data["buildings"]
	var unit := BoxMesh.new(); unit.size = Vector3.ONE
	unit.surface_set_material(0, mat_bld)
	var inst := _mm(unit, bl.size(), true)
	var det := MB.new()
	var cy := 3.0
	for i in bl.size():
		var b: Dictionary = bl[i]
		var h: float = b["h"]; var w: float = b["w"]; var d: float = b["d"]
		var x: float = b["x"]; var z: float = b["z"]
		var t := Transform3D(Basis.from_scale(Vector3(w, h + 2.5, d)), Vector3(x, cy - 2.5 + (h + 2.5) * 0.5, z))
		inst.multimesh.set_instance_transform(i, t)
		inst.multimesh.set_instance_custom_data(i, Color(float(b["c"]), rng.randf() * 10.0, 0, 0))
		Coll.add_rect(x, z, w * 0.5, d * 0.5, 0.0, cy + h)
		var top := cy + h
		# parapet & detail atap
		var pc := Color(0.62, 0.64, 0.72)
		det.box(Vector3(x, top + 0.25, z - d * 0.5 + 0.15), Vector3(w, 0.5, 0.3), pc)
		det.box(Vector3(x, top + 0.25, z + d * 0.5 - 0.15), Vector3(w, 0.5, 0.3), pc)
		det.box(Vector3(x - w * 0.5 + 0.15, top + 0.25, z), Vector3(0.3, 0.5, d), pc)
		det.box(Vector3(x + w * 0.5 - 0.15, top + 0.25, z), Vector3(0.3, 0.5, d), pc)
		var r := rng.randf()
		if r < 0.5:
			det.box(Vector3(x + w * 0.2, top + 0.9, z), Vector3(w * 0.28, 1.4, d * 0.26), Color(0.75, 0.78, 0.84))
		if r > 0.3:
			det.cyl(Vector3(x - w * 0.25, top + 1.9, z + d * 0.2), 1.1, 1.1, 2.4, Color(0.62, 0.45, 0.36), 0.0, 8)
			det.cyl(Vector3(x - w * 0.25, top + 3.4, z + d * 0.2), 0.0, 1.35, 0.9, Color(0.5, 0.36, 0.3), 0.0, 8)
		if h > 36.0:
			det.cyl(Vector3(x, top + 5.0, z), 0.06, 0.12, 10.0, Color(0.85, 0.3, 0.3), 0.0, 5)
			det.sphere(Vector3(x, top + 10.2, z), 0.35, Color(1.0, 0.3, 0.3), 0.5, 1.0, 6, 4)
	inst.visibility_range_end = 700.0
	_mi(det.build(mat_prop))
	# taman: bangku
	for bp in WD.data["benches"]:
		pass

func _lamps() -> void:
	var b := MB.new()
	var pole := Color(0.34, 0.36, 0.46)
	b.cyl(Vector3(0, 2.6, 0), 0.07, 0.12, 5.2, pole, 0.0, 6)
	b.box(Vector3(0.45, 5.15, 0), Vector3(1.0, 0.08, 0.1), pole)
	b.sphere(Vector3(0.85, 5.0, 0), 0.26, Color(1.0, 0.95, 0.75), 0.5, 1.0, 6, 4)
	var mesh := b.build(mat_lamp)
	var lst: Array = WD.data["lamps"]
	var inst := _mm(mesh, lst.size())
	for i in lst.size():
		var p: Array = lst[i]
		var y := 3.0
		var ang := atan2(WD.data["city"]["c"][1] - p[1], WD.data["city"]["c"][0] - p[0])
		inst.multimesh.set_instance_transform(i, Transform3D(Basis(Vector3.UP, -ang), Vector3(p[0], y, p[1])))
		Coll.add_circle(p[0], p[1], 0.18)
	inst.visibility_range_end = 300.0
	# lampu desa: lentera batu di sepanjang jalan
	var lb := MB.new()
	lb.box(Vector3(0, 0.3, 0), Vector3(0.6, 0.6, 0.6), Color(0.6, 0.6, 0.64))
	lb.cyl(Vector3(0, 0.9, 0), 0.12, 0.2, 0.7, Color(0.62, 0.62, 0.66), 0.0, 6)
	lb.box(Vector3(0, 1.45, 0), Vector3(0.55, 0.5, 0.55), Color(1.0, 0.9, 0.6), 0.5)
	lb.prism(Vector3(0, 1.95, 0), Vector3(0.9, 0.45, 0.9), Color(0.5, 0.5, 0.56))
	var lmesh := lb.build(mat_lamp)
	var vp: Array = WD.data["village_paths"]
	var pts := []
	for path in vp:
		for k in path.size() - 1:
			var a: Array = path[k]; var c: Array = path[k + 1]
			var L := Vector2(c[0] - a[0], c[1] - a[1]).length()
			var nrm := Vector2(-(c[1] - a[1]), c[0] - a[0]).normalized()
			var t := 6.0
			while t < L:
				var f := t / L
				var px: float = a[0] + (c[0] - a[0]) * f + nrm.x * 3.0
				var pz: float = a[1] + (c[1] - a[1]) * f + nrm.y * 3.0
				if WD.height(px, pz) > 0.6 and WD.splat(px, pz).g < 0.1: pts.append(Vector2(px, pz))
				t += 18.0
	var li := _mm(lmesh, pts.size())
	for i in pts.size():
		li.multimesh.set_instance_transform(i, Transform3D(Basis(), Vector3(pts[i].x, ground(pts[i].x, pts[i].y), pts[i].y)))
		Coll.add_circle(pts[i].x, pts[i].y, 0.35)

# ---------- desa ----------
func _village() -> void:
	var roofs := [Color(0.78, 0.36, 0.30), Color(0.30, 0.38, 0.52), Color(0.78, 0.64, 0.36)]
	var walls := [Color(0.97, 0.93, 0.84), Color(0.62, 0.45, 0.32), Color(0.88, 0.94, 0.97)]
	for hdat in WD.data["houses"]:
		var w: float = hdat["w"]; var d: float = hdat["d"]
		var x: float = hdat["x"]; var z: float = hdat["z"]; var rot: float = hdat["rot"]
		var gy := ground(x, z)
		var b := MB.new()
		var wc: Color = walls[hdat["wall"]]; var rc: Color = roofs[hdat["roof"]]
		b.box(Vector3(0, 0.1, 0), Vector3(w + 0.6, 1.1, d + 0.6), Color(0.58, 0.58, 0.62))       # pondasi batu
		b.box(Vector3(0, 2.3, 0), Vector3(w, 3.0, d), wc)
		if hdat["wall"] == 1:
			for k in 5: b.box(Vector3(-w * 0.5 + (k + 0.5) * w / 5.0, 2.3, d * 0.5 + 0.02), Vector3(0.12, 3.0, 0.06), Color(0.42, 0.30, 0.22))
		# balok kayu & pintu
		b.box(Vector3(0, 3.85, d * 0.5 + 0.03), Vector3(w, 0.18, 0.1), Color(0.40, 0.28, 0.22))
		b.box(Vector3(-w * 0.18, 1.7, d * 0.5 + 0.04), Vector3(1.1, 2.1, 0.1), Color(0.45, 0.30, 0.22))
		for sx in [-1.0, 1.0]:
			b.box(Vector3(sx * w * 0.3 + w * 0.12, 2.6, d * 0.5 + 0.04), Vector3(1.0, 1.0, 0.1), Color(1.0, 0.86, 0.5), 0.5)
			b.box(Vector3(sx * w * 0.3 + w * 0.12, 2.6, d * 0.5 + 0.02), Vector3(1.25, 1.25, 0.06), Color(0.4, 0.3, 0.25))
		b.box(Vector3(w * 0.5 + 0.04, 2.6, 0), Vector3(0.1, 1.0, 1.0), Color(1.0, 0.86, 0.5), 0.5)
		# atap (pelana, bubungan sepanjang sisi lebar)
		b.prism(Vector3(0, 3.8 + 1.35, 0), Vector3(d + 2.0, 2.7, w + 1.6), rc, 0.0, PI * 0.5)
		b.box(Vector3(0, 3.8 + 2.72, 0), Vector3(w + 1.7, 0.18, 0.4), rc.darkened(0.25))
		if hdat["roof"] != 2:
			b.box(Vector3(w * 0.28, 6.0, -d * 0.15), Vector3(0.6, 1.4, 0.6), Color(0.52, 0.5, 0.54))
		# tangga depan
		b.box(Vector3(-w * 0.18, 0.55, d * 0.5 + 0.7), Vector3(1.8, 0.35, 1.2), Color(0.62, 0.6, 0.64))
		var mi := MeshInstance3D.new(); mi.mesh = b.build(mat_prop)
		mi.position = Vector3(x, gy + 0.4, z); mi.rotation.y = rot; add_child(mi)
		mi.visibility_range_end = 450.0
		Coll.add_rect(x, z, (w + 0.6) * 0.5, (d + 0.6) * 0.5, -rot, gy + 4.5)
		# pagar kayu kecil & tong
		if rng.randf() < 0.6:
			var fb := MB.new()
			for k in 9: fb.box(Vector3(-4.0 + k, 0.5, 0), Vector3(0.14, 1.0, 0.14), Color(0.65, 0.5, 0.38))
			fb.box(Vector3(0, 0.75, 0), Vector3(8.2, 0.12, 0.1), Color(0.6, 0.46, 0.35))
			var fm := MeshInstance3D.new(); fm.mesh = fb.build(mat_prop)
			var fp := Vector3(x, gy, z) + Basis(Vector3.UP, rot) * Vector3(0, 0, d * 0.5 + 3.2)
			fm.position = Vector3(fp.x, ground(fp.x, fp.z), fp.z); fm.rotation.y = rot; add_child(fm)
	# gudang jerami / sumur di alun-alun
	var vc: Array = WD.data["village_center"]
	var wb := MB.new()
	wb.cyl(Vector3(0, 0.5, 0), 1.1, 1.2, 1.0, Color(0.62, 0.6, 0.64), 0.0, 10)
	wb.cyl(Vector3(0, 0.95, 0), 0.8, 0.8, 0.1, Color(0.2, 0.55, 0.7), 0.0, 10)
	wb.box(Vector3(-1.1, 1.7, 0), Vector3(0.14, 1.6, 0.14), Color(0.5, 0.36, 0.28)); wb.box(Vector3(1.1, 1.7, 0), Vector3(0.14, 1.6, 0.14), Color(0.5, 0.36, 0.28))
	wb.prism(Vector3(0, 2.8, 0), Vector3(1.8, 0.9, 3.0), Color(0.78, 0.36, 0.30), 0.0, PI * 0.5)
	var wm := _mi(wb.build(mat_prop), Vector3(vc[0], ground(vc[0], vc[1]), vc[1]))
	Coll.add_circle(vc[0], vc[1], 1.4)
	# jerami / kincir di ladang: tumpukan jerami
	var hb := MB.new(); hb.cyl(Vector3(0, 0.6, 0), 0.6, 0.6, 1.2, Color(0.95, 0.80, 0.35), 0.0, 8, Basis(Vector3(0, 0, 1), PI * 0.5)); hb.cyl(Vector3(0, 0.6, 0), 0.62, 0.62, 0.1, Color(0.82, 0.62, 0.22), 0.0, 8, Basis(Vector3(0, 0, 1), PI * 0.5))
	var hm := hb.build(mat_prop)
	for i in 26:
		var a := rng.randf() * TAU; var r := rng.randf_range(80.0, 150.0)
		var px: float = vc[0] + cos(a) * r; var pz: float = vc[1] + sin(a) * r
		if WD.splat(px, pz).g < 0.5: continue
		var hi := _mi(hm, Vector3(px, ground(px, pz), pz)); hi.rotation.y = rng.randf() * TAU

func _bridge() -> void:
	var br: Dictionary = WD.data["bridge"]
	var bx: float = br["x"]; var bz: float = br["z"]; var L: float = br["len"]
	var y := 3.75
	var b := MB.new()
	b.box(Vector3(0, y - 0.2, 0), Vector3(L, 0.45, 5.4), Color(0.62, 0.42, 0.30))
	for k in 24: b.box(Vector3(-L * 0.5 + (k + 0.5) * L / 24.0, y + 0.05, 0), Vector3(0.12, 0.08, 5.4), Color(0.5, 0.34, 0.25))
	for sz in [-1.0, 1.0]:
		b.box(Vector3(0, y + 1.0, sz * 2.6), Vector3(L, 0.18, 0.2), Color(0.85, 0.2, 0.2))
		b.box(Vector3(0, y + 0.55, sz * 2.6), Vector3(L, 0.1, 0.14), Color(0.85, 0.2, 0.2))
		for k in 13: b.box(Vector3(-L * 0.5 + 1.0 + k * (L - 2.0) / 12.0, y + 0.5, sz * 2.6), Vector3(0.22, 1.1, 0.22), Color(0.8, 0.18, 0.18))
	# tiang penyangga
	for k in 5:
		for sz in [-1.0, 1.0]: b.box(Vector3(-L * 0.5 + 3.0 + k * (L - 6.0) / 4.0, y - 2.6, sz * 2.0), Vector3(0.7, 5.0, 0.7), Color(0.45, 0.32, 0.26))
	var mi := _mi(b.build(mat_prop), Vector3(bx, 0, bz)); mi.rotation.y = 0.0
	# bidang jalan di atas jembatan: perlu "ground" agar pemain bisa berjalan di atasnya
	Coll.add_rect(bx, bz, L * 0.5, 2.7, 0.0, y + 0.0)

# ---------- kuil ----------
func _shrine() -> void:
	var s: Array = WD.data["shrine"]
	var sx: float = s[0]; var sz: float = s[1]
	var gy := ground(sx, sz)
	var b := MB.new()
	var red := Color(0.85, 0.2, 0.18); var wood := Color(0.55, 0.38, 0.28); var stone := Color(0.7, 0.7, 0.74)
	b.box(Vector3(0, -1.0, 0), Vector3(17, 3.0, 15), stone.darkened(0.1))
	b.box(Vector3(0, 0.7, 0), Vector3(16, 0.4, 14), stone)
	b.box(Vector3(0, 2.1, -1), Vector3(7, 2.8, 5), Color(0.96, 0.92, 0.84))
	for px in [-3.2, 3.2]:
		for pz in [-3.2, 1.2]: b.cyl(Vector3(px, 2.1, pz), 0.28, 0.28, 3.0, red, 0.0, 8)
	b.box(Vector3(0, 3.8, -1), Vector3(8.2, 0.4, 6.4), red.darkened(0.2))
	b.prism(Vector3(0, 5.2, -1), Vector3(7.4, 2.6, 9.4), Color(0.28, 0.32, 0.42), 0.0, PI * 0.5)
	b.prism(Vector3(0, 3.3, 2.8), Vector3(4.4, 1.2, 6.0), Color(0.28, 0.32, 0.42), 0.0, PI * 0.5)
	b.box(Vector3(0, 1.8, 1.55), Vector3(1.6, 1.2, 0.25), Color(1.0, 0.86, 0.5), 0.5)
	# torii (3)
	for k in 3:
		var tz := 11.0 + k * 7.0 - 0.0
		b.cyl(Vector3(-2.6, 3.2, tz), 0.28, 0.34, 6.4, red, 0.0, 8); b.cyl(Vector3(2.6, 3.2, tz), 0.28, 0.34, 6.4, red, 0.0, 8)
		b.box(Vector3(0, 6.1, tz), Vector3(8.0, 0.5, 0.6), Color(0.15, 0.12, 0.16)); b.box(Vector3(0, 5.2, tz), Vector3(6.4, 0.35, 0.4), red)
	# lentera
	for k in 4:
		for sx2 in [-4.5, 4.5]:
			var lz := 9.0 + k * 5.5
			b.box(Vector3(sx2, 0.5, lz), Vector3(0.6, 1.0, 0.6), stone)
			b.box(Vector3(sx2, 1.4, lz), Vector3(0.6, 0.6, 0.6), Color(1.0, 0.9, 0.6), 0.5)
			b.prism(Vector3(sx2, 1.95, lz), Vector3(0.95, 0.5, 0.95), stone.darkened(0.2))
	# jalur tangga
	for k in 8: b.box(Vector3(0, -0.6 - k * 0.55 + 0.0, 8.0 + k * 1.6), Vector3(5.0, 0.55, 1.6), stone)
	var mi := _mi(b.build(mat_prop), Vector3(sx, gy + 0.2, sz))
	Coll.add_rect(sx, sz - 1.0, 3.8, 3.0, 0.0, gy + 5.0)
	# pohon sakura besar di sekitar kuil
	var sm := _tree_mesh(0)
	for k in 6:
		var a := k / 6.0 * TAU + 0.4; var r := 11.0
		var tx := sx + cos(a) * r; var tz := sz + sin(a) * r * 0.9 - 3.0
		var ti := _mi(sm, Vector3(tx, ground(tx, tz), tz)); ti.scale = Vector3.ONE * 1.5; ti.rotation.y = a
		Coll.add_circle(tx, tz, 0.8)

# ---------- waypoint ----------
func _waypoints() -> void:
	var b := MB.new()
	b.cyl(Vector3(0, 0.25, 0), 1.6, 1.8, 0.5, Color(0.72, 0.74, 0.82))
	b.cyl(Vector3(0, 0.55, 0), 1.3, 1.3, 0.1, Color(0.5, 0.95, 1.0), 0.5)
	b.cyl(Vector3(0, 3.0, 0), 0.12, 0.12, 4.0, Color(0.7, 0.98, 1.0), 0.5)
	b.sphere(Vector3(0, 5.4, 0), 0.5, Color(0.8, 1.0, 1.0), 0.5, 1.2, 8, 5)
	var mesh := b.build(mat_glow)
	for w in WD.data["waypoints"]:
		var x: float = w["x"]; var z: float = w["z"]
		var mi := _mi(mesh, Vector3(x, ground(x, z), z))
		waypoints.append({"name": w["name"], "pos": Vector3(x, ground(x, z), z), "node": mi, "found": false})
	var light := OmniLight3D.new()

func _crystals() -> void:
	var sm := SphereMesh.new(); sm.radius = 0.35; sm.height = 1.1; sm.radial_segments = 4; sm.rings = 2
	var cm := ShaderMaterial.new(); cm.shader = load("res://shaders/toon_vcol.gdshader")
	cm.set_shader_parameter("night", 1.0); cm.set_shader_parameter("emit_c", Color(0.7, 0.9, 1.0))
	var b := MB.new(); b.add(sm, Transform3D(), Color(0.55, 0.85, 1.0), 0.5)
	var lst: Array = WD.data["crystals"]
	crystals = _mm(b.build(cm), lst.size())
	for i in lst.size():
		var p: Array = lst[i]
		crystal_pos.append(Vector3(p[0], ground(p[0], p[1]) + 1.3, p[1])); crystal_taken.append(false)
	crystals.visibility_range_end = 150.0
	update_crystals(0.0)

func update_crystals(t: float) -> void:
	for i in crystal_pos.size():
		if crystal_taken[i]:
			crystals.multimesh.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3.ZERO), crystal_pos[i])); continue
		var p: Vector3 = crystal_pos[i]
		crystals.multimesh.set_instance_transform(i, Transform3D(Basis(Vector3.UP, t * 1.4 + i), p + Vector3(0, sin(t * 2.0 + i) * 0.18, 0)))

class_name Player
extends Node3D
## Pemain kinematik: jalan/lari/sprint/dash, lompat 2x, glide, arung air, tabrakan 2D.

signal jumped
signal landed(speed: float)
signal stepped
signal dashed

const R := 0.38
const WATER_Y := -0.6
var avatar: Avatar
var vel := Vector2.ZERO
var vy := 0.0
var on_ground := false
var jumps := 0
var gliding := false
var sprint := false
var dash_t := 0.0
var dash_cd := 0.0
var yaw := 0.0
var move := Vector2.ZERO     # x kanan, y maju (-1..1)
var cam_yaw := 0.0
var in_water := false
var step_acc := 0.0
var state := 0
var frozen := false

func setup() -> void:
	avatar = Avatar.new(); add_child(avatar); avatar.setup(0.0, 1.0, 1.0, true)

func teleport(p: Vector3) -> void:
	position = p; vel = Vector2.ZERO; vy = 0.0; gliding = false; jumps = 0

func press_jump() -> void:
	if frozen: return
	if on_ground:
		vy = 11.5; on_ground = false; jumps = 1; jumped.emit()
	elif gliding:
		gliding = false
	elif jumps == 1:
		vy = 10.0; jumps = 2; jumped.emit()
	elif jumps >= 2:
		gliding = true

func press_dash() -> void:
	if frozen or dash_cd > 0.0: return
	dash_t = 0.28; dash_cd = 0.9; dashed.emit()
	if not on_ground: vy = maxf(vy, 2.0)

func _ground_at(x: float, z: float) -> float:
	return maxf(WD.height(x, z), WATER_Y - 0.9)

func update(dt: float) -> void:
	dt = minf(dt, 0.05)
	dash_cd = maxf(0.0, dash_cd - dt); dash_t = maxf(0.0, dash_t - dt)
	var fwd := Vector3(-sin(cam_yaw), 0, -cos(cam_yaw)); var rgt := Vector3(cos(cam_yaw), 0, -sin(cam_yaw))
	var m := move if not frozen else Vector2.ZERO
	var want := rgt * m.x + fwd * m.y
	var mag := clampf(want.length(), 0.0, 1.0)
	var dir := want.normalized() if mag > 0.05 else Vector3.ZERO
	in_water = position.y < WATER_Y + 0.3 and WD.height(position.x, position.z) < WATER_Y
	var spd := 0.0
	if mag > 0.05: spd = 4.6 if mag < 0.65 else 8.8
	if sprint and mag > 0.05: spd = 13.0
	if in_water: spd *= 0.55
	var target := Vector2(dir.x, dir.z) * spd
	if gliding:
		var fd := Vector2(sin(yaw), cos(yaw))
		if mag > 0.05:
			var ta := atan2(dir.x, dir.z); yaw = lerp_angle(yaw, ta, 1.0 - exp(-dt * 2.6))
		target = Vector2(sin(yaw), cos(yaw)) * 15.0
	if dash_t > 0.0:
		target = Vector2(sin(yaw), cos(yaw)) * 26.0
	var acc := 60.0 if on_ground else 18.0
	if gliding: acc = 10.0
	if dash_t > 0.0: acc = 200.0
	vel = vel.move_toward(target, acc * dt)
	if mag > 0.05 and not gliding and dash_t <= 0.0:
		yaw = lerp_angle(yaw, atan2(dir.x, dir.z), 1.0 - exp(-dt * 14.0))
	# gerak horizontal + batas kemiringan + tabrakan
	var step := vel * dt
	var np := position + Vector3(step.x, 0, step.y)
	var rise := _ground_at(np.x, np.z) - position.y
	var dist := step.length()
	if on_ground and rise > dist * 1.5 + 0.12:
		var nx := position + Vector3(step.x, 0, 0); var nz := position + Vector3(0, 0, step.y)
		var rx := _ground_at(nx.x, nx.z) - position.y; var rz := _ground_at(nz.x, nz.z) - position.y
		np = position
		if rx <= absf(step.x) * 1.5 + 0.12: np.x = nx.x
		if rz <= absf(step.y) * 1.5 + 0.12: np.z = nz.z
		if np == position: vel *= 0.5
	np.x = clampf(np.x, -625.0, 625.0); np.z = clampf(np.z, -625.0, 625.0)
	var res := Coll.resolve(np, R, position.y)
	np.x = res.x; np.z = res.y
	var floor_y := maxf(_ground_at(np.x, np.z), res.z)
	# vertikal
	var was_ground := on_ground
	if gliding: vy = maxf(vy - 8.0 * dt, -2.6)
	else: vy -= 30.0 * dt
	if in_water and not on_ground: vy = maxf(vy, -6.0)
	np.y = position.y + vy * dt
	if np.y <= floor_y:
		var fall := -vy
		np.y = floor_y; vy = 0.0
		if not was_ground and fall > 3.0: landed.emit(fall)
		on_ground = true; jumps = 0; gliding = false
	else:
		on_ground = np.y - floor_y < 0.05 and vy <= 0.0
	position = np
	if position.y < -40.0: teleport(Vector3(position.x, WD.height(position.x, position.z) + 3.0, position.z))
	# langkah kaki
	var sp := vel.length()
	if on_ground and sp > 1.2:
		step_acc += sp * dt
		if step_acc > (1.9 if sp < 7.0 else 2.6): step_acc = 0.0; stepped.emit()
	rotation.y = yaw
	if gliding: state = 3
	elif dash_t > 0.0: state = 4
	elif not on_ground: state = 2
	elif sp > 0.6: state = 1
	else: state = 0
	avatar.animate(dt, state, sp, vy)

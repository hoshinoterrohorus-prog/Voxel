class_name Coll
extends RefCounted
## Tabrakan 2D sederhana: persegi (bisa berputar) + lingkaran, hash grid. top = tinggi atas (bisa diinjak).

const CELL := 32.0
static var grid := {}
static var rects: Array = []   # [cx, cz, hx, hz, cos, sin, top]
static var circs: Array = []   # [x, z, r, top]

static func _key(ix: int, iz: int) -> int: return ix * 100003 + iz

static func _insert(kind: int, id: int, minx: float, minz: float, maxx: float, maxz: float) -> void:
	for ix in range(int(floor(minx / CELL)), int(floor(maxx / CELL)) + 1):
		for iz in range(int(floor(minz / CELL)), int(floor(maxz / CELL)) + 1):
			var k := _key(ix, iz)
			if not grid.has(k): grid[k] = []
			grid[k].append([kind, id])

static func add_rect(cx: float, cz: float, hx: float, hz: float, ang: float, top: float) -> void:
	rects.append([cx, cz, hx, hz, cos(ang), sin(ang), top])
	var r := absf(hx * cos(ang)) + absf(hz * sin(ang)); var r2 := absf(hx * sin(ang)) + absf(hz * cos(ang))
	_insert(0, rects.size() - 1, cx - r, cz - r2, cx + r, cz + r2)

static func add_circle(x: float, z: float, r: float, top: float = 99.0) -> void:
	circs.append([x, z, r, top])
	_insert(1, circs.size() - 1, x - r, z - r, x + r, z + r)

## dorong keluar; kembalikan Vector3(x, z, ground_top) di mana ground_top = tinggi permukaan yang bisa diinjak (atau -1e9)
static func resolve(pos: Vector3, radius: float, feet: float) -> Vector3:
	var p := Vector2(pos.x, pos.z)
	var ground := -1e9
	var seen := {}
	for ix in range(int(floor((p.x - radius) / CELL)), int(floor((p.x + radius) / CELL)) + 1):
		for iz in range(int(floor((p.y - radius) / CELL)), int(floor((p.y + radius) / CELL)) + 1):
			var lst = grid.get(_key(ix, iz))
			if lst == null: continue
			for e in lst:
				var sid: int = e[1] * 2 + e[0]
				if seen.has(sid): continue
				seen[sid] = true
				if e[0] == 0:
					var r: Array = rects[e[1]]
					var d := p - Vector2(r[0], r[1])
					var lx: float = d.x * r[4] + d.y * r[5]
					var lz: float = -d.x * r[5] + d.y * r[4]
					var inside: bool = absf(lx) < r[2] and absf(lz) < r[3]
					if inside and feet >= r[6] - 0.35: ground = maxf(ground, r[6]); continue
					if feet >= r[6] - 0.05: continue
					var cx := clampf(lx, -r[2], r[2]); var cz := clampf(lz, -r[3], r[3])
					var dx := lx - cx; var dz := lz - cz
					var dd := sqrt(dx * dx + dz * dz)
					if dd < radius:
						var nx: float; var nz: float; var push: float
						if dd > 0.0001:
							nx = dx / dd; nz = dz / dd; push = radius - dd
						else:
							var px: float = r[2] - absf(lx); var pz: float = r[3] - absf(lz)
							if px < pz: nx = signf(lx); nz = 0.0; push = px + radius
							else: nx = 0.0; nz = signf(lz); push = pz + radius
						var wx: float = nx * r[4] - nz * r[5]
						var wz: float = nx * r[5] + nz * r[4]
						p += Vector2(wx, wz) * push
				else:
					var c: Array = circs[e[1]]
					if feet >= c[3]: continue
					var d2 := p - Vector2(c[0], c[1]); var l := d2.length(); var rr: float = c[2] + radius
					if l < rr:
						if l < 0.0001: d2 = Vector2(1, 0); l = 0.0001
						p += d2 / l * (rr - l)
	return Vector3(p.x, p.y, ground)

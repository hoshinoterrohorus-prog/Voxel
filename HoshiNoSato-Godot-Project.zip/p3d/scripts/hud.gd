class_name Hud
extends Control
## HUD sentuh: joystick melayang kiri, geser kanan = kamera, tombol bundar, peta, banner lokasi, dialog.

signal jump_pressed
signal dash_pressed
signal sprint_toggled(on: bool)
signal interact_pressed
signal travel(idx: int)
signal quality_cycle
var quality_label := "Grafik: Tinggi"

var move := Vector2.ZERO
var look := Vector2.ZERO          # akumulasi geser kamera (piksel)
var sprint_on := false
var interact_label := ""
var crystals := 0
var time_text := "--:--"
var heading := 0.0
var touches := {}                 # id -> {role, pos, start}
var joy_center := Vector2.ZERO
var joy_vec := Vector2.ZERO
var toast_text := ""; var toast_t := 0.0
var banner_text := ""; var banner_t := 0.0
var say_text := ""; var say_t := 0.0; var say_who := ""
var menu: PanelContainer
var menu_box: VBoxContainer
var fps_text := ""
var font: Font

func _ready() -> void:
	font = ThemeDB.fallback_font
	set_anchors_preset(Control.PRESET_FULL_RECT); mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu = PanelContainer.new(); menu.visible = false
	var sb := StyleBoxFlat.new(); sb.bg_color = Color(0.08, 0.08, 0.16, 0.92); sb.set_corner_radius_all(18)
	sb.content_margin_left = 20; sb.content_margin_right = 20; sb.content_margin_top = 16; sb.content_margin_bottom = 16
	menu.add_theme_stylebox_override("panel", sb)
	menu.set_anchors_preset(Control.PRESET_CENTER); menu.grow_horizontal = Control.GROW_DIRECTION_BOTH; menu.grow_vertical = Control.GROW_DIRECTION_BOTH
	add_child(menu)
	menu_box = VBoxContainer.new(); menu_box.add_theme_constant_override("separation", 10); menu.add_child(menu_box)

func btn_defs() -> Array:
	var s := size
	var a := [
		{"id": "jump", "c": Vector2(s.x - 120, s.y - 120), "r": 64.0, "t": "LOMPAT"},
		{"id": "dash", "c": Vector2(s.x - 262, s.y - 78), "r": 46.0, "t": "DASH"},
		{"id": "sprint", "c": Vector2(s.x - 92, s.y - 262), "r": 46.0, "t": "LARI"},
		{"id": "map", "c": Vector2(s.x - 56, 56), "r": 34.0, "t": "PETA"},
	]
	if interact_label != "": a.append({"id": "act", "c": Vector2(s.x - 240, s.y - 205), "r": 52.0, "t": interact_label})
	return a

func _hit_btn(p: Vector2) -> String:
	for d in btn_defs():
		if p.distance_to(d["c"]) <= d["r"] + 10.0: return d["id"]
	return ""

func show_toast(t: String, sec := 2.5) -> void: toast_text = t; toast_t = sec
func show_banner(t: String) -> void: banner_text = t; banner_t = 3.6
func say(who: String, t: String) -> void: say_who = who; say_text = t; say_t = 4.5

func open_menu(names: Array, found: Array) -> void:
	for c in menu_box.get_children(): c.queue_free()
	var l := Label.new(); l.text = "TELEPORT"; l.add_theme_font_size_override("font_size", 26); menu_box.add_child(l)
	for i in names.size():
		var b := Button.new(); b.text = names[i] if found[i] else "??? (belum ditemukan)"; b.disabled = not found[i]
		b.custom_minimum_size = Vector2(480, 56); b.add_theme_font_size_override("font_size", 22)
		b.pressed.connect(func(): menu.visible = false; travel.emit(i)); menu_box.add_child(b)
	var q := Button.new(); q.text = quality_label + "  (ketuk untuk ganti)"; q.custom_minimum_size = Vector2(480, 52); q.add_theme_font_size_override("font_size", 20)
	q.pressed.connect(func(): menu.visible = false; quality_cycle.emit()); menu_box.add_child(q)
	var c := Button.new(); c.text = "Tutup"; c.custom_minimum_size = Vector2(480, 52); c.add_theme_font_size_override("font_size", 22)
	c.pressed.connect(func(): menu.visible = false); menu_box.add_child(c)
	menu.visible = true

func _input(e: InputEvent) -> void:
	if menu.visible: return
	if e is InputEventScreenTouch:
		var id: int = e.index
		if e.pressed:
			var p: Vector2 = e.position
			var b := _hit_btn(p)
			if b != "":
				touches[id] = {"role": "btn", "id": b, "pos": p}
				match b:
					"jump": jump_pressed.emit()
					"dash": dash_pressed.emit()
					"sprint": sprint_on = not sprint_on; sprint_toggled.emit(sprint_on)
					"map": map_req = true
					"act": interact_pressed.emit()
			elif p.x < size.x * 0.42:
				touches[id] = {"role": "joy", "pos": p, "start": p}; joy_center = p; joy_vec = Vector2.ZERO
			else:
				touches[id] = {"role": "look", "pos": p}
		else:
			if touches.has(id):
				if touches[id]["role"] == "joy": joy_vec = Vector2.ZERO
				touches.erase(id)
	elif e is InputEventScreenDrag:
		var id: int = e.index
		if not touches.has(id): return
		var t: Dictionary = touches[id]
		if t["role"] == "joy":
			var d: Vector2 = e.position - joy_center
			var maxr := 90.0
			if d.length() > maxr: joy_center += d.normalized() * (d.length() - maxr); d = e.position - joy_center
			joy_vec = d / maxr
		elif t["role"] == "look":
			look += e.relative
		t["pos"] = e.position
	if e is InputEventKey and e.pressed and not e.echo:
		match e.keycode:
			KEY_SPACE: jump_pressed.emit()
			KEY_SHIFT: sprint_on = not sprint_on; sprint_toggled.emit(sprint_on)
			KEY_Q: dash_pressed.emit()
			KEY_E, KEY_F: interact_pressed.emit()
			KEY_M: map_req = true

var map_req := false

func get_move() -> Vector2:
	var v := Vector2(joy_vec.x, -joy_vec.y)
	var kx := (1.0 if Input.is_key_pressed(KEY_D) else 0.0) - (1.0 if Input.is_key_pressed(KEY_A) else 0.0)
	var ky := (1.0 if Input.is_key_pressed(KEY_W) else 0.0) - (1.0 if Input.is_key_pressed(KEY_S) else 0.0)
	if kx != 0.0 or ky != 0.0: v = Vector2(kx, ky).normalized()
	if v.length() > 1.0: v = v.normalized()
	if v.length() < 0.12: v = Vector2.ZERO
	return v

func _process(dt: float) -> void:
	size = get_viewport_rect().size
	toast_t = maxf(0.0, toast_t - dt); banner_t = maxf(0.0, banner_t - dt); say_t = maxf(0.0, say_t - dt)
	queue_redraw()

func _txt(s: String, p: Vector2, fs: int, col := Color.WHITE, center := false) -> void:
	var w := font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	var pos := p - Vector2(w * 0.5 if center else 0.0, 0.0)
	draw_string_outline(font, pos, s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 6, Color(0.05, 0.05, 0.15, 0.85))
	draw_string(font, pos, s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, col)

func _draw() -> void:
	var s := size
	# joystick
	if joy_center != Vector2.ZERO and touches.values().any(func(t): return t["role"] == "joy"):
		draw_circle(joy_center, 96.0, Color(1, 1, 1, 0.10)); draw_arc(joy_center, 96.0, 0, TAU, 48, Color(1, 1, 1, 0.5), 3.0)
		draw_circle(joy_center + joy_vec * 90.0, 40.0, Color(1, 1, 1, 0.45))
	else:
		var hc := Vector2(170, s.y - 150)
		draw_arc(hc, 80.0, 0, TAU, 40, Color(1, 1, 1, 0.22), 3.0); draw_circle(hc, 32.0, Color(1, 1, 1, 0.12))
	# tombol
	for d in btn_defs():
		var on: bool = (d["id"] == "sprint" and sprint_on)
		var c: Vector2 = d["c"]; var r: float = d["r"]
		draw_circle(c, r, Color(0.35, 0.55, 1.0, 0.55) if on else Color(0.1, 0.1, 0.22, 0.45))
		draw_arc(c, r, 0, TAU, 40, Color(1, 1, 1, 0.8), 3.0)
		_txt(d["t"], c + Vector2(0, 7), 18 if r < 60 else 21, Color.WHITE, true)
	# info kiri atas
	_txt(time_text, Vector2(22, 44), 30)
	_txt("Kristal  %d" % crystals, Vector2(22, 80), 24, Color(0.7, 0.95, 1.0))
	if fps_text != "": _txt(fps_text, Vector2(22, 112), 20, Color(1, 1, 1, 0.7))
	# kompas
	var hdg := fposmod(rad_to_deg(heading), 360.0)
	var dirs := ["U", "TL", "T", "TG", "S", "BD", "B", "BL"]
	_txt("%s  %d" % [dirs[int(round(hdg / 45.0)) % 8], int(hdg)], Vector2(s.x * 0.5, 40), 22, Color(1, 1, 1, 0.85), true)
	# banner & toast & dialog
	if banner_t > 0.0:
		var a := clampf(minf(banner_t, 3.6 - banner_t) * 2.0, 0.0, 1.0)
		_txt(banner_text, Vector2(s.x * 0.5, 130), 46, Color(1, 1, 1, a), true)
	if toast_t > 0.0: _txt(toast_text, Vector2(s.x * 0.5, 190), 26, Color(1, 0.95, 0.6, clampf(toast_t, 0.0, 1.0)), true)
	if say_t > 0.0:
		var bw := minf(s.x - 200, 760.0)
		draw_rect(Rect2(s.x * 0.5 - bw * 0.5, s.y - 150, bw, 84), Color(0.06, 0.06, 0.14, 0.8), true)
		_txt(say_who, Vector2(s.x * 0.5 - bw * 0.5 + 16, s.y - 150 + 28), 22, Color(1.0, 0.8, 0.9))
		_txt(say_text, Vector2(s.x * 0.5 - bw * 0.5 + 16, s.y - 150 + 62), 24)

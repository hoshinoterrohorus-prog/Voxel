class_name Npcs
extends Node3D
## Warga kota/desa: data ringan untuk semua, hanya beberapa yang tampil (pool) di dekat pemain.

const POOL := 8
const ACTIVE_R := 80.0
const NAMES := ["Aoi", "Haru", "Mika", "Ren", "Sora", "Yui", "Kaito", "Nami", "Riku", "Hana", "Toma", "Mio", "Akira", "Rin", "Yuki", "Sana", "Koji", "Emi", "Daichi", "Noa", "Mei"]
const LINES_CITY := [
	"Lampu kota malam ini cantik banget ya.", "Katanya ada kristal biru di sekitar menara.", "Aku lagi nunggu teman di alun-alun.",
	"Kamu kelihatan lagi jalan-jalan. Hati-hati sama sungai!", "Coba loncat dua kali, lalu tahan lompat buat meluncur!", "Kopi dingin di kafe sebelah enak lho.",
]
const LINES_VIL := [
	"Sakura di desa mekar sepanjang tahun.", "Kuil di timur laut itu tempat favoritku.", "Di ladang banyak kristal kecil, rajin-rajin cari ya.",
	"Udara desa segar, kan?", "Kalau capek, duduk aja di bawah pohon sakura.", "Jembatan merah itu tempat orang janjian.",
]
var data: Array = []
var pool: Array[Avatar] = []
var slot: Array[int] = []
var timer := 0.0
var rng := RandomNumberGenerator.new()

func setup() -> void:
	rng.seed = 5
	var i := 0
	for n in WD.data["npcs"]:
		var p := Vector2(n["x"], n["z"])
		data.append({"pos": Vector3(p.x, WD.height(p.x, p.y), p.y), "home": p, "target": p, "wait": rng.randf() * 4.0, "yaw": rng.randf() * TAU,
			"hue": rng.randf_range(-0.5, 0.5), "sat": rng.randf_range(0.8, 1.25), "val": rng.randf_range(0.85, 1.1),
			"name": NAMES[i % NAMES.size()], "city": n["zone"] == "city", "speed": 0.0})
		i += 1
	for k in POOL:
		var a := Avatar.new(); add_child(a); a.setup(0.0, 1.0, 1.0, true); a.visible = false; pool.append(a); slot.append(-1)

func night(v: float) -> void:
	for a in pool: a.set_night(v)

func say_line(i: int) -> String:
	var l: Array = LINES_CITY if data[i]["city"] else LINES_VIL
	return l[rng.randi() % l.size()]

func nearest(p: Vector3, r: float) -> int:
	var best := -1; var bd := r
	for i in data.size():
		var d: float = (data[i]["pos"] as Vector3).distance_to(p)
		if d < bd: bd = d; best = i
	return best

func _assign(pp: Vector3) -> void:
	var near: Array = []
	for i in data.size():
		var d: float = (data[i]["pos"] as Vector3).distance_to(pp)
		if d < ACTIVE_R: near.append([d, i])
	near.sort_custom(func(a, b): return a[0] < b[0])
	var want := []
	for k in mini(near.size(), POOL): want.append(near[k][1])
	for s in POOL:
		if slot[s] != -1 and not (slot[s] in want): slot[s] = -1; pool[s].visible = false
	for w in want:
		if w in slot: continue
		for s in POOL:
			if slot[s] == -1:
				slot[s] = w; var d: Dictionary = data[w]
				pool[s].set_hue(d["hue"], d["sat"], d["val"]); pool[s].visible = true; break

func update(dt: float, pp: Vector3, talk_to := -1) -> void:
	timer -= dt
	if timer <= 0.0: timer = 0.5; _assign(pp)
	for s in POOL:
		var i := slot[s]
		if i < 0: continue
		var d: Dictionary = data[i]
		var pos: Vector3 = d["pos"]
		var spd := 0.0
		if i == talk_to:
			var dv := pp - pos; d["yaw"] = lerp_angle(d["yaw"], atan2(dv.x, dv.z), 1.0 - exp(-dt * 6.0))
		else:
			d["wait"] -= dt
			var tgt: Vector2 = d["target"]
			var to := tgt - Vector2(pos.x, pos.z)
			if d["wait"] > 0.0 and to.length() < 0.4: pass
			elif to.length() < 0.5:
				d["wait"] = rng.randf_range(2.0, 7.0)
				var h: Vector2 = d["home"]; d["target"] = h + Vector2(rng.randf_range(-10, 10), rng.randf_range(-10, 10))
			else:
				var dir := to.normalized(); spd = 1.5
				var np := Vector2(pos.x, pos.z) + dir * spd * dt
				var r := Coll.resolve(Vector3(np.x, pos.y, np.y), 0.4, pos.y)
				pos.x = r.x; pos.z = r.y
				d["yaw"] = lerp_angle(d["yaw"], atan2(dir.x, dir.y), 1.0 - exp(-dt * 8.0))
		pos.y = maxf(WD.height(pos.x, pos.z), -0.9)
		d["pos"] = pos
		var a := pool[s]; a.position = pos; a.rotation.y = d["yaw"]
		a.animate(dt, 1 if spd > 0.1 else 0, spd * 1.0, 0.0)

class_name MB
extends RefCounted
## Pembangun mesh sederhana: gabungkan primitif berwarna ke satu ArrayMesh (warna vertex).

var st := SurfaceTool.new()
func _init() -> void:
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

func add(m: Mesh, xf: Transform3D, col: Color, a: float = 0.0) -> void:
	var arr := m.surface_get_arrays(0)
	var vs: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
	var ns: PackedVector3Array = arr[Mesh.ARRAY_NORMAL]
	var idx = arr[Mesh.ARRAY_INDEX]
	var c := Color(col.r, col.g, col.b, a)
	var bn := xf.basis.inverse().transposed()
	if idx == null or idx.size() == 0:
		for i in vs.size():
			st.set_color(c); st.set_normal((bn * ns[i]).normalized()); st.add_vertex(xf * vs[i])
	else:
		for k in idx.size():
			var i: int = idx[k]
			st.set_color(c); st.set_normal((bn * ns[i]).normalized()); st.add_vertex(xf * vs[i])

func box(pos: Vector3, size: Vector3, col: Color, a: float = 0.0, rot_y: float = 0.0) -> void:
	var m := BoxMesh.new(); m.size = Vector3.ONE
	add(m, Transform3D(Basis(Vector3.UP, rot_y) * Basis.from_scale(size), pos), col, a)

func cyl(pos: Vector3, r_top: float, r_bot: float, h: float, col: Color, a: float = 0.0, seg: int = 8, basis: Basis = Basis.IDENTITY) -> void:
	var m := CylinderMesh.new(); m.top_radius = r_top; m.bottom_radius = r_bot; m.height = h; m.radial_segments = seg; m.rings = 1
	add(m, Transform3D(basis, pos), col, a)

func sphere(pos: Vector3, r: float, col: Color, a: float = 0.0, sy: float = 1.0, seg: int = 8, rings: int = 5) -> void:
	var m := SphereMesh.new(); m.radius = 1.0; m.height = 2.0; m.radial_segments = seg; m.rings = rings
	add(m, Transform3D(Basis.from_scale(Vector3(r, r * sy, r)), pos), col, a)

func prism(pos: Vector3, size: Vector3, col: Color, a: float = 0.0, rot_y: float = 0.0) -> void:
	var m := PrismMesh.new(); m.size = Vector3.ONE; m.left_to_right = 0.5
	add(m, Transform3D(Basis(Vector3.UP, rot_y) * Basis.from_scale(size), pos), col, a)

func build(mat: Material) -> ArrayMesh:
	var m := st.commit()
	m.surface_set_material(0, mat)
	return m

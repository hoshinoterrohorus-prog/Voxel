class_name Atmos
extends Node
## Langit anime, siang-malam, cahaya, kabut. 1 jam game = 1 menit nyata.

var hour := 16.7
var time_scale := 1.0 / 60.0 * 1.0   # jam game per detik nyata
var paused := false
var sun: DirectionalLight3D
var env: Environment
var we: WorldEnvironment
var sky_mat: ShaderMaterial
var night := 0.0
var mats: Array = []                 # material lain yang butuh 'night'
var clock := 0.0

# jam, zenith, horizon, sun_c, light_e, amb_c, amb_e, fog_c, fog_d, star, cloud_lit, cloud_shade, coverage
const KEYS := [
	[0.0,  Color(0.03,0.05,0.16), Color(0.10,0.14,0.32), Color(0.55,0.65,1.0), 0.30, Color(0.30,0.36,0.62), 0.9, Color(0.09,0.12,0.26), 0.0016, 1.0, Color(0.45,0.52,0.80), Color(0.18,0.22,0.42), 0.40],
	[4.8,  Color(0.05,0.07,0.20), Color(0.16,0.18,0.38), Color(0.55,0.65,1.0), 0.30, Color(0.30,0.36,0.62), 0.9, Color(0.12,0.14,0.30), 0.0016, 0.9, Color(0.50,0.52,0.82), Color(0.22,0.24,0.44), 0.42],
	[6.2,  Color(0.30,0.40,0.78), Color(1.00,0.70,0.60), Color(1.0,0.74,0.55), 0.95, Color(0.62,0.58,0.78), 1.0, Color(0.95,0.72,0.70), 0.0013, 0.2, Color(1.0,0.86,0.80), Color(0.62,0.55,0.80), 0.5],
	[8.0,  Color(0.28,0.56,0.96), Color(0.80,0.92,1.00), Color(1.0,0.95,0.86), 1.55, Color(0.66,0.78,0.98), 1.1, Color(0.78,0.88,1.00), 0.0009, 0.0, Color(1.0,1.0,1.0), Color(0.70,0.80,0.97), 0.52],
	[12.5, Color(0.20,0.50,0.96), Color(0.72,0.89,1.00), Color(1.0,0.97,0.90), 1.75, Color(0.66,0.80,1.00), 1.15, Color(0.74,0.88,1.00), 0.0008, 0.0, Color(1.0,1.0,1.0), Color(0.72,0.82,0.98), 0.5],
	[16.5, Color(0.30,0.50,0.92), Color(1.00,0.84,0.66), Color(1.0,0.82,0.56), 1.55, Color(0.78,0.74,0.92), 1.0, Color(1.00,0.84,0.72), 0.0010, 0.0, Color(1.0,0.93,0.86), Color(0.72,0.70,0.92), 0.55],
	[18.0, Color(0.30,0.32,0.68), Color(1.00,0.52,0.42), Color(1.0,0.56,0.36), 1.15, Color(0.70,0.55,0.78), 0.95, Color(0.98,0.58,0.52), 0.0012, 0.05, Color(1.0,0.74,0.62), Color(0.55,0.46,0.74), 0.6],
	[19.3, Color(0.13,0.13,0.40), Color(0.68,0.36,0.58), Color(0.7,0.45,0.75), 0.55, Color(0.45,0.42,0.72), 0.9, Color(0.50,0.34,0.56), 0.0014, 0.5, Color(0.72,0.50,0.72), Color(0.30,0.28,0.56), 0.55],
	[20.8, Color(0.04,0.06,0.18), Color(0.12,0.16,0.35), Color(0.55,0.65,1.0), 0.30, Color(0.30,0.36,0.62), 0.9, Color(0.10,0.13,0.28), 0.0016, 1.0, Color(0.45,0.52,0.80), Color(0.18,0.22,0.42), 0.42],
	[24.0, Color(0.03,0.05,0.16), Color(0.10,0.14,0.32), Color(0.55,0.65,1.0), 0.30, Color(0.30,0.36,0.62), 0.9, Color(0.09,0.12,0.26), 0.0016, 1.0, Color(0.45,0.52,0.80), Color(0.18,0.22,0.42), 0.40],
]

func setup(parent: Node) -> void:
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_max_distance = 130.0
	sun.directional_shadow_split_1 = 0.22
	sun.directional_shadow_blend_splits = true
	sun.shadow_bias = 0.04
	sun.shadow_normal_bias = 1.2
	sun.shadow_blur = 1.6
	sun.light_angular_distance = 0.6
	parent.add_child(sun)
	var sky := Sky.new()
	sky_mat = ShaderMaterial.new(); sky_mat.shader = load("res://shaders/sky.gdshader")
	sky.sky_material = sky_mat
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_white = 6.0
	env.glow_enabled = true
	env.glow_intensity = 0.75
	env.glow_strength = 1.0
	env.glow_bloom = 0.08
	env.glow_hdr_threshold = 1.05
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
	env.fog_enabled = true
	env.fog_light_energy = 1.0
	env.fog_sun_scatter = 0.08
	env.fog_aerial_perspective = 0.1
	env.fog_sky_affect = 0.0
	env.adjustment_enabled = true
	env.adjustment_saturation = 1.18
	env.adjustment_contrast = 1.06
	we = WorldEnvironment.new(); we.environment = env
	parent.add_child(we)
	apply()

func _process(dt: float) -> void:
	clock += dt
	if not paused:
		hour = fposmod(hour + dt * time_scale, 24.0)
	apply()

func _lerp_keys(h: float, k: int):
	var a: Array = KEYS[0]; var b: Array = KEYS[1]
	for i in KEYS.size() - 1:
		if h >= KEYS[i][0] and h <= KEYS[i + 1][0]:
			a = KEYS[i]; b = KEYS[i + 1]; break
	var t := inverse_lerp(a[0], b[0], h)
	t = t * t * (3.0 - 2.0 * t)
	return lerp(a[k], b[k], t)

func sun_vec(h: float) -> Vector3:
	var a := (h - 6.0) / 12.0 * PI
	return Vector3(cos(a) * 0.55, sin(a), 0.42).normalized()

func apply() -> void:
	var h := hour
	var sv := sun_vec(h)
	var mv := -sv
	night = 1.0 - smoothstep(-0.14, 0.10, sv.y)
	var use_moon := sv.y < -0.04
	var ldir := mv if use_moon else sv
	if absf(sv.y) < 0.04: ldir = Vector3(sv.x, 0.04, sv.z).normalized()
	sun.look_at_from_position(Vector3.ZERO, -ldir, Vector3.UP if absf(ldir.y) < 0.99 else Vector3.RIGHT)
	sun.light_color = _lerp_keys(h, 3)
	var e: float = _lerp_keys(h, 4)
	sun.light_energy = e * 0.62
	env.ambient_light_color = _lerp_keys(h, 5)
	env.ambient_light_energy = _lerp_keys(h, 6) * 0.50
	env.fog_light_color = _lerp_keys(h, 7)
	env.fog_density = _lerp_keys(h, 8) * 0.5
	var sm := sky_mat
	sm.set_shader_parameter("zenith", _lerp_keys(h, 1))
	sm.set_shader_parameter("horizon", _lerp_keys(h, 2))
	sm.set_shader_parameter("ground_c", (_lerp_keys(h, 2) as Color).lerp(Color(0.2, 0.3, 0.3), 0.3))
	sm.set_shader_parameter("sun_c", Color(1.0, 0.92, 0.75) if not use_moon else Color(0.8, 0.85, 1.0))
	sm.set_shader_parameter("sun_dir", sv)
	sm.set_shader_parameter("moon_dir", mv)
	sm.set_shader_parameter("star_vis", _lerp_keys(h, 9))
	sm.set_shader_parameter("cloud_lit", _lerp_keys(h, 10))
	sm.set_shader_parameter("cloud_shade", _lerp_keys(h, 11))
	sm.set_shader_parameter("coverage", _lerp_keys(h, 12))
	sm.set_shader_parameter("t", clock)
	for m in mats:
		m.set_shader_parameter("night", night)

func time_string() -> String:
	var hh := int(hour); var mm := int((hour - hh) * 60.0)
	return "%02d:%02d" % [hh, mm]

extends Node3D

var atmos: Atmos
var terrain: Terrain
var wb: WorldBuild
var cam: Camera3D
var player: Player
var hud: Hud
var npcs: Npcs
var cam_yaw := 0.0
var cam_pitch := 0.28
var cam_dist := 6.8
var cam_target := Vector3.ZERO
var free_cam := false
var region := ""
var region_t := 0.0
var sfx := {}
var petals: GPUParticles3D
var flies: GPUParticles3D
var talk_idx := -1
var near_wp := -1
var near_npc := -1
var auto := ""
var t_acc := 0.0
var opt := {}
var quality := 2
var fps_acc := 0.0
var fps_n := 0
var fps_age := 0.0

func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	for a in args:
		var kv := String(a).split("=", true, 1)
		opt[kv[0].trim_prefix("--")] = kv[1] if kv.size() == 2 else "1"
	WD.load_all()
	atmos = Atmos.new(); add_child(atmos); atmos.setup(self)
	terrain = Terrain.new(); add_child(terrain); terrain.build()
	atmos.mats.append_array([terrain.mat, terrain.water_mat, terrain.grass_mat])
	wb = WorldBuild.new(); add_child(wb); wb.build(atmos)
	cam = Camera3D.new(); cam.fov = 62; cam.far = 1800; cam.near = 0.15; add_child(cam); cam.current = true
	player = Player.new(); add_child(player); player.setup()
	var sp: Array = WD.data["spawn"]
	player.teleport(Vector3(sp[0], WD.height(sp[0], sp[1]) + 0.2, sp[1]))
	if opt.has("at"):
		var c: PackedStringArray = String(opt["at"]).split(",")
		player.teleport(Vector3(float(c[0]), WD.height(float(c[0]), float(c[1])) + 0.2, float(c[1])))
	npcs = Npcs.new(); add_child(npcs); npcs.setup()
	var cl := CanvasLayer.new(); add_child(cl); hud = Hud.new(); cl.add_child(hud)
	hud.jump_pressed.connect(player.press_jump); hud.dash_pressed.connect(player.press_dash)
	hud.sprint_toggled.connect(func(on): player.sprint = on)
	hud.quality_cycle.connect(func(): _set_quality((quality + 2) % 3); hud.show_toast(hud.quality_label)); hud.interact_pressed.connect(_interact); hud.travel.connect(_travel)
	player.jumped.connect(func(): _snd("jump")); player.landed.connect(func(v): _snd("land", clampf(v / 20.0, 0.2, 1.0)))
	player.stepped.connect(func(): _snd("step")); player.dashed.connect(func(): _snd("toggle"))
	_audio(); _particles()
	if opt.has("time"): atmos.hour = float(opt["time"]); atmos.paused = true
	if opt.has("yaw"): cam_yaw = float(opt["yaw"])
	if opt.has("pitch"): cam_pitch = float(opt["pitch"])
	if opt.has("dist"): cam_dist = float(opt["dist"])
	auto = opt.get("auto", "")
	var dbg: String = opt.get("dbg", "")
	if dbg.contains("nofog"): atmos.env.fog_enabled = false
	if opt.has("cam"):
		free_cam = true
		var c: PackedStringArray = String(opt["cam"]).split(",")
		cam.look_at_from_position(Vector3(float(c[0]), float(c[1]), float(c[2])), Vector3(float(c[3]), float(c[4]), float(c[5])))
	_set_quality(2)
	await get_tree().create_timer(0.8).timeout
	hud.show_banner("Hoshi no Sato")
	if opt.has("shot"):
		await get_tree().create_timer(float(opt.get("wait", 6))).timeout
		get_viewport().get_texture().get_image().save_png(opt["shot"])
		print("SHOT ", opt["shot"], " pos=", player.position, " fps=", Engine.get_frames_per_second()); get_tree().quit()

func _audio() -> void:
	var defs := {"jump": "jump", "land": "land", "coin": "coin", "toggle": "toggle", "pick": "placement-a", "step": "walking", "ui": "placement-b"}
	for k in defs:
		var p := AudioStreamPlayer.new(); p.stream = load("res://assets/sfx/%s.ogg" % defs[k]); p.bus = "Master"; add_child(p); sfx[k] = p
	(sfx["step"] as AudioStreamPlayer).volume_db = -10.0
	var amb := AudioStreamPlayer.new(); var s: AudioStream = load("res://assets/sfx/ambience.ogg")
	if s is AudioStreamOggVorbis: (s as AudioStreamOggVorbis).loop = true
	amb.stream = s; amb.volume_db = -12.0; add_child(amb); amb.play()
	if ResourceLoader.exists("res://assets/sfx/bgm.ogg"):
		var bg := AudioStreamPlayer.new(); var bs: AudioStream = load("res://assets/sfx/bgm.ogg")
		if bs is AudioStreamOggVorbis: (bs as AudioStreamOggVorbis).loop = true
		bg.stream = bs; bg.volume_db = -9.0; add_child(bg); bg.play()

func _snd(n: String, vol := 1.0) -> void:
	var p: AudioStreamPlayer = sfx[n]
	p.pitch_scale = randf_range(0.92, 1.08) if n == "step" else 1.0
	if n != "step": p.volume_db = linear_to_db(vol) - 3.0
	p.play()

func _particles() -> void:
	petals = GPUParticles3D.new(); petals.amount = 260; petals.lifetime = 9.0; petals.preprocess = 9.0
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX; pm.emission_box_extents = Vector3(32, 1, 32)
	pm.direction = Vector3(0.3, -1, 0.1); pm.spread = 18.0; pm.initial_velocity_min = 0.4; pm.initial_velocity_max = 1.2
	pm.gravity = Vector3(0.7, -0.6, 0.25); pm.angular_velocity_min = -200.0; pm.angular_velocity_max = 200.0
	pm.turbulence_enabled = true; pm.turbulence_noise_strength = 0.6
	petals.process_material = pm
	var q := QuadMesh.new(); q.size = Vector2(0.13, 0.13)
	var m := StandardMaterial3D.new(); m.albedo_color = Color(1.0, 0.74, 0.84); m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED; m.cull_mode = BaseMaterial3D.CULL_DISABLED; q.material = m
	petals.draw_pass_1 = q; petals.visibility_aabb = AABB(Vector3(-40, -20, -40), Vector3(80, 30, 80)); petals.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(petals)
	flies = GPUParticles3D.new(); flies.amount = 90; flies.lifetime = 6.0; flies.preprocess = 6.0
	var fm := ParticleProcessMaterial.new()
	fm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX; fm.emission_box_extents = Vector3(24, 1.5, 24)
	fm.gravity = Vector3.ZERO; fm.initial_velocity_min = 0.1; fm.initial_velocity_max = 0.5; fm.direction = Vector3.UP; fm.spread = 180.0
	fm.turbulence_enabled = true; fm.turbulence_noise_strength = 0.8
	var gr := Gradient.new(); gr.set_color(0, Color(1, 1, 1, 0)); gr.add_point(0.5, Color(1, 1, 1, 1)); gr.set_color(2 if false else 1, Color(1, 1, 1, 0))
	var gt := GradientTexture1D.new(); gt.gradient = gr; fm.color_ramp = gt
	flies.process_material = fm
	var fq := QuadMesh.new(); fq.size = Vector2(0.12, 0.12)
	var fmat := StandardMaterial3D.new(); fmat.albedo_color = Color(0.8, 1.0, 0.5); fmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED; fmat.vertex_color_use_as_albedo = true; fmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fmat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD; fq.material = fmat
	flies.draw_pass_1 = fq; flies.visibility_aabb = AABB(Vector3(-40, -5, -40), Vector3(80, 15, 80)); flies.emitting = false
	add_child(flies)

func _set_quality(q: int) -> void:
	quality = q
	hud.quality_label = "Grafik: " + ["Rendah", "Sedang", "Tinggi"][q]
	var vp := get_viewport()
	vp.scaling_3d_scale = [0.62, 0.8, 1.0][q]
	atmos.sun.directional_shadow_max_distance = [60.0, 90.0, 130.0][q]
	atmos.sun.shadow_enabled = q > 0
	petals.amount = [60, 140, 260][q]

func _interact() -> void:
	if near_npc >= 0:
		talk_idx = near_npc; hud.say(npcs.data[near_npc]["name"], npcs.say_line(near_npc)); _snd("ui")
	elif near_wp >= 0:
		_open_map()

func _open_map() -> void:
	var names := []; var found := []
	for w in wb.waypoints: names.append(w["name"]); found.append(w["found"])
	hud.open_menu(names, found)

func _travel(i: int) -> void:
	var w: Dictionary = wb.waypoints[i]; var p: Vector3 = w["pos"]
	player.teleport(Vector3(p.x + 3.0, p.y + 0.3, p.z + 3.0)); cam_yaw = 0.0
	hud.show_toast("Teleport: " + w["name"]); _snd("toggle")

func _region_name(p: Vector3) -> String:
	var cc: Array = WD.data["city"]["c"]; var vc: Array = WD.data["village_center"]; var sh: Array = WD.data["shrine"]
	var br: Dictionary = WD.data["bridge"]
	if Vector2(p.x - sh[0], p.z - sh[1]).length() < 40.0: return "Kuil Hoshi"
	if Vector2(p.x - cc[0], p.z - cc[1]).length() < 190.0: return "Hoshimachi - Kota"
	if Vector2(p.x - vc[0], p.z - vc[1]).length() < 130.0: return "Desa Sakura no Sato"
	if absf(p.x - br["x"]) < 40.0 and absf(p.z - br["z"]) < 25.0: return "Sungai Mizu"
	if p.y > 60.0: return "Pegunungan Tsuki"
	return "Padang Harumi"

func _process(dt: float) -> void:
	dt = minf(dt, 0.1)
	if not free_cam:
		# input
		var mv := hud.get_move()
		match auto:
			"walk": mv = Vector2(0, 0.5)
			"run": mv = Vector2(0, 1.0)
			"jump":
				mv = Vector2(0, 0.0)
				t_acc += dt
				if t_acc > 0.6 and t_acc < 0.7: player.press_jump()
			"menu":
				t_acc += dt
				if t_acc > 0.5 and t_acc < 0.6: _open_map()
			"glide":
				mv = Vector2(0, 1.0); t_acc += dt
				if (t_acc > 0.5 and t_acc < 0.55) or (t_acc > 1.1 and t_acc < 1.15) or (t_acc > 1.7 and t_acc < 1.75): player.press_jump()
		player.move = mv
		player.cam_yaw = cam_yaw
		cam_yaw -= hud.look.x * 0.0055; cam_pitch = clampf(cam_pitch + hud.look.y * 0.004, -0.35, 1.25); hud.look = Vector2.ZERO
		player.update(dt)
		hud.heading = cam_yaw
		# kamera orbit
		var tgt := player.position + Vector3(0, 1.45, 0)
		cam_target = cam_target.lerp(tgt, 1.0 - exp(-dt * 12.0))
		var dist := cam_dist * (1.25 if player.gliding else 1.0)
		var off := Vector3(sin(cam_yaw) * cos(cam_pitch), sin(cam_pitch), cos(cam_yaw) * cos(cam_pitch)) * dist
		var lim := 1.0
		for k in range(1, 9):
			var q := cam_target + off * (k / 8.0)
			var rr := Coll.resolve(q, 0.45, q.y)
			if Vector2(rr.x - q.x, rr.y - q.z).length() > 0.02: lim = maxf((k - 1) / 8.0, 0.22); break
		var cp := cam_target + off * lim
		cp.y = maxf(cp.y, WD.height(cp.x, cp.z) + 0.7)
		cam.global_position = cp
		cam.look_at(cam_target + Vector3(0, 0.15, 0), Vector3.UP)
		if hud.map_req: hud.map_req = false; _open_map()
	var pp := player.position
	var cam_pos := cam.global_position
	terrain.update_focus(cam_pos, pp)
	npcs.update(dt, pp, talk_idx if hud.say_t > 0.0 else -1)
	npcs.night(atmos.night)
	player.avatar.set_night(atmos.night)
	petals.global_position = Vector3(pp.x, pp.y + 11.0, pp.z)
	flies.global_position = Vector3(pp.x, pp.y + 1.5, pp.z)
	flies.emitting = atmos.night > 0.4
	# kristal & waypoint
	wb.update_crystals(Time.get_ticks_msec() * 0.001)
	for i in wb.crystal_pos.size():
		if not wb.crystal_taken[i] and (wb.crystal_pos[i] as Vector3).distance_to(pp + Vector3(0, 1.0, 0)) < 1.9:
			wb.crystal_taken[i] = true; hud.crystals += 1; _snd("coin"); hud.show_toast("Kristal +1  (%d)" % hud.crystals)
	near_wp = -1
	for i in wb.waypoints.size():
		var w: Dictionary = wb.waypoints[i]
		var d := (w["pos"] as Vector3).distance_to(pp)
		if d < 7.0: near_wp = i
		if d < 4.0 and not w["found"]:
			w["found"] = true; hud.show_toast("Titik teleport aktif: " + w["name"], 3.5); _snd("pick")
	near_npc = npcs.nearest(pp, 3.2)
	hud.interact_label = "BICARA" if near_npc >= 0 else ("TELEPORT" if near_wp >= 0 else "")
	# lokasi
	region_t -= dt
	var rn := _region_name(pp)
	if rn != region and region_t <= 0.0:
		region = rn; region_t = 6.0; hud.show_banner(rn)
	hud.time_text = atmos.time_string()
	hud.fps_text = "%d FPS" % Engine.get_frames_per_second()
	# kualitas otomatis: kalau terus di bawah 24 FPS, turunkan satu tingkat
	fps_acc += dt; fps_n += 1; fps_age += dt
	if fps_acc >= 5.0:
		var avg := fps_n / fps_acc
		if fps_age > 8.0 and avg < 24.0 and quality > 0 and not opt.has("shot"):
			_set_quality(quality - 1); hud.show_toast("Grafik diturunkan otomatis: " + hud.quality_label, 3.5)
		fps_acc = 0.0; fps_n = 0
	if Input.is_key_pressed(KEY_BRACKETRIGHT): cam_dist = clampf(cam_dist + dt * 4.0, 3.0, 14.0)

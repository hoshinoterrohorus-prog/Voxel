#!/usr/bin/env python3
"""Bake dunia: heightmap (16bit di RG), splatmap, dan world.json (penempatan objek).
Jalankan: python3 tools/bake_world.py  (hasil sudah dikomit di assets/world)"""
import json, math, os
import numpy as np
from PIL import Image
from scipy.ndimage import zoom, gaussian_filter, distance_transform_edt

RNG = np.random.default_rng(20261112)
N = 1024                 # resolusi heightmap
HALF = 640.0             # dunia: [-640, 640] meter
PX = 2 * HALF / N        # 1.25 m / px
OUT = os.path.join(os.path.dirname(__file__), '..', 'assets', 'world')
os.makedirs(OUT, exist_ok=True)

CITY_C = np.array([-250.0, -40.0]); CITY_R = 170.0
VIL_C = np.array([250.0, 140.0]); VIL_R = 105.0
WATER_Y = -0.6
H_MIN, H_MAX = -8.0, 160.0

xs = (np.arange(N) + 0.5) * PX - HALF
X, Z = np.meshgrid(xs, xs)       # X[j,i] , Z[j,i]  -> baris = z, kolom = x


def fbm(seed, scale, octaves=5, gain=0.5):
    r = np.random.default_rng(seed)
    out = np.zeros((N, N)); amp = 1.0; tot = 0.0
    for o in range(octaves):
        g = max(2, int(N / scale * (2 ** o)))
        a = r.random((g + 3, g + 3))
        up = zoom(a, N / g, order=3)[:N, :N]
        out += (up - 0.5) * 2 * amp; tot += amp; amp *= gain
    return out / tot


def smooth(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def river_x(z):
    return 30.0 + 55.0 * np.sin(z / 170.0) + 22.0 * np.sin(z / 63.0 + 1.3)


# ---------- tinggi ----------
roll = fbm(1, 260, 5) * 6.0 + fbm(2, 90, 3) * 1.6
h = 4.0 + roll
edge = np.maximum(np.abs(X), np.abs(Z))
ridge = 1 - np.abs(fbm(3, 200, 4))
mt = smooth(360, 600, edge)
h += mt * mt * (70 + ridge * 70 + fbm(4, 120, 3) * 20)
# bukit di antara kota dan sungai, dan di sisi utara desa
h += smooth(0.1, 0.9, fbm(5, 300, 3)) * 10 * (1 - smooth(300, 420, edge))
dc = np.hypot(X - CITY_C[0], Z - CITY_C[1])
h = h * (1 - (1 - smooth(CITY_R, CITY_R + 70, dc))) + 3.0 * (1 - smooth(CITY_R, CITY_R + 70, dc))
dv = np.hypot(X - VIL_C[0], Z - VIL_C[1])
wv = 1 - smooth(VIL_R, VIL_R + 55, dv)
h = h * (1 - wv) + (5.0 + roll * 0.25) * wv
# tepi sungai rata, lalu alur sungai
rd = np.abs(X - river_x(Z))
bank = 1 - smooth(18, 70, rd)
h = h * (1 - bank) + 3.4 * bank + roll * 0.15 * bank
carve = 1 - smooth(6, 21, rd)
h = h * (1 - carve) + (-2.6) * carve
# danau di desa
lake_c = VIL_C + np.array([-65.0, 70.0]); dl = np.hypot(X - lake_c[0], Z - lake_c[1])
carve2 = 1 - smooth(14, 34, dl)
h = h * (1 - carve2) + (-2.2) * carve2
h = gaussian_filter(h, 0.8)
H = h.copy()

# ---------- jalan setapak (polyline) ----------
road_pts = [(-85, -20), (-30, -6), (10, 4), (32, 8), (70, 22), (130, 60), (190, 105), (235, 130)]
village_paths = [
    [(235, 130), (250, 140), (275, 150), (320, 160)],
    [(250, 140), (236, 175), (222, 205)],
    [(250, 140), (212, 128), (170, 120)],
    [(275, 150), (300, 120), (330, 100)],
    [(190, 105), (165, 80), (150, 40), (160, 0)],
]


def seg_dist(px, pz, a, b):
    ax, az = a; bx, bz = b
    vx, vz = bx - ax, bz - az
    t = np.clip(((px - ax) * vx + (pz - az) * vz) / (vx * vx + vz * vz + 1e-9), 0, 1)
    return np.hypot(px - (ax + t * vx), pz - (az + t * vz))


def poly_dist(px, pz, pts):
    d = np.full(px.shape, 1e9)
    for a, b in zip(pts[:-1], pts[1:]):
        d = np.minimum(d, seg_dist(px, pz, a, b))
    return d

dpath = poly_dist(X, Z, road_pts)
for p in village_paths:
    dpath = np.minimum(dpath, poly_dist(X, Z, p))

# ---------- splat ----------
path_mask = 1 - smooth(1.6, 3.4, dpath)
path_mask *= (1 - carve)
# ladang di sekeliling desa
cell = 26.0
ci = np.floor((X - VIL_C[0]) / cell); cj = np.floor((Z - VIL_C[1]) / cell)
hv = (np.sin(ci * 12.9898 + cj * 78.233) * 43758.5453) % 1.0
field_zone = smooth(VIL_R - 25, VIL_R + 10, dv) * (1 - smooth(VIL_R + 70, VIL_R + 110, dv))
field = ((hv > 0.38) & (field_zone > 0.5) & (carve < 0.01) & (carve2 < 0.01)).astype(float)
# beri celah antar petak
fx = ((X - VIL_C[0]) / cell) % 1.0; fz = ((Z - VIL_C[1]) / cell) % 1.0
gap = (fx < 0.07) | (fx > 0.93) | (fz < 0.07) | (fz > 0.93)
field = field * (~gap) * (1 - path_mask > 0.5)
sand = smooth(0.4, -0.6, H) * 1.0          # dekat air
city_m = 1 - smooth(CITY_R - 5, CITY_R + 25, dc)
splat = np.stack([path_mask, field, np.clip(sand, 0, 1), city_m], -1)

# ---------- simpan peta ----------
hn = np.clip((H - H_MIN) / (H_MAX - H_MIN), 0, 1)
v16 = np.round(hn * 65535).astype(np.uint32)
img = np.zeros((N, N, 3), np.uint8)
img[..., 0] = (v16 >> 8) & 255; img[..., 1] = v16 & 255
Image.fromarray(img, 'RGB').save(os.path.join(OUT, 'height.png'))
Image.fromarray((splat * 255).astype(np.uint8), 'RGBA').save(os.path.join(OUT, 'splat.png'))


def hq(x, z):
    i = np.clip(((np.asarray(x) + HALF) / PX - 0.5), 0, N - 1.001); j = np.clip(((np.asarray(z) + HALF) / PX - 0.5), 0, N - 1.001)
    i0 = np.floor(i).astype(int); j0 = np.floor(j).astype(int); fi = i - i0; fj = j - j0
    a = H[j0, i0] * (1 - fi) + H[j0, i0 + 1] * fi
    b = H[j0 + 1, i0] * (1 - fi) + H[j0 + 1, i0 + 1] * fi
    return a * (1 - fj) + b * fj


def sample(m, x, z):
    i = int(np.clip((x + HALF) / PX, 0, N - 1)); j = int(np.clip((z + HALF) / PX, 0, N - 1))
    return m[j, i]

# slope
gy, gx = np.gradient(H, PX)
SLOPE = np.hypot(gx, gy)

world = {'half': HALF, 'n': N, 'hmin': H_MIN, 'hmax': H_MAX, 'water_y': WATER_Y,
         'city': {'c': CITY_C.tolist(), 'r': CITY_R}, 'village': {'c': VIL_C.tolist(), 'r': VIL_R}}

# ---------- kota: grid jalan ----------
CELL = 64.0; RW = 13.0
world['city']['cell'] = CELL; world['city']['road_w'] = RW
buildings = []; lamps = []; street_trees = []; benches = []
npc_spawns = []
n = int(CITY_R // CELL) + 2
for gi in range(-n, n):
    for gj in range(-n, n):
        # blok antara jalan: pusat blok
        bx = CITY_C[0] + (gi + 0.5) * CELL; bz = CITY_C[1] + (gj + 0.5) * CELL
        d = math.hypot(bx - CITY_C[0], bz - CITY_C[1])
        if d > CITY_R - 22: continue
        if abs(bx - river_x(bz)) < 40: continue
        center = 1 - d / CITY_R            # 1 di pusat
        bs = CELL - RW                      # lebar blok bersih
        park = (gi * 7 + gj * 13) % 11 == 0 and d > 30
        if park:
            for k in range(7):
                a = RNG.random() * 2 * math.pi; r = RNG.random() * 18
                street_trees.append((bx + math.cos(a) * r, bz + math.sin(a) * r, 0))
            benches.append((bx, bz))
            continue
        # 2x2 lot
        for li in range(2):
            for lj in range(2):
                lw = bs / 2 - 2.5
                lx = bx + (li - 0.5) * (bs / 2); lz = bz + (lj - 0.5) * (bs / 2)
                if RNG.random() < 0.08: continue
                w = lw * RNG.uniform(0.72, 1.0); dd = lw * RNG.uniform(0.72, 1.0)
                tall = center ** 1.4
                hh = 7 + tall * RNG.uniform(25, 85) + RNG.random() * 8
                if RNG.random() < 0.25: hh *= 0.55
                buildings.append({'x': round(lx, 2), 'z': round(lz, 2), 'w': round(w, 2), 'd': round(dd, 2), 'h': round(hh, 2),
                                  'c': int(RNG.integers(0, 8)), 'roof': int(RNG.integers(0, 3))})
    # lampu & pohon di sisi jalan dilakukan di bawah
# lampu jalan + pohon jalan sepanjang garis jalan
for gi in range(-n, n + 1):
    for gj in range(-n, n + 1):
        px = CITY_C[0] + gi * CELL; pz = CITY_C[1] + gj * CELL
        # persimpangan: lampu di sudut
        for sx in (-1, 1):
            for sz in (-1, 1):
                x = px + sx * (RW / 2 + 1.2); z = pz + sz * (RW / 2 + 1.2)
                if math.hypot(x - CITY_C[0], z - CITY_C[1]) < CITY_R - 20 and abs(x - river_x(z)) > 36:
                    lamps.append((round(x, 1), round(z, 1)))
for gi in range(-n, n + 1):
    for gj in range(-n, n + 1):
        px = CITY_C[0] + gi * CELL; pz = CITY_C[1] + gj * CELL
        for t in (0.3, 0.7):
            for (x, z) in ((px + (t - 0.5) * CELL + 0, pz + RW / 2 + 1.0), (px + (t - 0.5) * CELL, pz - RW / 2 - 1.0),
                           (px + RW / 2 + 1.0, pz + (t - 0.5) * CELL), (px - RW / 2 - 1.0, pz + (t - 0.5) * CELL)):
                if math.hypot(x - CITY_C[0], z - CITY_C[1]) < CITY_R - 24 and abs(x - river_x(z)) > 36 and RNG.random() < 0.55:
                    street_trees.append((x, z, 1))
        if math.hypot(px - CITY_C[0], pz - CITY_C[1]) < CITY_R - 30 and abs(px - river_x(pz)) > 40:
            npc_spawns.append(('city', px + RNG.uniform(-9, 9), pz + RNG.uniform(-9, 9)))

world['buildings'] = buildings
world['lamps'] = lamps
world['benches'] = [(round(a, 1), round(b, 1)) for a, b in benches]

# ---------- desa ----------
houses = []
vc = VIL_C
ring = []
for a in np.linspace(0, 2 * math.pi, 15, endpoint=False):
    for rr, jit in ((36, 6), (62, 8)):
        ring.append((vc[0] + math.cos(a) * (rr + RNG.uniform(-jit, jit)), vc[1] + math.sin(a) * (rr + RNG.uniform(-jit, jit))))
for (x, z) in ring:
    if dpath[int(np.clip((z + HALF) / PX, 0, N - 1)), int(np.clip((x + HALF) / PX, 0, N - 1))] < 6: continue
    if sample(carve2, x, z) > 0.001 or sample(carve, x, z) > 0.001: continue
    if sample(field, x, z) > 0.2: continue
    # hadap ke pusat desa
    rot = math.atan2(vc[0] - x, vc[1] - z)
    houses.append({'x': round(x, 2), 'z': round(z, 2), 'rot': round(rot, 3), 'w': round(RNG.uniform(7, 10), 1), 'd': round(RNG.uniform(6, 8), 1),
                   'roof': int(RNG.integers(0, 3)), 'wall': int(RNG.integers(0, 3))})
    if RNG.random() < 0.5:
        npc_spawns.append(('village', x + math.sin(rot) * 6, z + math.cos(rot) * 6))
world['houses'] = houses
world['village_center'] = vc.tolist()
# kuil di bukit timur laut desa
shrine = (vc[0] + 70.0, vc[1] - 82.0)
world['shrine'] = [round(shrine[0], 1), round(shrine[1], 1)]
# jembatan
bz = 0.0
world['bridge'] = {'x': round(float(river_x(2.0)), 1), 'z': 2.0, 'rot': 0.0, 'len': 48.0}
world['road_pts'] = road_pts
world['village_paths'] = village_paths

# ---------- pohon (hutan, tepi sungai, desa, taman) ----------
trees = []
forest = fbm(77, 140, 3)
for _ in range(9000):
    x = RNG.uniform(-HALF + 20, HALF - 20); z = RNG.uniform(-HALF + 20, HALF - 20)
    i = int(np.clip((x + HALF) / PX, 0, N - 1)); j = int(np.clip((z + HALF) / PX, 0, N - 1))
    if H[j, i] < 0.0 or H[j, i] > 70: continue
    if SLOPE[j, i] > 0.55: continue
    if splat[j, i, 0] > 0.12 or splat[j, i, 1] > 0.1 or splat[j, i, 3] > 0.02: continue
    dens = forest[j, i]
    if np.hypot(x - vc[0], z - vc[1]) < 44: continue
    near_vil = np.hypot(x - vc[0], z - vc[1]) < VIL_R + 40
    p = 0.15 + max(0, dens) * 1.3 + (0.2 if near_vil else 0)
    if RNG.random() > min(1.0, p * 0.7): continue
    alt = H[j, i]
    kind = 1 if alt > 22 else (0 if RNG.random() < 0.28 + (0.3 if near_vil else 0) else 2)
    trees.append((round(x, 1), round(z, 1), kind, round(RNG.uniform(0.8, 1.35), 2)))
world['trees'] = trees
world['street_trees'] = [(round(a, 1), round(b, 1)) for a, b, _ in street_trees]
# bunga sakura di sepanjang jalan desa
for p in village_paths + [road_pts[4:]]:
    for a, b in zip(p[:-1], p[1:]):
        L = math.hypot(b[0] - a[0], b[1] - a[1])
        for t in np.arange(8, L, 14):
            f = t / L; x = a[0] + (b[0] - a[0]) * f; z = a[1] + (b[1] - a[1]) * f
            nx = -(b[1] - a[1]) / L; nz = (b[0] - a[0]) / L; s = 5.5 if RNG.random() < .5 else -5.5
            tx, tz = x + nx * s, z + nz * s
            if sample(carve, tx, tz) > 0.001 or sample(carve2, tx, tz) > 0.001 or sample(field, tx, tz) > 0.2: continue
            if H[int(np.clip((tz + HALF) / PX, 0, N - 1)), int(np.clip((tx + HALF) / PX, 0, N - 1))] < 0.5: continue
            world['trees'].append((round(tx, 1), round(tz, 1), 0, round(RNG.uniform(1.0, 1.4), 2)))

# ---------- waypoint, kristal ----------
world['waypoints'] = [
    {'name': 'Menara Kota Hoshimachi', 'x': float(CITY_C[0] + 8), 'z': float(CITY_C[1] + 8)},
    {'name': 'Jembatan Sungai Mizu', 'x': float(river_x(2.0) + 6), 'z': 10.0},
    {'name': 'Alun-alun Sakura no Sato', 'x': float(vc[0] + 8), 'z': float(vc[1] + 8)},
    {'name': 'Kuil Bukit Angin', 'x': float(shrine[0] - 6), 'z': float(shrine[1] + 8)},
    {'name': 'Tepi Danau Tsuki', 'x': float(lake_c[0] + 40), 'z': float(lake_c[1] - 6)},
]
crystals = []
tries = 0
while len(crystals) < 70 and tries < 5000:
    tries += 1
    x = RNG.uniform(-480, 480); z = RNG.uniform(-480, 480)
    i = int(np.clip((x + HALF) / PX, 0, N - 1)); j = int(np.clip((z + HALF) / PX, 0, N - 1))
    if H[j, i] < 0.2 or SLOPE[j, i] > 0.7: continue
    crystals.append((round(x, 1), round(z, 1)))
world['crystals'] = crystals

# npc di sekitar jalan desa & kota
npc = []
for kind, x, z in npc_spawns:
    j = int(np.clip((z + HALF) / PX, 0, N - 1)); i = int(np.clip((x + HALF) / PX, 0, N - 1))
    if H[j, i] < 0.3: continue
    npc.append({'zone': kind, 'x': round(x, 1), 'z': round(z, 1)})
RNG.shuffle(npc)
world['npcs'] = npc[:44]

# titik mulai pemain: alun-alun kota
world['spawn'] = [float(CITY_C[0] + 6), float(CITY_C[1] + 14)]
json.dump(world, open(os.path.join(OUT, 'world.json'), 'w'))
print('ok', len(buildings), 'gedung', len(houses), 'rumah', len(trees), 'pohon', len(npc), 'npc', len(lamps), 'lampu')
print('tinggi min/max', H.min(), H.max(), 'kota h', hq(CITY_C[0], CITY_C[1]), 'desa h', hq(vc[0], vc[1]))

#!/bin/bash
cd "$(dirname "$0")"
python3 - <<'PY'
t=open('index.tpl.html').read()
rd=lambda f:open(f).read().replace('</script','<\\/script')
game=''.join(rd('js/'+f)+'\n' for f in ['px.js','map.js','interiors.js','net.js','game.js'])
t=t.replace('/*CSS*/',open('css/style.css').read()).replace('/*GAME*/',game)
open('out.html','w').write(t);print(len(t))
PY

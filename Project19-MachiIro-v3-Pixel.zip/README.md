# Machi-Iro 街色 v3 (2D pixel)
Semua grafis digambar lewat kode (tanpa aset luar). Database: Firebase Realtime DB (URL tertanam di js/game.js, DEFAULT_DB; bisa ditimpa ?db=URL).
Tes tanpa server: buka out.html?offline=1  |  tes lokal: node tools/mockdb.js 9000 lalu ?db=http://localhost:9000
Build: ./build.sh -> out.html

/* ===== PETA KOTA (tile 16px) — dibangun deterministik, sama di semua pemain ===== */
const CELLW=18,CELLH=16,NX=6,NY=5,OY=6,W=NX*CELLW,H=OY+NY*CELLH;
const PONDS=[],solid=new Uint8Array(W*H),doors=new Map(),objs=[],LOTS=[],LOTBYID=new Map(),NODES=[],stat=[]; // stat: staff diam di luar
const [mapCv,sx]=mk(W*T,H*T);
const ix=(x,y)=>y*W+x;
const SPR={sakura:[0,1,2,3].map(i=>mkTree('sakura',100+i)),tree:[0,1,2].map(i=>mkTree('tree',200+i)),lamp:mkLamp(),vend:['#e0524f','#4a7fe0','#38bfc9','#f2c230'].map(mkVend),bench:mkBench(),torii:mkTorii(),lantern:mkLantern(),stall:mkStall()};
const blockOrigin=(i,j)=>({x:i*CELLW+2,y:OY+j*CELLH+2});
function addObj(s,px,py,solidTile){objs.push({x:px,y:py,s});if(solidTile)solid[ix(Math.floor(px/T),Math.floor((py-1)/T))]=1;}
function setSolid(x,y,w,h,v){for(let j=0;j<h;j++)for(let i=0;i<w;i++)solid[ix(x+i,y+j)]=v===undefined?1:v;}
const tileCenter=(x,y)=>[x*T+8,y*T+8];

/* ---------- papan nama toko ---------- */
const SHOPS=[['ラーメン','#d9382e'],['居酒屋','#8a3a2a'],['カラオケ','#8a3ad9'],['ゲーム','#2a6ad9'],['薬局','#2aa66a'],['寿司','#e0523a'],['喫茶','#8a5a3a'],['本屋','#3a6a8a'],['弁当','#d9902a'],['パン','#d9a05a'],['花屋','#d95a8a'],['電器','#3a8ad9']];
const ROOFS=['#c0504a','#4a6aa8','#4a8a6a','#8a5a4a','#6a5a9a','#9a7a3a','#5a6a78'],WALLS=['#f4ead4','#e8f0f4','#f4dcd4','#e4f0d8','#f0e4c4','#dcdcf0','#f4e0e8','#e6e6ea'];

function paintBuilding(c,X,Y,w,h,o){const Wd=w*T,Hd=h*T,wr=o.wr||2,wallH=wr*T,roofH=Hd-wallH,wc=o.wc||'#f4ead4',rc=o.rc||'#c0504a';
 R(c,'rgba(40,20,60,.22)',X+Wd,Y+8,5,Hd-4);R(c,'rgba(40,20,60,.22)',X+5,Y+Hd,Wd,4);
 // dinding
 R(c,wc,X,Y+roofH,Wd,wallH);R(c,shade(wc,-.12),X,Y+Hd-3,Wd,3);
 // atap
 if(o.roof==='flat'){R(c,'#c9cbd6',X,Y,Wd,roofH);R(c,'#9a9db2',X,Y,Wd,3);R(c,'#9a9db2',X,Y+roofH-3,Wd,3);R(c,'#9a9db2',X,Y,3,roofH);R(c,'#9a9db2',X+Wd-3,Y,3,roofH);R(c,'#b4b7c8',X+3,Y+3,Wd-6,1);
  const r=mulberry32(o.seed||1);for(let i=0;i<2+(r()*2|0);i++){const bx=X+8+r()*(Wd-30),by=Y+6+r()*Math.max(1,roofH-18);if(r()<.5){R(c,INK,bx-1,by-1,14,11);R(c,'#e8e8f0',bx,by,12,9);R(c,'#aab',bx+2,by+2,8,5);R(c,'#778',bx+3,by+3,6,1);R(c,'#778',bx+3,by+5,6,1);}else{R(c,INK,bx-1,by-1,12,12);R(c,'#8a9ab0',bx,by,10,10);R(c,'#a8b8cc',bx+1,by+1,4,8);R(c,'#6a7a90',bx+7,by+1,2,8);}}
  if(o.kindTag==='apt'){R(c,rc,X+Wd-26,Y+5,20,10);R(c,shade(rc,-.25),X+Wd-26,Y+13,20,2);}}
 else{R(c,rc,X,Y,Wd,roofH);const dk=shade(rc,-.2),lt=shade(rc,.2);for(let yy=0;yy<roofH-4;yy+=4){R(c,dk,X,Y+yy+3,Wd,1);for(let xx=(yy/4%2)*4;xx<Wd;xx+=8)R(c,shade(rc,-.1),X+xx,Y+yy,1,4);}
  R(c,lt,X,Y,Wd,3);R(c,shade(rc,.35),X,Y,Wd,1);R(c,dk,X,Y,3,roofH);R(c,dk,X+Wd-3,Y,3,roofH);R(c,shade(rc,-.4),X,Y+roofH-3,Wd,3);
  if(o.gable){R(c,lt,X+Wd/2-2,Y,4,roofH);}}
 // bayangan di bawah atap
 R(c,'rgba(0,0,0,.18)',X,Y+roofH,Wd,3);
 const dc=o.dc===undefined?(w>>1):o.dc,dx=X+dc*T+2,wy=Y+roofH;
 const win=(a,b,ww,hh)=>{R(c,INK,a-1,b-1,ww+2,hh+2);R(c,'#ffffff',a,b,ww,hh);R(c,'#9fd6f2',a+1,b+1,ww-2,hh-2);R(c,'#cfeeff',a+1,b+1,ww-2,3);R(c,'#fff',a+2,b+2,2,2);R(c,'#fff',a+(ww>>1),b+1,1,hh-2);R(c,'#7fb6d4',a+1,b+hh-3,ww-2,2);if(o.curtain)R(c,o.curtain,a+1,b+1,3,hh-2);};
 if(o.shop){ // papan nama, kanopi, etalase
  const sg=o.shop;R(c,INK,X+2,wy+1,Wd-4,13);R(c,sg[1],X+3,wy+2,Wd-6,11);R(c,shade(sg[1],.3),X+3,wy+2,Wd-6,2);drawText(c,sg[0],X+Wd/2,wy+2,'#fff',shade(sg[1],-.45));
  const aw=o.awn||['#fff',sg[1]];for(let i=0;i<Wd;i+=6){R(c,aw[(i/6|0)%2],X+i,wy+14,6,6);}R(c,'rgba(0,0,0,.2)',X,wy+19,Wd,2);for(let i=0;i<Wd;i+=6)R(c,aw[(i/6|0)%2],X+i,wy+20,6,2);
  const gy=wy+22;for(let i=0;i<w;i++){if(i===dc)continue;R(c,INK,X+i*T+1,gy-1,T-2,11);R(c,'#aee0f8',X+i*T+2,gy,T-4,9);R(c,'#e8f6ff',X+i*T+2,gy,T-4,2);const gc=['#e0524f','#f2c230','#4cb87a','#4a7fe0'];R(c,gc[(i+(o.seed|0))%4],X+i*T+4,gy+5,3,4);R(c,gc[(i+2+(o.seed|0))%4],X+i*T+9,gy+4,3,5);}
 }else if(o.kind==='school'){for(let i=0;i<w;i++){if(i===dc)continue;if(i%2===0)win(X+i*T+3,wy+8,10,14),win(X+i*T+3,wy+wallH-18,10,12);else{}}}
 else{for(let i=0;i<w;i++){if(i===dc)continue;if(i%2===(o.alt|0)||w<4)win(X+i*T+3,wy+6,10,12);if(wr>2)win(X+i*T+3,wy+wallH-20,10,12);}}
 // pintu
 const dh=o.dh||16,dy=Y+Hd-dh-1;if(o.door!==false){R(c,INK,dx-1,dy-1,T-2,dh+1);R(c,o.doorCol||'#8a5a3a',dx,dy,T-4,dh);R(c,shade(o.doorCol||'#8a5a3a',.2),dx,dy,T-4,2);if(o.shop||o.glassDoor){R(c,'#aee0f8',dx+1,dy+2,T-6,dh-5);R(c,'#e8f6ff',dx+1,dy+2,T-6,2);}else{R(c,'#f2c230',dx+T-8,dy+dh/2,2,2);R(c,shade(o.doorCol||'#8a5a3a',-.25),dx+1,dy+3,T-6,dh-5);}
  R(c,'#cfc6b4',dx-2,Y+Hd-1,T,1);}
 if(o.extra==='lantern'){for(const lx of[dx-8,dx+T-2]){R(c,INK,lx,dy+1,6,9);R(c,'#e0382e',lx+1,dy+2,4,7);R(c,'#ffd27a',lx+2,dy+4,2,3);}}
 if(o.extra==='cross'){R(c,INK,X+Wd-18,wy+3,14,14);R(c,'#fff',X+Wd-17,wy+4,12,12);R(c,'#2aa66a',X+Wd-13,wy+5,4,10);R(c,'#2aa66a',X+Wd-16,wy+8,10,4);}
 if(o.extra==='koban'){R(c,INK,X+Wd/2-5,wy-9,10,10);R(c,'#e0382e',X+Wd/2-4,wy-8,8,8);R(c,'#ff8a80',X+Wd/2-3,wy-7,3,3);R(c,'#2a3f8f',X+2,wy+2,Wd-4,5);drawText(c,'交番',X+Wd/2,wy-1,'#fff','#1a2a6f');}
 if(o.extra==='clock'){const cx=X+Wd/2,cy=Y+roofH/2;R(c,INK,cx-9,cy-9,18,18);R(c,'#fff',cx-8,cy-8,16,16);R(c,INK,cx,cy-6,1,6);R(c,INK,cx,cy,5,1);}
 if(o.extra==='stripe'){R(c,'#3ab070',X,wy+2,Wd,3);R(c,'#4a8ae0',X,wy+5,Wd,2);}
 // garis luar
 R(c,INK,X-1,Y-1,Wd+2,1);R(c,INK,X-1,Y-1,1,Hd+2);R(c,INK,X+Wd,Y-1,1,Hd+2);R(c,INK,X-1,Y+Hd,Wd+2,1);R(c,INK,X,Y+roofH-1,Wd,1);}

/* ---------- lahan kosong & rumah pemain ---------- */
function lotBase(l){const r=mulberry32(l.x*131+l.y*17);for(let y=0;y<l.h;y++)for(let x=0;x<l.w;x++){const X=(l.x+x)*T,Y=(l.y+y)*T;if(y===l.h-1)tilePlaza(sx,X,Y,r);else tileGrass(sx,X,Y,r);}}
function lotEmpty(l){lotBase(l);const r=mulberry32(l.x*7+l.y*3);const X=l.x*T,Y=l.y*T;
 for(let y=0;y<l.h-1;y++)for(let x=0;x<l.w;x++)tileGravel(sx,X+x*T,Y+y*T,r);
 for(let x=0;x<l.w;x++){R(sx,'#8a6a3a',X+x*T+1,Y+4,2,12);R(sx,'#b8923a',X+x*T,Y+7,T,2);R(sx,'#b8923a',X+x*T,Y+12,T,2);}
 R(sx,'#8a6a3a',X+l.w*T-3,Y+4,2,12);
 for(let i=0;i<5;i++){const gx=X+10+r()*(l.w*T-26),gy=Y+30+r()*50;R(sx,'#4f9a4a',gx,gy,3,2);R(sx,'#6ac04b',gx+1,gy-1,1,1);R(sx,'#6f7a8a',gx+6,gy+3,3,2);}
 // papan 売地
 const sxp=X+(l.w/2|0)*T-8,syp=Y+(l.h-2)*T-4;R(sx,'rgba(0,0,0,.2)',sxp+2,syp+26,28,3);R(sx,INK,sxp+14,syp+14,3,14);R(sx,'#8a6a3a',sxp+15,syp+14,1,13);
 R(sx,INK,sxp,syp-1,32,18);R(sx,'#ffd23a',sxp+1,syp,30,16);R(sx,'#c4161c',sxp+1,syp,30,2);R(sx,'#c4161c',sxp+1,syp+14,30,2);drawText(sx,'売地',sxp+16,syp+1,'#c4161c',null);
 // kerucut
 for(const cx of[X+3,X+l.w*T-9]){R(sx,INK,cx,Y+(l.h-1)*T-8,6,8);R(sx,'#ff7a2a',cx+1,Y+(l.h-1)*T-7,4,6);R(sx,'#fff',cx+1,Y+(l.h-1)*T-5,4,1);}
 l.owner=null;setSolid(l.x,l.y,l.w,l.h-1,0);for(let x=0;x<l.w;x++)doors.delete(ix(l.x+x,l.y+l.h-2));setSolid(l.x,l.y,l.w,1,1);}
const HSTYLE=[{rc:'#c0504a',wc:'#f4ead4'},{rc:'#4a6aa8',wc:'#e8f0f4'},{rc:'#4a8a6a',wc:'#f4dcd4'},{rc:'#6a5a9a',wc:'#e4f0d8'},{rc:'#9a7a3a',wc:'#dcdcf0'},{rc:'#5a6a78',wc:'#f4e0e8'}];
function lotHouse(l,style,name,owner){lotBase(l);const hs=HSTYLE[style%6],fx=l.x+(l.a?1:0),fy=l.y;
 paintBuilding(sx,fx*T,fy*T,6,5,{rc:hs.rc,wc:hs.wc,dc:3,curtain:'#f4a0b4',seed:style,alt:1,gable:1});
 const r=mulberry32(style*9);for(const[bx,by]of[[fx-1,fy+4],[fx+6,fy+4]]){R(sx,INK,bx*T+2,by*T+4,12,10);R(sx,'#3f8a4a',bx*T+3,by*T+5,10,8);R(sx,'#5cb060',bx*T+4,by*T+5,4,3);if(r()<.7)R(sx,['#ff8fb5','#ffe27a','#fff'][(r()*3)|0],bx*T+6,by*T+7,2,2);}
 // papan nama
 const nx=(fx+3)*T+8,ny=(fy+4)*T-3;R(sx,INK,nx-18,ny,36,11);R(sx,'#fffaf0',nx-17,ny+1,34,9);drawText(sx,name.slice(0,8),nx,ny-1,'#2a2030',null);
 setSolid(l.x,l.y,l.w,l.h-1,0);setSolid(fx,fy,6,5,1);solid[ix(fx+3,fy+4)]=2;doors.set(ix(fx+3,fy+4),{to:'h:'+l.id,ret:[(fx+3)*T+8,(fy+5)*T+10],lot:l});l.owner=owner;l.fx=fx;}
function removeLotHouse(l){lotEmpty(l);}
function lotRedraw(l,rec){if(rec)lotHouse(l,rec.st|0,rec.n||'?',{uid:rec.u,n:rec.n});else lotEmpty(l);}

/* ---------- blok khusus ---------- */
function scatter(r,x0,y0,w,h,n,kind,avoid){for(let i=0;i<n;i++){const x=x0+(r()*w|0),y=y0+(r()*h|0);if(avoid&&avoid(x,y))continue;if(solid[ix(x,y)])continue;const s=kind==='sakura'?SPR.sakura[(r()*4)|0]:SPR.tree[(r()*3)|0];addObj(s,x*T+8,y*T+14,1);}}
function paintPark(i,j){const o=blockOrigin(i,j),r=mulberry32(i*31+j*7);
 for(let y=0;y<12;y++)for(let x=0;x<14;x++)tileGrass(sx,(o.x+x)*T,(o.y+y)*T,r);
 // jalan setapak
 for(let x=0;x<14;x++)tilePlaza(sx,(o.x+x)*T,(o.y+5)*T,r),tilePlaza(sx,(o.x+x)*T,(o.y+6)*T,r);for(let y=0;y<12;y++)tilePlaza(sx,(o.x+6)*T,(o.y+y)*T,r),tilePlaza(sx,(o.x+7)*T,(o.y+y)*T,r);
 // kolam
 const px=o.x+1,py=o.y+1;for(let y=0;y<4;y++)for(let x=0;x<4;x++){R(sx,INK,(px+x)*T,(py+y)*T,T,T);}for(let y=0;y<4;y++)for(let x=0;x<4;x++)tileWater(sx,(px+x)*T,(py+y)*T,0);setSolid(px,py,4,4,1);PONDS.push({x:px,y:py});
 for(let y=0;y<4;y++)for(let x=0;x<4;x++){const X=(px+x)*T,Y=(py+y)*T;if(x===0)R(sx,'#8a8a96',X,Y,2,T);if(x===3)R(sx,'#8a8a96',X+T-2,Y,2,T);if(y===0)R(sx,'#8a8a96',X,Y,T,2);if(y===3)R(sx,'#8a8a96',X,Y+T-2,T,2);}
 R(sx,'#6fcf6f',(px+1)*T+4,(py+1)*T+4,8,5);R(sx,'#ff9fc0',(px+1)*T+7,(py+1)*T+3,3,3);R(sx,'#6fcf6f',(px+2)*T+2,(py+2)*T+6,7,4);
 scatter(r,o.x,o.y,14,12,16,'sakura',(x,y)=>x<o.x+6&&x>=o.x+0&&y<o.y+5||(x>=o.x+6&&x<=o.x+7)||(y>=o.y+5&&y<=o.y+6));
 scatter(r,o.x,o.y,14,12,8,'tree',(x,y)=>(x>=o.x+6&&x<=o.x+7)||(y>=o.y+5&&y<=o.y+6)||(x<o.x+5&&y<o.y+5));
 for(const[bx,by]of[[o.x+3,o.y+5],[o.x+10,o.y+5],[o.x+5,o.y+9],[o.x+9,o.y+8]])addObj(SPR.bench,bx*T+8,by*T+2,0);
 if(i===1&&j===1){addObj(SPR.stall,(o.x+9)*T+8,(o.y+3)*T+14,0);setSolid(o.x+8,o.y+2,2,1,1);stat.push({id:'takoyaki',name:'Pak Tako',job:'Penjual Takoyaki',x:(o.x+9)*T+8,y:(o.y+4)*T+10,dir:0,svc:'takoyaki',look:{skin:GRAYSK,hair:GRAYHAIR,hs:0,top:'#e8c23a',bot:'#2a3a5a',hat:'#fff'}});}
 for(let k=0;k<30;k++){const x=o.x+(r()*14|0),y=o.y+(r()*12|0);if(solid[ix(x,y)]||(x>=o.x+6&&x<=o.x+7)||(y>=o.y+5&&y<=o.y+6))continue;sx.drawImage(mkFlower(r,['#ff8fb5','#ffe27a','#fff','#c9a0ff']),x*T,y*T);}}
function paintShrine(i,j){const o=blockOrigin(i,j),r=mulberry32(5);
 for(let y=0;y<12;y++)for(let x=0;x<14;x++)tileGravel(sx,(o.x+x)*T,(o.y+y)*T,r);
 for(let y=0;y<12;y++)for(let x=5;x<9;x++)tilePlaza(sx,(o.x+x)*T,(o.y+y)*T,r);
 for(let x=0;x<14;x++)for(let y=0;y<2;y++)tileGrass(sx,(o.x+x)*T,(o.y+y)*T,r);
 // aula
 const hx=(o.x+3)*T,hy=(o.y+1)*T;R(sx,'rgba(40,20,60,.22)',hx+8*T,hy+8,5,4*T);
 R(sx,INK,hx-1,hy+4*T-1,8*T+2,5);R(sx,'#b8b8c4',hx,hy+4*T,8*T,4);R(sx,'#9a9aa8',hx,hy+4*T+3,8*T,2);
 R(sx,INK,hx+8,hy+T+4,8*T-16,2*T+8);R(sx,'#9a3a2a',hx+9,hy+T+5,8*T-18,2*T+6);for(let k=0;k<4;k++)R(sx,'#c8b070',hx+14+k*28,hy+T+10,6,26);R(sx,'#3a2a2a',hx+30,hy+T+14,16,26);R(sx,'#6a4a3a',hx+36,hy+T+14,2,26);
 R(sx,INK,hx-4,hy-6,8*T+8,T+10);R(sx,'#3a3844',hx-3,hy-5,8*T+6,T+8);for(let yy=0;yy<T+6;yy+=4)R(sx,'#2a2834',hx-3,hy-2+yy,8*T+6,1);R(sx,'#4e4a5a',hx-3,hy-5,8*T+6,3);
 R(sx,INK,hx-8,hy+10,8*T+16,10);R(sx,'#3a3844',hx-7,hy+11,8*T+14,8);R(sx,'#4e4a5a',hx-7,hy+11,8*T+14,2);
 R(sx,INK,hx+3*T,hy+T+8,2*T,10);R(sx,'#e8c060',hx+3*T+1,hy+T+9,2*T-2,8);drawText(sx,'神社',hx+4*T,hy+T+8,'#8a2a1a',null);
 setSolid(o.x+3,o.y+1,8,3,1);
 // torii
 addObj(SPR.torii,(o.x+7)*T,(o.y+11)*T+14,0);setSolid(o.x+5,o.y+10,1,2,0);solid[ix(o.x+5,o.y+11)]=1;solid[ix(o.x+8,o.y+11)]=1;
 for(const lx of[o.x+4,o.x+9])for(const ly of[o.y+5,o.y+8])addObj(SPR.lantern,lx*T+8,ly*T+16,1);
 scatter(r,o.x,o.y,14,12,10,'sakura',(x,y)=>x>=o.x+3&&x<=o.x+10||y<o.y+1||y<=o.y+4&&x>=o.x+3);
 stat.push({id:'miko',name:'Miko',job:'Penjaga kuil',x:(o.x+6)*T+16,y:(o.y+5)*T+10,dir:0,svc:'omikuji',look:{skin:GRAYSK,hair:GRAYHAIR,hs:1,top:'#f4f4f8',bot:'#d9382e',collar:'#d9382e'}});}
function paintSchool(i,j){const o=blockOrigin(i,j),r=mulberry32(11);
 for(let y=0;y<12;y++)for(let x=0;x<14;x++)tileGravel(sx,(o.x+x)*T,(o.y+y)*T,r);
 for(let x=0;x<14;x++)for(let y=0;y<6;y++)tilePlaza(sx,(o.x+x)*T,(o.y+y)*T,r);
 // gedung 12x6
 paintBuilding(sx,(o.x+1)*T,o.y*T,12,6,{roof:'flat',wc:'#f0ece0',wr:3,dc:6,extra:'clock',kind:'school',doorCol:'#4a6aa8',glassDoor:1,seed:3,dh:20});
 sx.fillStyle='#2a6a3a';R(sx,'#2a6a3a',(o.x+1)*T+2*T,o.y*T+1*T-4,8*T,12);drawText(sx,'さくら小学校',(o.x+7)*T,o.y*T+1*T-4,'#fff','#143a20');
 setSolid(o.x+1,o.y,12,6,1);solid[ix(o.x+7,o.y+5)]=2;doors.set(ix(o.x+7,o.y+5),{to:'school',ret:[(o.x+7)*T+8,(o.y+6)*T+10]});
 // lapangan
 for(let y=7;y<12;y++)for(let x=0;x<14;x++)tileGravel(sx,(o.x+x)*T,(o.y+y)*T,r);
 R(sx,'#fff',(o.x+1)*T,(o.y+7)*T+6,12*T,2);R(sx,'#fff',(o.x+1)*T,(o.y+11)*T+6,12*T,2);R(sx,'#fff',(o.x+7)*T-1,(o.y+7)*T+6,2,5*T-4);
 R(sx,'#fff',(o.x+1)*T,(o.y+7)*T+6,2,5*T-4);R(sx,'#fff',(o.x+13)*T-2,(o.y+7)*T+6,2,5*T-4);
 scatter(r,o.x,o.y+6,14,1,5,'sakura');for(let k=0;k<4;k++)addObj(SPR.sakura[k%4],(o.x+(k<2?0:13))*T+8,(o.y+(k%2?8:11))*T+14,1);
 stat.push({id:'guard',name:'Pak Satpam',job:'Penjaga gerbang',x:(o.x+9)*T+8,y:(o.y+6)*T+12,dir:0,svc:'talk',look:{skin:GRAYSK,hair:GRAYHAIR,hs:0,top:'#3a5a9a',bot:'#2a3a6a',hat:'#2a3a6a',badge:1},lines:['Selamat datang di Sekolah Sakura!','Masuk lewat pintu tengah, ikut pelajaran biar pintar dan dapat uang saku.']});}

/* ---------- blok biasa ---------- */
const SPECIAL={'3,2':'shrine','1,1':'park','4,3':'park','0,4':'park','4,1':'school'};
const FIXED={'2,2:0':'cloth','2,3:2':'dealer','3,1:0':'konbini','1,2:3':'konbini','3,3:1':'ramen','4,2:0':'clinic','2,1:2':'koban'};
function paintBlocks(){const r=mulberry32(4242);
 for(let j=0;j<NY;j++)for(let i=0;i<NX;i++){const sp=SPECIAL[i+','+j];if(sp==='park'){paintPark(i,j);continue;}if(sp==='shrine'){paintShrine(i,j);continue;}if(sp==='school'){paintSchool(i,j);continue;}
  const o=blockOrigin(i,j);for(let y=0;y<12;y++)for(let x=0;x<14;x++)tileGrass(sx,(o.x+x)*T,(o.y+y)*T,r);
  const dealerHere=FIXED[i+','+j+':2']==='dealer';
  for(let k=0;k<4;k++){const a=k&1,b=k>>1,key=i+','+j+':'+k,fx=FIXED[key];if(dealerHere&&k===3)continue;
   const l={id:i+'-'+j+'-'+k,x:o.x+a*7,y:o.y+b*6,w:7,h:6,a,b,kind:fx||'',owner:null};
   // dasar lot
   const rr=mulberry32(l.x*3+l.y);for(let y=0;y<6;y++)for(let x=0;x<7;x++)(y===5?tilePlaza:tileGrass)(sx,(l.x+x)*T,(l.y+y)*T,rr);
   if(fx==='dealer'){dealer(o,l);continue;}
   if(fx){special(l,fx,r);continue;}
   if(r()<.52){l.kind='lot';LOTS.push(l);LOTBYID.set(l.id,l);lotEmpty(l);continue;}
   decor(l,r);}
  // gang: pohon & mesin penjual
  for(let k=0;k<2;k++){const gx=o.x+6,gy=o.y+(k?7:1);if(r()<.65)addObj(r()<.5?SPR.tree[(r()*3)|0]:SPR.sakura[(r()*4)|0],gx*T+16,(gy+(r()*3|0))*T+14,0);if(r()<.5)addObj(SPR.vend[(r()*4)|0],(gx+(r()<.5?0:1))*T+8,(gy+4)*T+12,0);}
 }}
function mark(x,y,w,h,door,to,ret){setSolid(x,y,w,h,1);if(door){solid[ix(door[0],door[1])]=2;doors.set(ix(door[0],door[1]),{to,ret});}}
function decor(l,r){const fx=l.x+(l.a?1:0),kind=r(),seed=(r()*99)|0;
 if(kind<.3){const sh=SHOPS[(r()*SHOPS.length)|0];paintBuilding(sx,fx*T,l.y*T,6,5,{shop:sh,wc:WALLS[(r()*8)|0],rc:ROOFS[(r()*7)|0],roof:'tile',seed,dc:1+(r()*4|0)});mark(fx,l.y,6,5);}
 else if(kind<.62){paintBuilding(sx,fx*T,l.y*T,6,5,{roof:'flat',wr:3,wc:WALLS[(r()*8)|0],rc:ROOFS[(r()*7)|0],kindTag:'apt',seed,dc:3,doorCol:'#5a6a78',glassDoor:1,alt:seed&1});mark(fx,l.y,6,5);}
 else{const hs=HSTYLE[(r()*6)|0];paintBuilding(sx,fx*T,l.y*T,6,5,{rc:hs.rc,wc:hs.wc,dc:3,curtain:'#e8a0b8',alt:1,gable:1,seed});mark(fx,l.y,6,5);
  const nx=(fx+3)*T+8,ny=(l.y+4)*T-3;R(sx,INK,nx-12,ny,24,10);R(sx,'#fffaf0',nx-11,ny+1,22,8);drawText(sx,['田中','佐藤','鈴木','高橋','伊藤','山本'][(r()*6)|0],nx,ny-1,'#2a2030',null);}}
function special(l,fx,r){const x=l.x+(l.a?1:0),y=l.y,d=[x+3,y+4];
 if(fx==='konbini'){paintBuilding(sx,x*T,y*T,6,5,{shop:['コンビニ','#2aa66a'],awn:['#fff','#2a7ad9'],wc:'#f4f6fa',rc:'#4a6aa8',roof:'flat',extra:'stripe',dc:3,glassDoor:1,seed:2});mark(x,y,6,5,d,'konbini',[d[0]*T+8,(y+5)*T+10]);}
 if(fx==='ramen'){paintBuilding(sx,x*T,y*T,6,5,{shop:['ラーメン','#d9382e'],awn:['#2a2030','#d9382e'],wc:'#f0d8b0',rc:'#7a3a2a',roof:'tile',extra:'lantern',dc:3,seed:5});mark(x,y,6,5,d,'ramen',[d[0]*T+8,(y+5)*T+10]);}
 if(fx==='cloth'){paintBuilding(sx,x*T,y*T,6,5,{shop:['ブティック','#d95a9a'],awn:['#fff','#f08ab4'],wc:'#fbe8f0',rc:'#a84a7a',roof:'tile',dc:3,glassDoor:1,seed:6});mark(x,y,6,5,d,'cloth',[d[0]*T+8,(y+5)*T+10]);}
 if(fx==='clinic'){paintBuilding(sx,x*T,y*T,6,5,{roof:'flat',wc:'#f4f8f8',rc:'#2aa66a',wr:3,extra:'cross',dc:3,glassDoor:1,doorCol:'#9fd6c8',seed:7});mark(x,y,6,5,d,'clinic',[d[0]*T+8,(y+5)*T+10]);}
 if(fx==='koban'){paintBuilding(sx,x*T,y*T,6,5,{roof:'tile',wc:'#e4ecf8',rc:'#3a4a8a',extra:'koban',dc:3,doorCol:'#3a4a8a',glassDoor:1,seed:8});mark(x,y,6,5,d,'koban',[d[0]*T+8,(y+5)*T+10]);}}
function dealer(o,l){const x=o.x+0,y=l.y,w=13,d=[x+6,y+4];
 paintBuilding(sx,x*T,y*T,w,5,{shop:['ディーラー','#2a6ad9'],awn:['#fff','#2a6ad9'],wc:'#eef2fa',rc:'#4a5a78',roof:'flat',dc:6,glassDoor:1,seed:9});mark(x,y,w,5,d,'dealer',[d[0]*T+8,(y+5)*T+10]);
 {const pr=mulberry32(5);for(let k=0;k<14;k++)tilePlaza(sx,(x+k)*T,(y+5)*T,pr);}
 // mobil pajangan
 const cols=['#e0303a','#f2c230','#4a7fe0'];[[x+2,y+5],[x+4,y+5],[x+9,y+5]].forEach(([cx,cy],i)=>{const s=carSpr(cols[i],0,i===0?1:0);addObj({c:s.c,ox:s.ox,oy:s.oy},cx*T+16,cy*T+12,0);});
 stat.push({id:'dealer',name:'Dealer Kenji',job:'Penjual kendaraan',x:(x+7)*T+14,y:(y+5)*T+12,dir:0,svc:'dealer',look:{skin:GRAYSK,hair:GRAYHAIR,hs:0,top:'#2e3446',bot:'#2e3446',collar:'#fff',tie:'#d9382e'}});}

/* ---------- peta dasar ---------- */
function paintBase(){const r=mulberry32(99);
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){const X=x*T,Y=y*T;
  if(y<OY){continue;}
  const lx=x%CELLW,ly=(y-OY)%CELLH,laneX=lx===17||lx===0,swX=lx===16||lx===1,laneY=ly===15||ly===0,swY=ly===14||ly===1;
  if(laneX||laneY){tileRoad(sx,X,Y,r);if(swX&&laneY)for(const b of[1,6,11])R(sx,'#f4f1e8',X+b,Y,4,T);if(swY&&laneX)for(const b of[1,6,11])R(sx,'#f4f1e8',X,Y+b,T,4);}
  else if(swX||swY)tileSidewalk(sx,X,Y,r);else tileGrass(sx,X,Y,r);
  if(lx===17&&!laneY&&!swY)R(sx,'#f4f0c8',X+15,Y+3,1,10);if(lx===0&&!laneY&&!swY)R(sx,'#f4f0c8',X,Y+3,1,10);
  if(ly===15&&!laneX&&!swX)R(sx,'#f4f0c8',X+3,Y+15,10,1);if(ly===0&&!laneX&&!swX)R(sx,'#f4f0c8',X+3,Y,10,1);
  // sudut trotoar membulat
  if(swX&&swY){R(sx,'#c9bfae',X+(lx===1?0:15),Y+(ly===1?0:15),1,1);}
 }
 // garis tepi trotoar (curb)
 for(let y=OY;y<H;y++)for(let x=0;x<W;x++){const lx=x%CELLW,ly=(y-OY)%CELLH;const X=x*T,Y=y*T;if(ly===1&&lx>=2&&lx<=15)R(sx,'#b6aa96',X,Y,T,1);if(ly===14&&lx>=2&&lx<=15)R(sx,'#b6aa96',X,Y+15,T,1);if(lx===1&&ly>=2&&ly<=13)R(sx,'#b6aa96',X,Y,1,T);if(lx===16&&ly>=2&&ly<=13)R(sx,'#b6aa96',X+15,Y,1,T);}
 // area rel kereta
 for(let y=0;y<OY;y++)for(let x=0;x<W;x++){const X=x*T,Y=y*T;if(y<=1)tileGrass(sx,X,Y,r);else if(y===2){tileGrass(sx,X,Y,r);R(sx,'#9aa0ae',X,Y+4,T,2);R(sx,'#9aa0ae',X+2,Y+2,2,10);R(sx,'#9aa0ae',X+10,Y+2,2,10);}
  else if(y===3||y===4){R(sx,'#8a8478',X,Y,T,T);for(let k=0;k<6;k++)R(sx,r()<.5?'#a8a296':'#6e695e',X+(r()*14|0),Y+(r()*14|0),2,1);R(sx,'#5a4a3a',X+2,Y,3,T);R(sx,'#5a4a3a',X+10,Y,3,T);R(sx,'#c0c4d0',X,Y+(y===3?4:3),T,1);R(sx,'#c0c4d0',X,Y+(y===3?11:10),T,1);}
  else{tilePlaza(sx,X,Y,r);R(sx,'#f2c230',X,Y+2,T,2);R(sx,'#d9a820',X,Y+4,T,1);}}
 setSolid(0,0,W,OY+1,1);
 // pagar tepi
 for(let x=0;x<W;x++)for(const y of[OY,H-1]){hedge(x,y);}for(let y=OY;y<H;y++)for(const x of[0,W-1])hedge(x,y);
 for(let x=0;x<W;x++)solid[ix(x,H-1)]=1;
 // pohon di sepanjang jalur kereta
 for(let x=2;x<W;x+=5)addObj(SPR.tree[x%3],x*T+8,T*2-2+12,0);}
function hedge(x,y){const X=x*T,Y=y*T;R(sx,'#2f7a3c',X,Y,T,T);const r=mulberry32(x*13+y);for(let i=0;i<8;i++)R(sx,r()<.5?'#44a857':'#256c35',X+(r()*14|0),Y+(r()*14|0),2,2);R(sx,'#6cc46e',X,Y,T,2);solid[ix(x,y)]=1;}

/* ---------- graf trotoar untuk warga ---------- */
function buildNodes(){const id=(i,j,c)=>(j*NX+i)*4+c;for(let j=0;j<NY;j++)for(let i=0;i<NX;i++){const x0=i*CELLW+1,x1=i*CELLW+16,y0=OY+j*CELLH+1,y1=OY+j*CELLH+14;[[x0,y0],[x1,y0],[x0,y1],[x1,y1]].forEach(([x,y],c)=>NODES[id(i,j,c)]={x:x*T+8,y:y*T+8,n:[]});}
 const link=(a,b)=>{NODES[a].n.push(b);NODES[b].n.push(a);};
 for(let j=0;j<NY;j++)for(let i=0;i<NX;i++){link(id(i,j,0),id(i,j,1));link(id(i,j,1),id(i,j,3));link(id(i,j,3),id(i,j,2));link(id(i,j,2),id(i,j,0));
  if(i<NX-1){link(id(i,j,1),id(i+1,j,0));link(id(i,j,3),id(i+1,j,2));}if(j<NY-1){link(id(i,j,2),id(i,j+1,0));link(id(i,j,3),id(i,j+1,1));}}}
function buildMap(){paintBase();paintBlocks();buildNodes();objs.sort((a,b)=>a.y-b.y);}

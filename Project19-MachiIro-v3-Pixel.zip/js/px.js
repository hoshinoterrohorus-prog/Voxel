/* ===== PIXEL ART: semua gambar dibuat lewat kode (tanpa aset luar) ===== */
const T=16,$=s=>document.querySelector(s);
function mulberry32(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
const mk=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.imageSmoothingEnabled=false;return[c,x];};
const R=(x,col,a,b,w,h)=>{x.fillStyle=col;x.fillRect(a|0,b|0,w|0,h|0);};
function shade(hex,a){const n=parseInt(hex.slice(1),16);let r=n>>16,g=n>>8&255,b=n&255;if(a>=0){r+=(255-r)*a;g+=(255-g)*a;b+=(255-b)*a;}else{r*=1+a;g*=1+a;b*=1+a;}return'#'+((1<<24)|(r|0)<<16|(g|0)<<8|(b|0)).toString(16).slice(1);}
const INK='#2a2030';
const SK=['#fde0c8','#f5c9a2','#e0a87a','#c28559','#8d5a3b','#5e3a26'],GRAYSK='#a8aab2',GRAYHAIR='#6d6f7a';
const HAIRC=['#2a1d18','#4a3020','#8a5a2a','#d8b25a','#c0392e','#3a4a9a','#e86aa8','#e8e8ee'];
const TOPC=['#e0524f','#4a7fe0','#f2c230','#4cb87a','#9a63d4','#f4f4f8','#2e3446','#f08a3c','#38bfc9','#e868a8','#7a8a3a','#a8553a'];
const BOTC=['#2b3144','#3b4a6b','#6a523a','#23252b','#7a7a86','#9a8a5a','#2f5a4a','#8a3a3a'];
const HSN=['Pendek','Panjang','Jabrik','Kuncir'],ACN=['Tanpa','Topi','Kacamata','Syal'];


/* font bitmap 3x5 untuk huruf latin (tajam) */
const F35={"A":".#.#.#####.##.#","B":"##.#.###.#.###.","C":".###..#..#...##","D":"##.#.##.##.###.","E":"####..##.#..###","F":"####..##.#..#..","G":".###..#.##.#.##","H":"#.##.#####.##.#","I":"###.#..#..#.###","J":"..#..#..##.#.#.","K":"#.##.###.#.##.#","L":"#..#..#..#..###","M":"#.########.##.#","N":"##.#.##.##.##.#","O":".#.#.##.##.#.#.","P":"##.#.###.#..#..","Q":".#.#.##.###..##","R":"##.#.###.#.##.#","S":".###...#...###.","T":"###.#..#..#..#.","U":"#.##.##.##.####","V":"#.##.##.##.#.#.","W":"#.##.########.#","X":"#.##.#.#.#.##.#","Y":"#.##.#.#..#..#.","Z":"###..#.#.#..###","0":"####.##.##.####","1":".#.##..#..#.###","2":"##...#.#.#..###","3":"##...#.#...###.","4":"#.##.####..#..#","5":"####..##...###.","6":".###..####.####","7":"###..#.#..#..#.","8":"####.#####.####","9":"####.####..###."," ":"...............",".":".............#.",",":"..........#.#..","!":".#..#..#.....#.","?":"##...#.#.....#.",":":"....#.....#....","-":"......###......","'":".#..#..........","+":"....#.###.#....","/":"..#..#.#.#..#..","(":".#.#..#..#...#.",")":".#...#..#..#.#.","%":"#.#..#.#.#..#.#","¥":"#.##.####.#..#.","♪":".##.#..#.##.##."};
const _bt=new Map();
function btext(txt,col,out){txt=String(txt).toUpperCase();const k=txt+'|'+col+'|'+out;let r=_bt.get(k);if(r)return r;const w=txt.length*4+1,[c,x]=mk(w+2,9);
 const dot=(a,b,cc)=>R(x,cc,a,b,1,1);
 for(let pass=0;pass<2;pass++){let ox=1;for(const ch of txt){const g=F35[ch]||F35['?'];for(let i=0;i<15;i++)if(g[i]==='#'){const gx=ox+i%3,gy=1+((i/3)|0);if(pass===0){if(out!=='none')for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]])dot(gx+dx,gy+dy,out||INK);}else dot(gx,gy,col);}ox+=4;}}
 _bt.set(k,c);return c;}
const isLatin=t=>[...String(t).toUpperCase()].every(ch=>F35[ch]!==undefined);

/* ---------- teks pixel tajam ---------- */
const _pt=new Map();
function ptext(txt,col,outCol){const k=txt+'|'+col+'|'+outCol;let r=_pt.get(k);if(r)return r;
 const[m,mx]=mk(8,8);mx.font='bold 8px "Noto Sans JP","Hiragino Sans","Yu Gothic",system-ui,sans-serif';const w=Math.ceil(mx.measureText(txt).width)+4,h=13;
 const[c,x]=mk(w,h);x.font=mx.font;x.textBaseline='alphabetic';x.fillStyle='#fff';x.fillText(txt,2,9);
 const d=x.getImageData(0,0,w,h),px=d.data,mask=new Uint8Array(w*h);for(let i=0;i<w*h;i++)mask[i]=px[i*4+3]>110?1:0;
 const[o,ox]=mk(w,h);const od=ox.createImageData(w,h),pd=od.data;const set=(i,c3)=>{pd[i*4]=c3[0];pd[i*4+1]=c3[1];pd[i*4+2]=c3[2];pd[i*4+3]=255;};
 const hx=s=>{if(s.length===4)s='#'+s[1]+s[1]+s[2]+s[2]+s[3]+s[3];return[parseInt(s.slice(1,3),16),parseInt(s.slice(3,5),16),parseInt(s.slice(5,7),16)];},fc=hx(col),oc=hx(outCol||INK);
 if(outCol!==null)for(let y=0;y<h;y++)for(let xx=0;xx<w;xx++){if(mask[y*w+xx])continue;let n=0;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const X=xx+dx,Y=y+dy;if(X>=0&&Y>=0&&X<w&&Y<h&&mask[Y*w+X])n=1;}if(n)set(y*w+xx,oc);}
 for(let i=0;i<w*h;i++)if(mask[i])set(i,fc);ox.putImageData(od,0,0);_pt.set(k,o);return o;}
function drawText(ctx,txt,x,y,col,out){if(isLatin(txt)){const c=btext(txt,col||'#fff',out===null?'none':out===undefined?INK:out);ctx.drawImage(c,Math.round(x-c.width/2),Math.round(y)+2);return;}const c=ptext(txt,col||'#fff',out===undefined?INK:out);ctx.drawImage(c,Math.round(x-c.width/2),Math.round(y));}

/* ---------- karakter ---------- */
const CW=18,CH=25;
function frame(x,ox,oy,dir,fr,L){
 if(dir===2){const[t,tx]=mk(CW,CH);frame(tx,0,0,1,fr,L);x.save();x.translate(ox+16,oy);x.scale(-1,1);x.drawImage(t,0,0);x.restore();return;}
 const S=L.skin,sd=shade(S,-.14),H=L.hair,hh=shade(H,.22),Tp=L.top,td=shade(Tp,-.2),B=L.bot,bd=shade(B,-.22),shoe='#2b2230';
 const step=fr===1?1:fr===3?-1:0,sit=fr===4,wave=fr===5,dy=sit?3:0,hs=L.hs|0;
 const r=(c,a,b,w,h)=>R(x,c,ox+a,oy+b,w,h);
 const legs=()=>{if(sit){r(B,4,18,8,3);r(bd,4,20,8,1);r(shoe,4,21,3,2);r(shoe,9,21,3,2);return;}
  if(dir===1){const a=step>0?-1:step<0?1:0;r(bd,7-a,16,3,5);r(B,6+a,16,3,5);r(shoe,5-a,21,4,2);r(shoe,5+a,21,4,2);return;}
  const yl=step>0?-1:0,yr=step<0?-1:0;r(B,5,16+yl,3,5);r(B,8,16+yr,3,5);r(bd,7,16+yl,1,5);r(bd,10,16+yr,1,5);r(shoe,5,21+yl,3,2);r(shoe,8,21+yr,3,2);};
 legs();
 // badan
 if(dir===1){r(Tp,5,10+dy,6,6);r(td,9,10+dy,2,6);const a=step>0?-1:step<0?1:0;r(td,7+a,10+dy,3,5);r(S,7+a,15+dy,3,2);}
 else{r(Tp,4,10+dy,8,6);r(td,10,10+dy,2,6);r(td,4,15+dy,8,1);
  const aL=sit?0:step>0?-1:step<0?1:0;r(Tp,2,10+dy+aL,2,5);r(S,2,15+dy+aL,2,2);
  if(wave){r(Tp,12,4,2,7);r(S,12,2,2,2);r(S,13,2,1,1);}else{r(Tp,12,10+dy-aL,2,5);r(S,12,15+dy-aL,2,2);}
  if(L.collar){r(L.collar,4,10+dy,8,2);r(L.tie||L.collar,7,11+dy,2,4);}
  if(L.badge){r('#f2c230',9,12+dy,2,2);}}
 if(L.prop==='case'&&dir!==3)r('#6a4a2a',12,16+dy,4,3),r('#3a2a1a',13,15+dy,2,1);
 if(L.prop==='broom'){r('#8a6a3a',14,5,1,15);r('#d9b85a',12,18,4,3);r('#b8923a',12,20,4,1);}
 if(L.prop==='apron')r('#fff',5,13+dy,6,3);
 // kepala
 const h0=2+dy;
 if(dir===0){
  if(hs===1){r(H,2,h0,2,10);r(H,12,h0,2,10);} if(hs===2){r(H,4,h0-2,2,2);r(H,7,h0-2,2,1);r(H,10,h0-2,2,2);} if(hs===3){r(H,6,h0-2,4,2);r(hh,7,h0-2,1,1);}
  r(S,3,h0,10,8);r(sd,3,h0+7,10,1);
  r(H,3,h0-1,10,3);r(hh,5,h0-1,3,1);r(H,2,h0,1,5);r(H,13,h0,1,5);r(H,4,h0+2,3,1);r(H,9,h0+2,3,1);
  r(INK,5,h0+4,2,2);r(INK,9,h0+4,2,2);r('#fff',5,h0+4,1,1);r('#fff',9,h0+4,1,1);
  if(L.skin!==GRAYSK)r('rgba(240,110,110,.45)',4,h0+6,2,1),r('rgba(240,110,110,.45)',10,h0+6,2,1);
  r(shade(S,-.3),7,h0+6,2,1);
 }else if(dir===1){
  if(hs===1)r(H,9,h0,4,12);if(hs===3)r(H,10,h0-1,3,3);if(hs===2){r(H,4,h0-2,2,2);r(H,8,h0-2,2,2);}
  r(S,3,h0,9,8);r(S,2,h0+4,1,2);r(sd,3,h0+7,9,1);
  r(H,3,h0-1,10,3);r(hh,5,h0-1,3,1);r(H,8,h0,5,7);r(H,3,h0,1,2);
  r(INK,4,h0+4,1,2);r('#fff',4,h0+4,1,1);
 }else{ // belakang
  if(hs===1)r(H,2,h0,12,12);if(hs===3){r(H,6,h0-2,4,2);r(H,7,h0+8,2,5);}if(hs===2){r(H,4,h0-2,2,2);r(H,7,h0-2,2,1);r(H,10,h0-2,2,2);}
  r(H,2,h0-1,12,10);r(hh,4,h0,3,1);r(sd,3,h0+8,10,1);r(S,6,h0+8,4,1);
 }
 // aksesori
 const ac=L.ac|0;
 if(ac===2){if(dir===0){r(INK,4,h0+3,4,3);r(INK,8,h0+3,4,3);r('#cfeaff',5,h0+4,2,1);r('#cfeaff',9,h0+4,2,1);r(INK,8,h0+4,1,1);}else if(dir===1){r(INK,3,h0+3,4,3);r('#cfeaff',4,h0+4,2,1);}}
 if(ac===3){r('#f0e6d0',4,10+dy,8,2);if(dir!==1)r('#d8cbb0',10,12+dy,2,3);}
 if(ac===1||L.hat){const hc=L.hat||'#d94a4a';r(hc,3,h0-2,10,3);r(shade(hc,.25),4,h0-2,3,1);if(dir===0)r(shade(hc,-.25),3,h0+1,10,1);else if(dir===1)r(shade(hc,-.25),1,h0+1,6,1);}
}
const _cs=new Map();
function charSheet(L){const k=JSON.stringify(L);let c=_cs.get(k);if(c)return c;
 const[cv,x]=mk(CW*6,CH*4);for(let d=0;d<4;d++)for(let f=0;f<6;f++){if((f===4||f===5)&&d!==0)continue;frame(x,f*CW+1,d*CH+1,d,f,L);}
 const id=x.getImageData(0,0,cv.width,cv.height),p=id.data,w=cv.width,h=cv.height,out=new Uint8ClampedArray(p);
 for(let y=0;y<h;y++)for(let xx=0;xx<w;xx++){const i=(y*w+xx)*4;if(p[i+3]>0)continue;let n=false;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const X=xx+dx,Y=y+dy;if(X>=0&&Y>=0&&X<w&&Y<h&&p[(Y*w+X)*4+3]>0)n=true;}if(n){out[i]=42;out[i+1]=32;out[i+2]=48;out[i+3]=255;}}
 x.putImageData(new ImageData(out,w,h),0,0);_cs.set(k,cv);return cv;}
function drawChar(ctx,L,dir,fr,x,y){const s=charSheet(L);ctx.drawImage(s,fr*CW,dir*CH,CW,CH,Math.round(x-9),Math.round(y-24),CW,CH);}

/* ---------- kendaraan ---------- */
const VEH=[null,{id:1,n:'Sepeda',p:150,spd:6.5,t:'bike',c:'#e0524f'},{id:2,n:'Skuter',p:500,spd:8.5,t:'scooter',c:'#4a7fe0'},{id:3,n:'Mobil Kei',p:1200,spd:11,t:'car',c:'#f2c230'},{id:4,n:'Mobil Sport',p:2800,spd:14,t:'car',c:'#e0303a',low:1}];
const _vs=new Map();
function carSpr(col,dir,low,kind){const k=col+dir+low+(kind||'');let c=_vs.get(k);if(c)return c;
 const side=dir===1||dir===2,[cv,x]=mk(side?30:18,side?18:30);c={c:cv,ox:cv.width/2,oy:cv.height-1};
 const body=col,roof=shade(col,.22),win='#bfe6f7',wd='#7fb4d0';
 if(side){const L=dir===1;R(x,'rgba(0,0,0,.28)',3,14,24,3);
  R(x,body,2,6,26,7);R(x,shade(col,-.2),2,11,26,2);R(x,roof,L?8:6,low?3:2,16,low?5:6);R(x,win,L?9:7,low?4:3,6,low?3:4);R(x,win,L?16:14,low?4:3,6,low?3:4);R(x,wd,L?15:13,3,1,5);
  R(x,INK,5,12,5,4);R(x,INK,19,12,5,4);R(x,'#9a9aa8',6,13,3,2);R(x,'#9a9aa8',20,13,3,2);
  R(x,'#fff3a0',L?2:26,8,2,2);R(x,'#e0403a',L?26:2,8,2,2);if(kind==='van'){R(x,roof,6,2,18,6);}
 }else{const up=dir===3;R(x,'rgba(0,0,0,.28)',2,26,14,3);
  R(x,body,2,3,14,24);R(x,shade(col,-.2),2,22,14,4);R(x,roof,4,up?10:9,10,9);R(x,win,4,up?5:6,10,5);R(x,win,4,up?19:18,10,3);R(x,wd,4,up?5:6,10,1);
  R(x,INK,0,6,2,6);R(x,INK,16,6,2,6);R(x,INK,0,19,2,6);R(x,INK,16,19,2,6);
  R(x,'#fff3a0',3,up?3:24,3,2);R(x,'#fff3a0',12,up?3:24,3,2);R(x,'#e0403a',3,up?24:3,3,2);R(x,'#e0403a',12,up?24:3,3,2);}
 // garis luar
 const id=x.getImageData(0,0,cv.width,cv.height),p=id.data,w=cv.width,h=cv.height,out=new Uint8ClampedArray(p);
 for(let y=0;y<h;y++)for(let xx=0;xx<w;xx++){const i=(y*w+xx)*4;if(p[i+3]>0)continue;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const X=xx+dx,Y=y+dy;if(X>=0&&Y>=0&&X<w&&Y<h&&p[(Y*w+X)*4+3]>200){out[i]=42;out[i+1]=32;out[i+2]=48;out[i+3]=255;break;}}}
 x.putImageData(new ImageData(out,w,h),0,0);_vs.set(k,c);return c;}
function bikeSpr(v,dir){const k='b'+v.id+dir;let c=_vs.get(k);if(c)return c;const side=dir===1||dir===2,[cv,x]=mk(side?24:12,side?14:24);c={c:cv,ox:cv.width/2,oy:cv.height-1};
 if(side){const L=dir===1;R(x,'rgba(0,0,0,.25)',3,12,18,2);R(x,INK,2,7,6,6);R(x,INK,16,7,6,6);R(x,'#cfd2dc',3,8,4,4);R(x,'#cfd2dc',17,8,4,4);R(x,INK,4,9,2,2);R(x,INK,18,9,2,2);
  if(v.t==='bike'){R(x,v.c,6,5,12,2);R(x,v.c,9,3,2,5);R(x,v.c,L?16:6,2,2,5);R(x,'#444',L?15:5,1,4,1);}else{R(x,v.c,5,5,15,5);R(x,shade(v.c,.25),L?15:5,2,3,4);R(x,'#444',L?13:7,1,5,1);R(x,'#fff3a0',L?3:20,6,2,2);}}
 else{R(x,'rgba(0,0,0,.25)',2,21,8,2);R(x,INK,4,2,4,19);R(x,'#cfd2dc',5,3,2,17);R(x,v.c,3,8,6,8);R(x,'#444',1,dir===3?7:8,10,1);}
 const id=x.getImageData(0,0,cv.width,cv.height),p=id.data,w=cv.width,h=cv.height,out=new Uint8ClampedArray(p);
 for(let y=0;y<h;y++)for(let xx=0;xx<w;xx++){const i=(y*w+xx)*4;if(p[i+3]>0)continue;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const X=xx+dx,Y=y+dy;if(X>=0&&Y>=0&&X<w&&Y<h&&p[(Y*w+X)*4+3]>200){out[i]=42;out[i+1]=32;out[i+2]=48;out[i+3]=255;break;}}}
 x.putImageData(new ImageData(out,w,h),0,0);_vs.set(k,c);return c;}
function vehSpr(id,dir){const v=VEH[id];return v.t==='car'?carSpr(v.c,dir,v.low||0):bikeSpr(v,dir);}

/* ---------- objek (pohon, lampu, dll) ---------- */
function mkTree(kind,seed){const r=mulberry32(seed),[c,x]=mk(40,48);R(x,'rgba(0,0,0,.22)',8,42,24,5);R(x,'#6b4528',18,28,5,16);R(x,'#4f321c',21,28,2,16);R(x,'#6b4528',14,42,13,2);
 const pal=kind==='sakura'?['#ff9fc0','#ffb7d0','#ffd5e4','#e87aa4']:['#2f8a43','#44a857','#6cc46e','#256c35'];
 const blob=(cx,cy,rad,col)=>{for(let y=-rad;y<=rad;y++)for(let xx=-rad;xx<=rad;xx++)if(xx*xx+y*y<=rad*rad+r()*rad)R(x,col,cx+xx,cy+y,1,1);};
 blob(20,18,14,pal[3]);blob(20,16,13,pal[0]);blob(14,14,8,pal[1]);blob(26,12,7,pal[1]);for(let i=0;i<26;i++)R(x,pal[2],8+r()*24,4+r()*20,2,1);for(let i=0;i<18;i++)R(x,pal[3],8+r()*24,18+r()*12,2,2);
 const id=x.getImageData(0,0,40,48),p=id.data,out=new Uint8ClampedArray(p);for(let y=0;y<48;y++)for(let xx=0;xx<40;xx++){const i=(y*40+xx)*4;if(p[i+3]>0)continue;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const X=xx+dx,Y=y+dy;if(X>=0&&Y>=0&&X<40&&Y<48&&p[(Y*40+X)*4+3]>200&&!(p[(Y*40+X)*4]===0)){out[i]=42;out[i+1]=32;out[i+2]=48;out[i+3]=255;break;}}}
 x.putImageData(new ImageData(out,40,48),0,0);return{c,ox:20,oy:44};}
function mkLamp(){const[c,x]=mk(12,30);R(x,'rgba(0,0,0,.2)',1,27,9,3);R(x,'#3a3f4f',5,6,2,22);R(x,'#3a3f4f',3,26,6,2);R(x,'#3a3f4f',3,4,6,3);R(x,'#fff1b0',4,2,4,3);R(x,'#ffe27a',5,3,2,1);return{c,ox:6,oy:27};}
function mkVend(col){const[c,x]=mk(16,26);R(x,'rgba(0,0,0,.2)',1,23,14,3);R(x,INK,1,1,14,24);R(x,col,2,2,12,22);R(x,shade(col,.25),2,2,12,2);R(x,'#dfe8f4',3,5,10,9);for(let i=0;i<3;i++)for(let j=0;j<2;j++){R(x,['#e0524f','#4a7fe0','#f2c230','#4cb87a'][(i+j)%4],4+i*3,6+j*4,2,3);}R(x,'#2a2030',4,16,8,2);R(x,'#2a2030',5,20,6,3);return{c,ox:8,oy:24};}
function mkBench(){const[c,x]=mk(24,16);R(x,'rgba(0,0,0,.2)',1,13,22,3);R(x,INK,1,2,22,5);R(x,'#b8793c',2,3,20,3);R(x,'#d99a55',2,3,20,1);R(x,INK,1,8,22,4);R(x,'#9a6030',2,9,20,2);R(x,INK,2,12,2,3);R(x,INK,20,12,2,3);return{c,ox:12,oy:14};}
function mkTorii(){const[c,x]=mk(64,56);R(x,'rgba(0,0,0,.2)',4,52,56,4);const red='#d9382e',dk='#a82820',blk='#26222c';R(x,INK,6,10,6,44);R(x,red,7,10,4,43);R(x,dk,10,10,1,43);R(x,INK,52,10,6,44);R(x,red,53,10,4,43);R(x,dk,56,10,1,43);R(x,INK,10,18,44,6);R(x,red,11,19,42,4);R(x,INK,0,6,64,6);R(x,blk,1,7,62,3);R(x,'#3a3440',1,7,62,1);R(x,red,4,3,56,3);R(x,INK,1,1,62,3);R(x,blk,2,2,60,1);R(x,INK,27,12,10,8);R(x,'#f2c230',28,13,8,6);return{c,ox:32,oy:54};}
function mkLantern(){const[c,x]=mk(14,26);R(x,'rgba(0,0,0,.2)',1,23,12,3);R(x,INK,2,20,10,4);R(x,'#9a9aa6',3,20,8,3);R(x,INK,5,10,4,11);R(x,'#aaaab6',6,10,2,10);R(x,INK,2,4,10,7);R(x,'#ffe27a',4,5,6,4);R(x,INK,0,1,14,4);R(x,'#8a8a96',1,2,12,2);return{c,ox:7,oy:24};}
function mkStall(){const[c,x]=mk(40,40);R(x,'rgba(0,0,0,.2)',2,36,36,4);R(x,INK,2,16,36,22);R(x,'#c98a4a',3,17,34,20);R(x,'#a86a30',3,30,34,7);R(x,INK,0,4,40,14);for(let i=0;i<8;i++)R(x,i%2?'#fff':'#d9382e',1+i*5,5,5,12);R(x,'#ffe27a',8,22,24,6);R(x,'#e0a040',10,23,4,4);R(x,'#e0a040',17,23,4,4);R(x,'#e0a040',24,23,4,4);return{c,ox:20,oy:38};}
function mkFlower(r,col){const[c,x]=mk(16,16);for(let i=0;i<6;i++){const a=r()*12+1,b=r()*10+4;R(x,'#3d9a48',a,b+2,1,3);R(x,col[(r()*col.length)|0],a-1,b,3,2);R(x,'#ffe27a',a,b,1,1);}return c;}

/* ---------- ubin dasar ---------- */
function tileGrass(x,ox,oy,r){R(x,'#7ccf5c',ox,oy,16,16);for(let i=0;i<10;i++){const a=r()*14|0,b=r()*13|0;R(x,'#6ac04b',ox+a,oy+b,2,1);R(x,'#92dc72',ox+a+1,oy+b-1,1,1);}if(r()<.18){R(x,'#fff',ox+(r()*13|0),oy+(r()*13|0),1,1);}}
function tileRoad(x,ox,oy,r){R(x,'#5d6372',ox,oy,16,16);for(let i=0;i<7;i++)R(x,r()<.5?'#656b7a':'#555b69',ox+(r()*15|0),oy+(r()*15|0),2,1);}
function tileSidewalk(x,ox,oy,r){R(x,'#ddd5c8',ox,oy,16,16);R(x,'#c9bfae',ox,oy+7,16,1);R(x,'#c9bfae',ox+7,oy,1,8);R(x,'#c9bfae',ox+3,oy+8,1,8);R(x,'#c9bfae',ox+11,oy+8,1,8);R(x,'#eee8dc',ox,oy,16,1);if(r()<.2)R(x,'#cfc5b4',ox+(r()*12|0),oy+(r()*12|0),2,2);}
function tilePlaza(x,ox,oy,r){R(x,'#e6dfd2',ox,oy,16,16);R(x,'#d2c8b6',ox,oy+15,16,1);R(x,'#d2c8b6',ox+15,oy,1,16);for(let i=0;i<3;i++)R(x,'#d9d0c0',ox+(r()*13|0),oy+(r()*13|0),2,1);}
function tileGravel(x,ox,oy,r){R(x,'#c9bd9a',ox,oy,16,16);for(let i=0;i<14;i++)R(x,r()<.5?'#b5a984':'#ddd2b0',ox+(r()*14|0),oy+(r()*14|0),2,1);}
function tileWater(x,ox,oy,t){R(x,'#58b4e8',ox,oy,16,16);R(x,'#7cc8f2',ox+((t*3)%12|0),oy+3,4,1);R(x,'#3f98d0',ox+((5+t*2)%12|0),oy+10,5,1);}
function tileWood(x,ox,oy,r,a,b){R(x,a,ox,oy,16,16);R(x,b,ox,oy+15,16,1);R(x,b,ox+(r()*14|0),oy,1,15);for(let i=0;i<3;i++)R(x,shade(a,-.07),ox+(r()*13|0),oy+(r()*13|0),3,1);}

/* ===== database kota bersama: Firebase Realtime Database lewat REST + SSE (tanpa SDK) ===== */
const rid=()=>Math.random().toString(36).slice(2,10);
class DB{
 constructor(base){this.base=base.trim().replace(/\/+$/,'').replace(/\.json$/,'');}
 u(p,q){return this.base+'/'+p+'.json'+(q?'?'+q:'');}
 async get(p,ms){const c=new AbortController();const t=setTimeout(()=>c.abort(),ms||8000);try{const r=await fetch(this.u(p),{signal:c.signal});if(!r.ok)throw new Error('DB '+r.status+(r.status===401||r.status===403?' (rules belum public)':''));return await r.json();}finally{clearTimeout(t);}}
 put(p,v){return fetch(this.u(p),{method:'PUT',body:JSON.stringify(v)}).catch(()=>{});}
 patch(p,v,keep){return fetch(this.u(p),{method:'PATCH',body:JSON.stringify(v),keepalive:!!keep}).catch(()=>{});}
 del(p){return fetch(this.u(p),{method:'DELETE'}).catch(()=>{});}
 /* langganan: cb(root, path) dipanggil tiap perubahan; root = nilai terbaru di p */
 sub(p,cb,q){let root=null,es,dead=false;const open=()=>{if(dead)return;es=new EventSource(this.u(p,q));
  const setAt=(parts,val)=>{if(!parts.length){root=val;return;}if(root===null||typeof root!=='object')root={};let o=root;for(let i=0;i<parts.length-1;i++){if(o[parts[i]]==null||typeof o[parts[i]]!=='object')o[parts[i]]={};o=o[parts[i]];}const k=parts[parts.length-1];if(val===null)delete o[k];else o[k]=val;};
  const pp=s=>s.split('/').filter(Boolean);
  es.addEventListener('put',e=>{const m=JSON.parse(e.data);setAt(pp(m.path),m.data);cb(root,m.path);});
  es.addEventListener('patch',e=>{const m=JSON.parse(e.data),base=pp(m.path);for(const k in m.data)setAt(base.concat(pp(k)),m.data[k]);cb(root,m.path);});
  es.onerror=()=>{};};open();return{close:()=>{dead=true;es&&es.close();}};}
}

/* ===== GAME ===== */
const DEFAULT_DB='https://idke-fee0c-default-rtdb.firebaseio.com';
const cv=$('#c'),ctx=cv.getContext('2d');ctx.imageSmoothingEnabled=false;
buildMap();
const NBASE=60;let LW=160,LH=340;
function resize(){const w=innerWidth,h=innerHeight;LW=Math.max(150,Math.min(300,Math.round(w/2.8)));LH=Math.ceil(h*LW/w);if(cv.width!==LW||cv.height!==LH){cv.width=LW;cv.height=LH;ctx.imageSmoothingEnabled=false;}}
addEventListener('resize',resize);resize();

/* ---------- state ---------- */
let db=null,myUid='',mySlot=-1,me={name:'Pemain',k:1,a:[0,0,2,0,0]},players={},seen={},prevT={},wasOn={},lotsData={},chatDone=new Set(),playing=false,t0Play=0,firstSnap=true,clock=0,lastW=0,lastSent={},sending=false;
const M={x:0,y:0,dir:0,mv:false,em:0,emT:0,ii:'',vd:0,coins:1500,iq:0,inv:[],ret:[0,0],boost:0,run:false};
const keys={},joy={x:0,y:0},A=new Map(),bubbles=new Map(),camP={x:0,y:0};
let busy=false,fadeA=0,fadeCb=null,fadeDir=0;
const toast=(t)=>{const e=$('#toast');e.textContent=t;e.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('on'),2600);};
const logLine=(t)=>{const l=$('#log'),d=document.createElement('div');d.textContent=t;l.appendChild(d);while(l.children.length>4)l.firstChild.remove();setTimeout(()=>d.remove(),9000);};
const skinOf=k=>SK[k]||SK[1];
const lookOfPlayer=(r)=>{const a=r.a||[0,0,2,0,0];return{skin:skinOf(r.k),hair:HAIRC[a[0]]||HAIRC[0],hs:a[1]|0,top:TOPC[a[2]]||TOPC[0],bot:BOTC[a[3]]||BOTC[0],ac:a[4]|0};};
const lookOfSlot=(s)=>{const r=mulberry32(s*131+7);return{skin:GRAYSK,hair:GRAYHAIR,hs:(r()*4)|0,top:TOPC[(r()*12)|0],bot:BOTC[(r()*8)|0],ac:r()<.22?1+((r()*3)|0):0};};
const titleOf=q=>q<5?'Murid Baru':q<15?'Murid Rajin':q<30?'Juara Kelas':q<60?'Cendekiawan':'Profesor';
const isOn=uid=>uid===myUid?playing:(!!players[uid]&&players[uid].o!==0&&performance.now()-(seen[uid]||-1e9)<12000);
function hashS(s){let h=2166136261;for(const c of s)h=Math.imul(h^c.charCodeAt(0),16777619);return h>>>0;}

/* ---------- jadwal warga & staf berjalan (deterministik dari jam) ---------- */
const scheds=new Map();
function sched(key,spd,opt){let s=scheds.get(key);if(s)return s;const seed=typeof key==='number'?key:hashS(key),r=mulberry32(seed*7919+101),NN=NODES.length;let node=(r()*NN)|0,tt=0;spd=spd||(24+r()*16);opt=opt||{in:1,sit:1};const legs=[];
 for(let k=0;k<40;k++){const nd=NODES[node],nx=nd.n[(r()*nd.n.length)|0],nn=NODES[nx],dx=nn.x-nd.x,dy=nn.y-nd.y,d=Math.hypot(dx,dy),dur=d/spd,u=r(),type=u<.2&&opt.sit?2:u<.34&&opt.in?3:u<.55?1:0,pd=type===0?0:(type===3?8+r()*14:4+r()*10);
  legs.push({a:node,b:nx,t0:tt,t1:tt+dur,p1:tt+dur+pd,type,dir:Math.abs(dx)>Math.abs(dy)?(dx<0?1:2):(dy>0?0:3)});tt+=dur+pd;node=nx;}
 s={legs,T:tt,off:r()*tt,spd,i:0};scheds.set(key,s);return s;}
const _sp={x:0,y:0,dir:0,sp:0,m:0};
function simAt(key,spd,opt,ts){const s=sched(key,spd,opt),u=(ts+s.off)%s.T,L=s.legs;let i=s.i;if(!(L[i].t0<=u&&u<L[i].p1)){i=0;while(i<L.length-1&&u>=L[i].p1)i++;s.i=i;}const l=L[i],a=NODES[l.a],b=NODES[l.b];
 if(u<l.t1){const f=(u-l.t0)/(l.t1-l.t0);_sp.x=a.x+(b.x-a.x)*f;_sp.y=a.y+(b.y-a.y)*f;_sp.dir=l.dir;_sp.sp=1;_sp.m=0;}else{_sp.x=b.x;_sp.y=b.y;_sp.dir=l.dir===1||l.dir===2?l.dir:0;_sp.sp=0;_sp.m=l.type===0?1:l.type;}return _sp;}
// staf yang berkeliling
const WALKERS=[];{const C=(a)=>Object.assign({skin:GRAYSK,hair:GRAYHAIR,hs:0},a);
 for(let i=0;i<3;i++)WALKERS.push({id:'pol'+i,name:'Polisi',job:'Polisi patroli',spd:30,opt:{in:0,sit:0},look:C({top:'#3a5a9a',bot:'#2a3a6a',hat:'#2a3a6a',badge:1,hs:i%2*2}),lines:['Patroli rutin. Kota aman terkendali!','Jangan lari di dekat jalan ya.','Lahan kosong bisa dibeli di dekat papan 売地.']});
 for(let i=0;i<3;i++)WALKERS.push({id:'swp'+i,name:'Penyapu',job:'Petugas kebersihan',spd:16,opt:{in:0,sit:0},look:C({top:'#4cb87a',bot:'#4a4a56',hat:'#4cb87a',prop:'broom',hs:i%3}),lines:['Kotanya harus tetap bersih, apalagi kelopak sakura jatuh terus.','Sapu sapu sapu~','Buang sampah di tempatnya ya!']});
 for(let i=0;i<6;i++)WALKERS.push({id:'sal'+i,name:'Karyawan',job:'Pegawai kantoran',spd:36,opt:{in:1,sit:0},look:C({top:'#3a3f50',bot:'#3a3f50',collar:'#fff',tie:['#d9382e','#2a6ad9','#f2c230'][i%3],prop:'case',hs:i%4}),lines:['Aduh, aku telat rapat!','Lembur lagi minggu ini...','Kopi kaleng dulu di mesin penjual itu.']});
 for(let i=0;i<8;i++)WALKERS.push({id:'stu'+i,name:'Pelajar',job:'Murid SD Sakura',spd:34,opt:{in:1,sit:1},look:C({top:'#fff',collar:'#2a3a6a',tie:'#d9382e',bot:'#2a3a6a',hs:(i*3)%4,ac:i%4===1?1:0}),lines:['Aku mau jadi juara kelas!','Belajar yang rajin, nanti dapat uang saku.','Sekolah ada di sebelah timur laut.']});
 for(let i=0;i<2;i++)WALKERS.push({id:'rid'+i,name:'Kurir',job:'Kurir paket',spd:70,opt:{in:0,sit:0},veh:2,look:C({top:'#f08a3c',bot:'#2a3a5a',hat:'#f08a3c',hs:0}),lines:['Paket datang! Minggir sedikit~']}); }
const INMAP=new Map();WALKERS.forEach(w=>INMAP.set('s:'+w.id,w));

/* ---------- mobil & kereta ---------- */
const CARS=[];{const r=mulberry32(555),cols=['#e0524f','#f4f4f8','#4a7fe0','#f2c230','#2e3446','#4cb87a','#e8e8ee','#f08a3c','#9a63d4'];
 for(let m=0;m<NX-1;m++)for(const[lane,dir]of[[m*CELLW+17,1],[(m+1)*CELLW,-1]])for(let k=0;k<2;k++)CARS.push({ax:1,lane,dir,sp:40+r()*30,off:r()*2000,col:cols[(r()*cols.length)|0],van:r()<.2});
 for(let k=0;k<NY-1;k++)for(const[lane,dir]of[[OY+k*CELLH+15,1],[OY+(k+1)*CELLH,-1]])for(let q=0;q<3;q++)CARS.push({ax:0,lane,dir,sp:40+r()*30,off:r()*3000,col:cols[(r()*cols.length)|0],van:r()<.2});}
const trainCar=(()=>{const[c,x]=mk(60,26);R(x,'rgba(0,0,0,.25)',2,22,56,4);R(x,INK,1,3,58,20);R(x,'#eceef4',2,4,56,18);R(x,'#2fb86a',2,14,56,4);R(x,'#c7cad6',2,4,56,2);for(let i=0;i<5;i++){R(x,INK,5+i*11,7,9,7);R(x,'#9fd6f2',6+i*11,8,7,5);R(x,'#e8f6ff',6+i*11,8,7,2);}R(x,INK,4,21,6,3);R(x,INK,50,21,6,3);return c;})();

/* ---------- jaringan ---------- */
const slotList=()=>{const l=[];for(let i=0;i<NBASE;i++)l.push(i);for(const u in players){const s=players[u]&&players[u].s;if(typeof s==='number'&&s>=NBASE)l.push(s);}return l;};
const ownerOf=()=>{const m=new Map();for(const u in players){const r=players[u];if(r&&typeof r.s==='number')m.set(r.s,u);}return m;};
function updHud(){let on=playing?1:0,res=0;for(const u in players){if(u!==myUid&&isOn(u))on++;res++;}if(!players[myUid]&&playing)res++;$('#cnt').textContent='Online '+on+' · Warga '+res;$('#coin').textContent='¥ '+M.coins+' · '+titleOf(M.iq);$('#bRide').classList.toggle('hide',!M.inv.length);}
function onPlayers(root){const now=performance.now();players=root||{};for(const uid in players){const r=players[uid];if(!r||typeof r!=='object'){delete players[uid];continue;}if(!(uid in prevT)){prevT[uid]=r.t;seen[uid]=firstSnap?-1e9:now;}else if(prevT[uid]!==r.t){prevT[uid]=r.t;seen[uid]=now;}}firstSnap=false;updHud();}
setInterval(()=>{if(!playing)return;for(const uid in players){if(uid===myUid)continue;const on=isOn(uid);if(on!==!!wasOn[uid]){wasOn[uid]=on;if(performance.now()-t0Play>6000)logLine((on?'➕ ':'➖ ')+(players[uid].n||'?')+(on?' masuk kota':' pulang'));}}updHud();},1000);
function applyLots(){for(const l of LOTS){const rec=lotsData[l.id],key=rec&&typeof rec==='object'?rec.u+'|'+rec.n+'|'+rec.st:'';if(l.key===key)continue;l.key=key;lotRedraw(l,key?rec:null);}buildMM();}
const myLots=()=>LOTS.filter(l=>l.owner&&l.owner.uid===myUid);
function saveLocalLots(){if(db)return;try{localStorage.setItem('machi2-lots',JSON.stringify(lotsData));}catch(_){}}
function patchMe(o){if(db)db.patch('players/'+myUid,o);}
function addCoins(n){M.coins=Math.max(0,M.coins+n);patchMe({c:M.coins});updHud();}
function chatShow(slot,txt,name){logLine((name||'Warga')+': '+txt);bubbles.set('r:'+slot,{txt,t:5});}
function onChat(root){if(!root)return;for(const k in root){if(chatDone.has(k))continue;chatDone.add(k);const m=root[k];if(m&&m.txt)chatShow(m.s,String(m.txt).slice(0,60),m.n);}}
function sendChat(){const i=$('#ci'),tx=i.value.trim();i.value='';toggleChat(false);if(!tx||mySlot<0)return;chatShow(mySlot,tx,me.name);if(db){const k=Date.now().toString(36)+rid().slice(0,3);chatDone.add(k);db.put('chat/'+k,{n:me.name,s:mySlot,txt:tx});setTimeout(()=>db.del('chat/'+k),30000);}}
function leave(){if(db&&playing)db.patch('players/'+myUid,{o:0,t:Date.now()},true);}addEventListener('pagehide',leave);

/* ---------- UI: dialog & panel ---------- */
let uiOpen=false;
function dlg(name,text,choices){uiOpen=true;$('#dlg').classList.remove('hide');$('#dn').textContent=name;$('#dt').textContent=text;const c=$('#dc');c.innerHTML='';(choices||[{t:'OK'}]).forEach(ch=>{const b=document.createElement('button');b.textContent=ch.t;b.onclick=()=>{closeDlg();ch.fn&&ch.fn();};c.appendChild(b);});}
function closeDlg(){uiOpen=false;$('#dlg').classList.add('hide');}
function panel(build){uiOpen=true;const p=$('#panel');p.classList.remove('hide');p.innerHTML='';const box=document.createElement('div');box.className='box';p.appendChild(box);build(box);return box;}
function closePanel(){uiOpen=false;$('#panel').classList.add('hide');$('#panel').innerHTML='';updHud();}
const el=(t,cls,txt,par)=>{const e=document.createElement(t);if(cls)e.className=cls;if(txt!==undefined)e.textContent=txt;par&&par.appendChild(e);return e;};
function pickLine(n){const L=n.lines||['Halo!'];return L[(Math.random()*L.length)|0];}
function openNpc(n){const nm=n.name+' · '+n.job;
 switch(n.svc){
  case 'konbini':return dlg(nm,'いらっしゃいませ! Selamat datang di Konbini.',[{t:'Kerja paruh waktu',fn:()=>jobGame('konbini')},{t:'Onigiri ¥150',fn:()=>buyFood('Onigiri',150)},{t:'Tutup'}]);
  case 'ramen':return dlg(nm,'へい、らっしゃい! Mau ramen panas?',[{t:'Kerja paruh waktu',fn:()=>jobGame('ramen')},{t:'Makan ramen ¥300',fn:()=>buyFood('Ramen',300)},{t:'Tutup'}]);
  case 'takoyaki':return dlg(nm,'Takoyaki hangat, enak lho!',[{t:'Beli ¥100',fn:()=>buyFood('Takoyaki',100)},{t:'Tutup'}]);
  case 'clothes':return dlg(nm,'Selamat datang di butik! Mau ganti gaya?',[{t:'Coba baju',fn:clothesPanel},{t:'Tutup'}]);
  case 'dealer':return dlg(nm,'Kendaraan baru? Sepeda, skuter, sampai mobil sport ada!',[{t:'Lihat kendaraan',fn:dealerPanel},{t:'Tutup'}]);
  case 'school':return dlg(nm,'Selamat datang di kelas. Status belajarmu: '+titleOf(M.iq)+' ('+M.iq+' poin).',[{t:'Ikut pelajaran',fn:quiz},{t:'Tutup'}]);
  case 'omikuji':return dlg(nm,'Mau mencoba omikuji (ramalan keberuntungan)?',[{t:'Coba ¥0',fn:omikuji},{t:'Tutup'}]);
  default:return dlg(nm,pickLine(n),[{t:'OK'}]);}}
function buyFood(nm,p){if(M.coins<p)return toast('Uangmu kurang');addCoins(-p);M.boost=performance.now()+90000;toast(nm+' enak! Tenaga naik 90 detik 🔥');}
const FORT=['大吉 Keberuntungan besar! Hari ini apa pun lancar.','中吉 Keberuntungan menengah. Teruslah belajar.','小吉 Keberuntungan kecil, tapi manis.','吉 Baik. Sapa orang baru hari ini.','末吉 Nanti baik. Sabar ya.'];
let omiT=0;function omikuji(){const f=FORT[(Math.random()*FORT.length)|0];if(Date.now()-omiT>300000){omiT=Date.now();addCoins(50);dlg('Miko',f+'\n\nPersembahan kuil: +¥50',[{t:'Terima kasih'}]);}else dlg('Miko',f,[{t:'Terima kasih'}]);}
/* kerja paruh waktu */
function jobGame(kind){const items=kind==='ramen'?['🍜','🥟','🍵']:['🍙','🥤','🍡'];let round=0,hits=0,target=0,deadline=0,tmr=0;
 panel(b=>{el('h2','',kind==='ramen'?'Kerja di kedai ramen':'Kerja di konbini',b);const ord=el('div','row',''),bar=el('div','bar','',b),ii=el('i','',undefined,bar),inf=el('div','row','',b),big=el('div','big','',b);
  const btns=items.map((e,i)=>{const x=el('button','',e,big);x.onclick=()=>pick(i);return x;});
  const end=el('button','no','Berhenti',b);end.onclick=()=>{clearInterval(tmr);closePanel();};b.insertBefore(ord,bar);
  function next(){if(round>=8){clearInterval(tmr);const pay=hits*14;addCoins(pay);b.innerHTML='';el('h2','','Selesai!',b);el('div','row','Pesanan benar: '+hits+'/8',b);el('div','row','Gaji: ¥'+pay,b);const o=el('button','ok','OK',b);o.onclick=closePanel;return;}
   round++;target=(Math.random()*3)|0;deadline=performance.now()+1700;ord.textContent='Pelanggan '+round+'/8 — pesanan: '+items[target];inf.textContent='Benar: '+hits;}
  function pick(i){if(i===target)hits++;next();}
  tmr=setInterval(()=>{const left=deadline-performance.now();ii.style.width=Math.max(0,left/17)+'%';if(left<=0)next();},60);next();});}
/* sekolah */
const QB=[['「ねこ」artinya?','Kucing','Anjing','Burung','Ikan'],['「いぬ」artinya?','Anjing','Kucing','Kuda','Sapi'],['「みず」artinya?','Air','Api','Angin','Tanah'],['「ありがとう」artinya?','Terima kasih','Maaf','Selamat pagi','Sampai jumpa'],['Ibu kota Jepang?','Tokyo','Osaka','Kyoto','Nagoya'],['Gunung tertinggi di Jepang?','Fuji','Aso','Hakone','Tate'],['7 × 8 = ?','56','54','48','64'],['Bunga simbol musim semi Jepang?','Sakura','Mawar','Melati','Tulip'],['「さようなら」artinya?','Selamat tinggal','Selamat makan','Terima kasih','Permisi'],['12 + 29 = ?','41','39','43','31'],['Makanan nasi dan ikan mentah?','Sushi','Ramen','Tempura','Udon'],['Kereta cepat Jepang?','Shinkansen','Monorel','Trem','Bus'],['「やま」artinya?','Gunung','Sungai','Hutan','Laut'],['100 ÷ 4 = ?','25','20','40','30'],['Pulau terbesar Jepang?','Honshu','Kyushu','Hokkaido','Shikoku'],['「おいしい」artinya?','Enak','Pedas','Besar','Dingin'],['Mata uang Jepang?','Yen','Won','Yuan','Baht'],['「がっこう」artinya?','Sekolah','Rumah','Toko','Stasiun'],['15 × 3 = ?','45','35','55','40'],['「おはよう」dipakai saat?','Pagi hari','Malam hari','Makan','Tidur']];
function quiz(){const qs=QB.slice().sort(()=>Math.random()-.5).slice(0,5);let qi=0,ok=0;
 panel(b=>{function show(){b.innerHTML='';if(qi>=5){const pay=ok*40+(ok===5?100:0);addCoins(pay);M.iq+=ok;patchMe({q:M.iq});el('h2','','Hasil ujian',b);el('div','row','Benar: '+ok+'/5',b);el('div','row','Uang saku: ¥'+pay+(ok===5?' (bonus nilai sempurna!)':''),b);el('div','row','Status: '+titleOf(M.iq)+' ('+M.iq+' poin)',b);const o=el('button','ok','OK',b);o.onclick=closePanel;return;}
  const q=qs[qi],opts=q.slice(1).map((t,i)=>({t,c:i===0})).sort(()=>Math.random()-.5);el('h2','','Pelajaran '+(qi+1)+'/5',b);el('div','row',q[0],b);opts.forEach(o=>{const x=el('button','',o.t,b);x.onclick=()=>{if(o.c)ok++;qi++;show();};});}
  show();});}
/* baju */
const CLOTH_PRICE=60;
function clothesPanel(){const cur=me.a.slice(),orig=me.a.slice();
 panel(b=>{el('h2','','Butik Hana',b);const pv=document.createElement('canvas');pv.width=72;pv.height=100;pv.style.width='144px';pv.style.height='200px';b.appendChild(pv);
  const rows=[['Rambut',0,8,i=>'Warna '+(i+1)],['Gaya rambut',1,4,i=>HSN[i]],['Atasan',2,12,i=>'Model '+(i+1)],['Bawahan',3,8,i=>'Model '+(i+1)],['Aksesori',4,4,i=>ACN[i]]];
  const cost=()=>cur.reduce((s,v,i)=>s+(v!==orig[i]?CLOTH_PRICE:0),0);
  const price=el('div','row','',b);
  function draw(){const x=pv.getContext('2d');x.imageSmoothingEnabled=false;x.clearRect(0,0,72,100);const L=lookOfPlayer({k:me.k,a:cur});const s=charSheet(L);x.drawImage(s,0,0,CW,CH,0,0,72,100);price.textContent='Total: ¥'+cost()+' (¥'+CLOTH_PRICE+'/bagian yang diganti) — uangmu ¥'+M.coins;}
  rows.forEach(([nm,k,n,lab])=>{const r=el('div','row','',b);const bl=el('button','','◀',r),tx=el('span','',nm+': '+lab(cur[k]),r),br=el('button','','▶',r);bl.onclick=()=>{cur[k]=(cur[k]+n-1)%n;tx.textContent=nm+': '+lab(cur[k]);draw();};br.onclick=()=>{cur[k]=(cur[k]+1)%n;tx.textContent=nm+': '+lab(cur[k]);draw();};});
  const buy=el('button','ok','Beli & pakai',b),cx=el('button','no','Batal',b);
  buy.onclick=()=>{const c=cost();if(!c)return closePanel();if(M.coins<c)return toast('Uangmu kurang');addCoins(-c);me.a=cur.slice();patchMe({a:me.a});toast('Gaya baru! Keren 😎');closePanel();};cx.onclick=closePanel;draw();});}
/* dealer */
function dealerPanel(){panel(b=>{el('h2','','Dealer Kendaraan',b);el('div','row','Uangmu: ¥'+M.coins,b);
  for(let i=1;i<VEH.length;i++){const v=VEH[i],own=M.inv.includes(i),r=el('div','row','',b);const pc=document.createElement('canvas');const sp=vehSpr(i,v.t==='car'?1:1);pc.width=sp.c.width;pc.height=sp.c.height;pc.style.background='none';pc.style.border='0';pc.getContext('2d').drawImage(sp.c,0,0);pc.style.width=sp.c.width*2+'px';pc.style.height=sp.c.height*2+'px';r.appendChild(pc);el('span','',v.n+' ¥'+v.p+(v.t==='car'?'':''),r);
   const bt=el('button',own?'':'ok',own?'Dimiliki':'Beli',r);if(own){bt.classList.add('dis');}else bt.onclick=()=>{if(M.coins<v.p)return toast('Uangmu kurang');addCoins(-v.p);M.inv.push(i);patchMe({v:M.inv.join(',')});toast(v.n+' dibeli! Tekan 🚲 untuk naik');dealerPanel();};}
  const cx=el('button','no','Tutup',b);cx.onclick=closePanel;});}
function toggleRide(){if(!M.inv.length)return;if(M.ii)return toast('Tidak bisa naik kendaraan di dalam gedung');M.vd=M.vd?0:Math.max(...M.inv);toast(M.vd?'Naik '+VEH[M.vd].n:'Turun');}
/* rumah */
async function claimLot(l){if(myLots().length>=3)return toast('Maksimal 3 rumah');if(M.coins<600)return toast('Butuh ¥600 untuk membeli lahan');
 try{if(db){const cur=await db.get('lots/'+l.id);if(cur)return toast('Sudah ada yang punya');}else if(lotsData[l.id])return;
  const rec={u:myUid,n:me.name,st:(Math.random()*6)|0,ts:Date.now()};lotsData[l.id]=rec;addCoins(-600);applyLots();saveLocalLots();
  if(db){await db.put('lots/'+l.id,rec);await new Promise(r=>setTimeout(r,700));const chk=await db.get('lots/'+l.id);if(!chk||chk.u!==myUid){delete lotsData[l.id];addCoins(600);applyLots();toast('Keduluan orang lain! Uang dikembalikan');return;}}
  toast('Rumah dibangun! 🏠');logLine('🏠 Kamu membangun rumah');}catch(e){toast('Gagal: '+e.message);}}
async function sellLot(l){delete lotsData[l.id];addCoins(300);applyLots();saveLocalLots();if(db)await db.del('lots/'+l.id);toast('Rumah dibongkar (+¥300)');}

/* ---------- interaksi (tombol A) ---------- */
function interactables(){const out=[];const fx=M.x+[0,-8,8,0][M.dir],fy=M.y+[8,0,0,-8][M.dir]-2;
 const add=(kind,o,x,y,r)=>{const d=Math.hypot(x-fx,y-(fy-6));if(d<r)out.push({kind,o,d});};
 if(M.ii){const I=getInt(M.ii);I.npcs.forEach(n=>add('npc',n,n.x,n.y,26));}
 else{stat.forEach(n=>add('npc',n,n.x,n.y,26));
  const ts=Date.now()/1000;WALKERS.forEach(w=>{const a=A.get('s:'+w.id);if(a&&!a.hidden)add('npc',w,a.x,a.y,22);});
  A.forEach((a,id)=>{if(id.startsWith('r:')&&!a.hidden&&+id.slice(2)!==mySlot)add('res',{id,a},a.x,a.y,20);});
  for(const l of LOTS){const cx=(l.x+l.w/2)*T,cy=(l.y+l.h-1)*T;if(M.x>l.x*T-6&&M.x<(l.x+l.w)*T+6&&M.y>l.y*T&&M.y<(l.y+l.h)*T+8){if(!l.owner||l.owner.uid===myUid)out.push({kind:'lot',o:l,d:Math.hypot(M.x-cx,M.y-cy)*.6});}}}
 out.sort((a,b)=>a.d-b.d);return out;}
function interact(){if(uiOpen||busy)return;const t=interactables()[0];if(!t)return toast('Tidak ada yang bisa diajak bicara');
 if(t.kind==='npc')return openNpc(t.o);
 if(t.kind==='res'){const s=+t.o.id.slice(2),own=ownerOf().get(s),r=own&&players[own];if(r)return dlg(r.n,'Level: '+titleOf(r.q|0)+'\nSedang '+(isOn(own)?'online':'offline')+'.',[{t:'Halo!'}]);return dlg('Warga abu-abu','…(Belum ada pemain yang mengisi warga ini)',[{t:'OK'}]);}
 if(t.kind==='lot'){const l=t.o;if(l.owner)return dlg('Rumahmu','Mau dibongkar jadi lahan kosong? Kamu dapat ¥300 kembali.',[{t:'Bongkar',fn:()=>sellLot(l)},{t:'Batal'}]);return dlg('Lahan kosong 売地','Beli lahan dan bangun rumah seharga ¥600? (Rumahmu: '+myLots().length+'/3, uangmu ¥'+M.coins+')',[{t:'Bangun rumah',fn:()=>claimLot(l)},{t:'Batal'}]);}}

/* ---------- input ---------- */
function toggleChat(on){const b=$('#chatbox');b.classList.toggle('hide',!on);if(on)$('#ci').focus();else $('#ci').blur();}
addEventListener('keydown',e=>{if(e.target.tagName==='INPUT'){if(e.key==='Enter'&&e.target.id==='ci')sendChat();return;}keys[e.code]=true;if(e.code==='KeyE'||e.code==='Space')interact();if(e.code==='Enter')toggleChat(true);if(e.code==='KeyQ')doEm(2);if(e.code==='KeyR')toggleRide();});
addEventListener('keyup',e=>{keys[e.code]=false;});
function doEm(k){if(mySlot<0||M.vd)return;if(k===2&&M.em===2)M.em=0;else{M.em=k;M.emT=k===1?2.4:0;}}
const press=(id,f)=>$(id).addEventListener('pointerdown',e=>{e.preventDefault();f(e);});
press('#bA',interact);press('#bRun',()=>{M.run=!M.run;$('#bRun').classList.toggle('on',M.run);});press('#bWave',()=>doEm(1));press('#bDance',()=>doEm(2));press('#bChat',()=>toggleChat($('#chatbox').classList.contains('hide')));press('#bRide',toggleRide);press('#bExit',()=>{leave();location.reload();});
$('#cs').addEventListener('click',sendChat);
{const J=$('#joy'),K=$('#knob');let id=null;const R0=50;const mv=e=>{const r=J.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const d=Math.hypot(dx,dy);if(d>R0){dx*=R0/d;dy*=R0/d;}joy.x=dx/R0;joy.y=dy/R0;K.style.transform='translate('+dx+'px,'+dy+'px)';};
 J.addEventListener('pointerdown',e=>{e.preventDefault();id=e.pointerId;J.setPointerCapture(id);mv(e);});J.addEventListener('pointermove',e=>{if(e.pointerId===id)mv(e);});
 const up=e=>{if(e.pointerId!==id)return;id=null;joy.x=joy.y=0;K.style.transform='';};J.addEventListener('pointerup',up);J.addEventListener('pointercancel',up);}

/* ---------- menu ---------- */
let selSkin=1;
function drawPreview(){const x=$('#pv').getContext('2d');x.imageSmoothingEnabled=false;x.clearRect(0,0,72,100);x.drawImage(charSheet(lookOfPlayer({k:selSkin,a:me.a})),0,0,CW,CH,0,0,72,100);}
{const sk=$('#sk'),q=new URLSearchParams(location.search);try{const s=JSON.parse(localStorage.getItem('machi2')||'{}');if(s.n)$('#nm').value=s.n;if(s.k!=null)selSkin=s.k;if(s.a)me.a=s.a;myUid=s.uid||'';}catch(_){}
 if(!myUid)myUid='u'+rid()+rid();
 if(!localStorage.getItem('machi2'))randStyle();
 SK.forEach((c,i)=>{const e=document.createElement('i');e.style.background=c;if(i===selSkin)e.className='on';e.onclick=()=>{selSkin=i;[...sk.children].forEach((x,j)=>x.classList.toggle('on',j===i));drawPreview();};sk.appendChild(e);});
 function randStyle(){const r=n=>(Math.random()*n)|0;me.a=[r(8),r(4),r(12),r(8),r(4)===0?1+r(3):0];}
 $('#bRand').onclick=()=>{randStyle();drawPreview();};drawPreview();
 const msg=t=>{$('#msg').textContent=t;};
 $('#bPlay').onclick=async()=>{const url=q.get('db')||DEFAULT_DB;me.name=($('#nm').value.trim()||'Pemain'+((Math.random()*90+10)|0)).slice(0,10);me.k=selSkin;
  try{localStorage.setItem('machi2',JSON.stringify({n:$('#nm').value.trim(),k:selSkin,a:me.a,uid:myUid}));}catch(_){}
  msg('Menyambung ke kota…');$('#bPlay').disabled=true;
  try{await startGame(q.get('offline')?'':url);}catch(e){msg('Gagal: '+e.message+' — coba lagi');$('#bPlay').disabled=false;}};}
async function startGame(url){let cur={};
 if(url){db=new DB(url);cur=await db.get('players')||{};}
 const rec=cur[myUid];let slot;if(rec&&typeof rec.s==='number')slot=rec.s;else{const used=new Set(Object.values(cur).map(r=>r&&r.s)),free=[];for(let i=0;i<NBASE;i++)if(!used.has(i))free.push(i);if(free.length)slot=free[(Math.random()*free.length)|0];else{slot=NBASE;while(used.has(slot))slot++;}}
 mySlot=slot;
 if(rec){M.coins=rec.c===undefined?1500:rec.c|0;M.iq=rec.q|0;M.inv=String(rec.v||'').split(',').filter(Boolean).map(Number);}
 const sp=simAt(mySlot,0,null,Date.now()/1000);let X=sp.x,Y=sp.y;if(solid[ix(X>>4,Y>>4)])Y+=8;M.x=X;M.y=Y;M.dir=0;camP.x=X;camP.y=Y;
 const mine={n:me.name,k:me.k,a:me.a,s:mySlot,x:Math.round(M.x),y:Math.round(M.y),d:0,m:0,e:0,i:'',vd:0,c:M.coins,q:M.iq,v:M.inv.join(','),t:Date.now(),o:1};
 if(db){await db.put('players/'+myUid,mine);players=cur;players[myUid]=mine;db.sub('players',onPlayers);db.sub('lots',root=>{lotsData=root||{};applyLots();});db.sub('chat',onChat,'orderBy='+encodeURIComponent('"$key"')+'&startAt='+encodeURIComponent('"'+Date.now().toString(36)+'"'));}
 else{try{lotsData=JSON.parse(localStorage.getItem('machi2-lots')||'{}');}catch(_){lotsData={};}players={};players[myUid]=mine;applyLots();}
 firstSnap=false;playing=true;t0Play=performance.now();$('#menu').classList.add('hide');$('#hud').classList.remove('hide');$('#rm').textContent=db?'Kota Machi · online':'offline (tanpa server)';updHud();buildMM();
 toast(db?'Kamu mengisi satu warga abu-abu!':'Mode tanpa server: kota hanya di perangkatmu');}

/* ---------- gerak & tabrakan ---------- */
function blocked(x,y,I,self){const hw=5,top=y-4,l=Math.floor((x-hw)/T),r=Math.floor((x+hw-1)/T),t=Math.floor(top/T),b=Math.floor((y-1)/T);
 for(let j=t;j<=b;j++)for(let i=l;i<=r;i++){if(I){if(i<0||j<0||i>=IW||j>=IH||I.sol[j*IW+i])return true;}else{if(i<0||j<0||i>=W||j>=H)return true;if(solid[ix(i,j)]===1)return true;}}
 // staf diam sebagai penghalang
 const list=I?I.npcs:stat;for(const n of list){if(Math.abs(x-n.x)<7&&Math.abs(y-n.y)<6)return true;}return false;}
function tryMove(dx,dy,I){let nx=M.x+dx,ny=M.y;if(!blocked(nx,ny,I))M.x=nx;nx=M.x;ny=M.y+dy;if(!blocked(nx,ny,I))M.y=ny;}
function fadeTo(cb){if(busy)return;busy=true;fadeDir=1;fadeCb=cb;}
function checkDoor(){if(busy)return;if(!M.ii){const t=solid[ix(M.x>>4,(M.y-2)>>4)];if(t===2){const d=doors.get(ix(M.x>>4,(M.y-2)>>4));if(d){fadeTo(()=>{M.ii=d.to;M.ret=d.ret;M.vd=0;M.x=6*T;M.y=8*T+10;M.dir=3;camP.x=M.x;camP.y=M.y;});}}}
 else if(M.y>=9*T+3&&M.x>=5*T&&M.x<=7*T){fadeTo(()=>{M.ii='';M.x=M.ret[0];M.y=M.ret[1];M.dir=0;camP.x=M.x;camP.y=M.y;});}}
function playerStep(dt){if(uiOpen||busy){M.mv=false;return;}let ix_=joy.x+((keys.KeyD||keys.ArrowRight)?1:0)-((keys.KeyA||keys.ArrowLeft)?1:0),iy=joy.y+((keys.KeyS||keys.ArrowDown)?1:0)-((keys.KeyW||keys.ArrowUp)?1:0);
 const m=Math.hypot(ix_,iy);if(m>1){ix_/=m;iy/=m;}const I=M.ii?getInt(M.ii):null;
 if(m>.15){let sp=M.vd?[0,100,130,165,210][M.vd]:(M.run||keys.ShiftLeft?82:52);if(M.boost>performance.now())sp*=1.25;const dx=ix_*sp*dt,dy=iy*sp*dt;tryMove(dx,0,I);tryMove(0,dy,I);
  M.dir=Math.abs(ix_)>Math.abs(iy)?(ix_<0?1:2):(iy>0?0:3);M.mv=true;if(M.em===2)M.em=0;}else M.mv=false;
 if(M.emT>0){M.emT-=dt;if(M.emT<=0&&M.em===1)M.em=0;}
 checkDoor();}
function netSend(now){if(!db||sending)return;const x=Math.round(M.x),y=Math.round(M.y),mv=x!==lastSent.x||y!==lastSent.y||M.em!==lastSent.e||M.vd!==lastSent.vd||M.ii!==lastSent.i||M.dir!==lastSent.d;
 if((mv&&now-lastW>220)||now-lastW>4000){lastW=now;lastSent={x,y,e:M.em,vd:M.vd,i:M.ii,d:M.dir};sending=true;db.patch('players/'+myUid,{x,y,d:M.dir,m:M.mv?1:0,e:M.em,i:M.ii,vd:M.vd,t:Date.now(),o:1}).finally(()=>{sending=false;});}}

/* ---------- gambar ---------- */
const mmCv=$('#mm'),mm=mmCv.getContext('2d');let mmBase=null;
function buildMM(){const[c,x]=mk(224,168);x.drawImage(mapCv,0,OY*T,W*T,(H-OY)*T,0,0,224,168);mmBase=c;}
function actorFor(id,tx,ty,dir,mv,dt,snap){let a=A.get(id);if(!a){a={x:tx,y:ty,dir,mv};A.set(id,a);}const far=Math.hypot(tx-a.x,ty-a.y)>60,k=far||snap?1:Math.min(1,dt*10);a.x+=(tx-a.x)*k;a.y+=(ty-a.y)*k;a.dir=dir;a.mv=mv;a.hidden=false;return a;}
function drawActor(c,a){const x=Math.round(a.x),y=Math.round(a.y);R(c,'rgba(30,20,50,.28)',x-6,y-2,12,4);let dir=a.dir,fr=0,dy=0;
 if(a.veh){const sp=vehSpr(a.veh,dir);c.drawImage(sp.c,Math.round(x-sp.ox),Math.round(y-sp.oy));if(VEH[a.veh].t!=='car')drawChar(c,a.look,dir,dir===0?4:0,x,y-6);return;}
 if(a.sit){fr=4;dir=0;}else if(a.em===1){fr=5;dir=0;}else if(a.em===2){dir=((clock*4)|0)%2?1:2;dy=-(Math.abs(Math.sin(clock*8))*3|0);fr=((clock*8)|0)%4;}else if(a.mv)fr=((clock*9)|0)%4;
 drawChar(c,a.look,dir,fr,x,y+dy);}
const PET=[];for(let i=0;i<34;i++)PET.push({x:Math.random(),y:Math.random(),s:.4+Math.random()*.6});
function render(dt){const w=LW,h=LH;ctx.fillStyle='#1a1420';ctx.fillRect(0,0,w,h);
 const items=[],labels=[],now=Date.now()/1000,I=M.ii?getInt(M.ii):null;let cx,cy;
 const pushA=(a,lab,col)=>{items.push({y:a.y,f:()=>drawActor(ctx2,a)});if(lab)labels.push({a,lab,col});};
 let ctx2=ctx;
 // --- kumpulkan aktor ---
 const cand=[];
 const mine=mySlot>=0&&playing;
 if(!I){
  // warga & pemain
  const own=ownerOf();for(const s of slotList()){const uid=own.get(s),rec=uid&&players[uid],id='r:'+s;
   if(s===mySlot&&mine){const a=actorFor(id,M.x,M.y,M.dir,M.mv,dt,1);a.look=lookOfPlayer({k:me.k,a:me.a});a.em=M.em;a.veh=M.vd;a.hidden=false;a.sit=0;cand.push([a,me.name,'#bfeaff']);continue;}
   if(rec&&isOn(uid)){if((rec.i||'')!==''){A.delete(id);continue;}const a=actorFor(id,rec.x,rec.y,rec.d|0,!!rec.m,dt);a.look=lookOfPlayer(rec);a.em=rec.e|0;a.veh=rec.vd|0;a.sit=0;cand.push([a,rec.n,'#fff']);continue;}
   const sp=simAt(s,0,null,now);if(sp.m===3){A.delete(id);continue;}const a=actorFor(id,sp.x,sp.y,sp.dir,sp.sp>0,dt);a.sit=sp.m===2;a.em=0;a.veh=0;a.look=rec?lookOfPlayer(rec):lookOfSlot(s);cand.push([a,rec?rec.n:'',rec?'#c8c8d4':null]);}
  // staf berjalan
  for(const wk of WALKERS){const sp=simAt('s:'+wk.id,wk.spd,wk.opt,now);const id='s:'+wk.id;if(sp.m===3){const a=A.get(id);if(a)a.hidden=true;continue;}const a=actorFor(id,sp.x,sp.y,sp.dir,sp.sp>0,dt);a.sit=sp.m===2;a.look=wk.look;a.veh=wk.veh||0;a.em=0;cand.push([a,null,null]);}
  // staf diam
  for(const n of stat){const id='n:'+n.id;let a=A.get(id);if(!a){a={x:n.x,y:n.y,dir:n.dir,mv:false};A.set(id,a);}a.look=n.look;a.dir=n.dir;a.em=0;a.sit=0;a.veh=0;cand.push([a,null,null]);}
 }else{
  for(const n of I.npcs){const id='i:'+M.ii+n.id;let a=A.get(id);if(!a){a={x:n.x,y:n.y,dir:n.dir,mv:false};A.set(id,a);}a.look=n.look;a.dir=n.dir;a.em=0;a.sit=0;a.veh=0;cand.push([a,null,null]);}
  const own=ownerOf();for(const uid in players){const rec=players[uid];if(uid===myUid||!isOn(uid)||(rec.i||'')!==M.ii)continue;const id='p:'+uid;const a=actorFor(id,rec.x,rec.y,rec.d|0,!!rec.m,dt);a.look=lookOfPlayer(rec);a.em=rec.e|0;a.veh=0;a.sit=0;cand.push([a,rec.n,'#fff']);}
  if(mine){const id='r:'+mySlot;const a=actorFor(id,M.x,M.y,M.dir,M.mv,dt,1);a.look=lookOfPlayer({k:me.k,a:me.a});a.em=M.em;a.veh=0;a.sit=0;cand.push([a,me.name,'#bfeaff']);}}
 // --- kamera ---
 const tx=mine?M.x:(playing?M.x:Math.sin(clock*.05)*400+W*T/2),ty=mine?M.y-10:Math.cos(clock*.04)*250+H*T/2;
 camP.x+=(tx-camP.x)*Math.min(1,dt*(M.vd?10:7));camP.y+=(ty-camP.y)*Math.min(1,dt*(M.vd?10:7));
 if(I){cx=IW*T<=w?Math.round(IW*T/2-w/2):Math.round(Math.max(0,Math.min(IW*T-w,camP.x-w/2)));cy=IH*T<=h?Math.round(IH*T/2-h/2)-8:Math.round(Math.max(0,Math.min(IH*T-h,camP.y-h/2)));}
 else{cx=Math.round(Math.max(0,Math.min(W*T-w,camP.x-w/2)));cy=Math.round(Math.max(0,Math.min(H*T-h,camP.y-h/2)));}
 ctx.save();ctx.translate(-cx,-cy);
 if(!I){ctx.drawImage(mapCv,cx,cy,w,h,cx,cy,w,h);
  // riak air kolam
  for(const p of PONDS){const X=p.x*T,Y=p.y*T;if(X+4*T<cx||X>cx+w||Y+4*T<cy||Y>cy+h)continue;for(let i=0;i<6;i++){const rx=X+4+((i*23+clock*9)%(4*T-10)),ry=Y+4+((i*17)%(4*T-10));R(ctx,'#b4e4fa',rx,ry,3,1);}}
  // kereta
  for(const[ty0,dir,sp0,off]of[[3*T+1,1,60,0],[4*T+1,-1,48,900]]){const L=W*T+6*60,pos=(((now*sp0*dir+off)%L)+L)%L-6*60;for(let k=0;k<6;k++){const X=pos+k*61;if(X+60<cx||X>cx+w)continue;ctx.drawImage(trainCar,Math.round(X),ty0-4);}}
  // mobil
  for(const c of CARS){const len=c.ax?(H-OY-2)*T:(W-2)*T,pos=(((c.off+c.dir*c.sp*now)%len)+len)%len;let X,Y,d;if(c.ax){X=c.lane*T+8;Y=(OY+1)*T+pos;d=c.dir>0?0:3;}else{Y=c.lane*T+13;X=T+pos;d=c.dir>0?2:1;}if(X<cx-40||X>cx+w+40||Y<cy-40||Y>cy+h+60)continue;const sp=carSpr(c.col,d,0,c.van?'van':'');items.push({y:Y,f:()=>ctx.drawImage(sp.c,Math.round(X-sp.ox),Math.round(Y-sp.oy))});}
  for(const o of objs){if(o.x<cx-50||o.x>cx+w+50||o.y<cy||o.y>cy+h+60)continue;items.push({y:o.y,f:()=>ctx.drawImage(o.s.c,Math.round(o.x-o.s.ox),Math.round(o.y-o.s.oy))});}
 }else{ctx.drawImage(I.cv,0,0);for(const c of I.cars)items.push({y:c.y,f:()=>ctx.drawImage(c.c,c.x-c.ox,c.y-c.oy)});}
 for(const[a,lab,col]of cand){if(a.x<cx-30||a.x>cx+w+30||a.y<cy-10||a.y>cy+h+40)continue;items.push({y:a.y+(a.veh?4:0),f:()=>drawActor(ctx,a)});if(lab)labels.push({a,lab,col});}
 items.sort((p,q)=>p.y-q.y);for(const it of items)it.f();
 if(I)ctx.drawImage(I.fr,0,0);
 // label nama & gelembung chat
 for(const l of labels){const y=Math.round(l.a.y)-(l.a.veh&&VEH[l.a.veh].t==='car'?18:32);drawText(ctx,l.lab,l.a.x,y-8,l.col||'#fff');}
 for(const[id,b]of bubbles){const a=A.get(id);if(!a)continue;b.t-=dt;if(b.t<=0){bubbles.delete(id);continue;}const tw=isLatin(b.txt)?btext(b.txt,'#2a2030','#ffffff'):ptext(b.txt,'#2a2030',null),bw=tw.width+8,bx=Math.round(a.x-bw/2),by=Math.round(a.y)-52;R(ctx,INK,bx-1,by-1,bw+2,16);R(ctx,'#fff',bx,by,bw,14);R(ctx,INK,Math.round(a.x)-2,by+14,5,3);R(ctx,'#fff',Math.round(a.x)-1,by+14,3,2);ctx.drawImage(tw,bx+4,by+1);}
 ctx.restore();
 // kelopak sakura
 if(!I){for(const p of PET){p.y+=dt*.05*p.s;p.x+=dt*.02*p.s;if(p.y>1.05){p.y=-.05;p.x=Math.random();}if(p.x>1.05)p.x=-.05;R(ctx,'#ffc2d8',(p.x*w)|0,(p.y*h)|0,2,1);R(ctx,'#ff9fc0',((p.x*w)|0)+1,((p.y*h)|0)+1,1,1);}}
 // fade
 if(fadeDir){fadeA+=fadeDir*dt*5;if(fadeA>=1){fadeA=1;fadeDir=-1;if(fadeCb){fadeCb();fadeCb=null;A.clear();}}else if(fadeA<=0){fadeA=0;fadeDir=0;busy=false;}}
 if(fadeA>0){ctx.fillStyle='rgba(20,12,30,'+fadeA+')';ctx.fillRect(0,0,w,h);}
 return{cx,cy};}
function drawMM(){mm.clearRect(0,0,224,168);if(mmBase){mm.drawImage(mmBase,0,0);}else{mm.fillStyle='#222';mm.fillRect(0,0,224,168);}
 for(const l of LOTS){const X=(l.x*T)/(W*T)*224,Y=((l.y-OY)*T)/((H-OY)*T)*168;mm.fillStyle=l.owner?(l.owner.uid===myUid?'#37e6ff':'#ff9a3a'):'#ffd23a';mm.fillRect(X,Y,6,5);}
 if(M.ii){return;}
 const pt=(x,y)=>[x/(W*T)*224,(y-OY*T)/((H-OY)*T)*168];
 const own=ownerOf();for(const s of slotList()){const a=A.get('r:'+s);if(!a||a.hidden)continue;const[X,Y]=pt(a.x,a.y),uid=own.get(s);mm.fillStyle=s===mySlot?'#37e6ff':uid?'#ff5a7a':'#9a9ca6';mm.beginPath();mm.arc(X,Y,s===mySlot?5:2.6,0,7);mm.fill();if(s===mySlot||uid){mm.strokeStyle='#fff';mm.lineWidth=1.5;mm.stroke();}}}
/* petunjuk kontekstual */
function updHint(){const h=$('#hint');if(uiOpen||busy||!playing){h.classList.add('hide');return;}const t=interactables()[0];if(!t){h.classList.add('hide');return;}
 const txt=t.kind==='npc'?'A: bicara dengan '+t.o.name:t.kind==='lot'?(t.o.owner?'A: bongkar rumah':'A: beli lahan (¥600)'):'A: sapa';h.textContent=txt;h.classList.remove('hide');}

let last=performance.now(),mmT=0,hT=0;
function loop(now){requestAnimationFrame(loop);const dt=Math.min(.05,(now-last)/1000);last=now;clock+=dt;
 if(playing){playerStep(dt);netSend(now);}
 render(dt);
 if(playing&&now-mmT>150){mmT=now;drawMM();}if(playing&&now-hT>200){hT=now;updHint();}}
requestAnimationFrame(loop);
window.__g={M,A,get db(){return db},get slot(){return mySlot},players:()=>players,lots:()=>lotsData,LOTS,doors,solid,joy,keys,interact,openNpc,stat,WALKERS,get playing(){return playing},getInt,clothesPanel,dealerPanel,quiz,jobGame,addCoins,toggleRide,INT,render};
window.__ready=true;

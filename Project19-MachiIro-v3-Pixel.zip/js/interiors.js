/* ===== INTERIOR (ruangan di dalam gedung) ===== */
const IW=12,IH=10,INT={};
const G=(skin)=>({skin:GRAYSK,hair:GRAYHAIR,hs:0});
const lk=(o)=>Object.assign({skin:GRAYSK,hair:GRAYHAIR,hs:0},o);
function makeInt(key,th){const[cv,x]=mk(IW*T,IH*T),[fr,fx]=mk(IW*T,IH*T),sol=new Uint8Array(IW*IH),r=mulberry32(key.length*77+key.charCodeAt(0));
 const I={key,cv,fr,sol,npcs:[],cars:[]};const S=(a,b,w,h)=>{for(let j=0;j<h;j++)for(let i=0;i<w;i++)if(a+i>=0&&b+j>=0&&a+i<IW&&b+j<IH)sol[(b+j)*IW+a+i]=1;};
 // lantai
 for(let j=2;j<9;j++)for(let i=1;i<11;i++){const X=i*T,Y=j*T;
  if(th.floor==='check'){R(x,(i+j)%2?'#eef0f6':'#d8dbe6',X,Y,T,T);R(x,'#c6cad8',X,Y+15,T,1);}
  else if(th.floor==='tatami'){R(x,'#cfdc8e',X,Y,T,T);R(x,'#aebd6c',X,Y,T,1);R(x,'#aebd6c',X,Y,1,T);R(x,'#e0ecaa',X+3,Y+3,2,1);if((i+j)%2===0)R(x,'#8a9a50',X+7,Y,1,T);}
  else if(th.floor==='gray'){R(x,(i+j)%2?'#b8bcc8':'#c8ccd8',X,Y,T,T);R(x,'#a8acb8',X,Y+15,T,1);R(x,'#dfe2ec',X+2,Y+2,4,1);}
  else tileWood(x,X,Y,r,th.floor,shade(th.floor,-.14));}
 // dinding atas
 R(x,th.wall,0,0,IW*T,2*T);R(x,shade(th.wall,-.1),0,2*T-3,IW*T,3);R(x,th.trim,0,T+4,IW*T,T-6);R(x,shade(th.trim,-.2),0,2*T-6,IW*T,3);R(x,INK,0,2*T,IW*T,1);
 // dinding samping & bawah
 R(x,shade(th.wall,-.25),0,2*T,T,8*T);R(x,shade(th.wall,-.25),11*T,2*T,T,8*T);R(x,INK,T-1,2*T,1,7*T);R(x,INK,11*T,2*T,1,7*T);
 R(x,shade(th.wall,-.2),0,9*T,IW*T,T);R(x,th.trim,0,9*T+4,IW*T,T-4);R(x,INK,0,9*T,IW*T,1);
 R(x,'#7a2a2a',5*T,9*T,2*T,T);R(x,'#9a3a3a',5*T+1,9*T+1,2*T-2,T-2);R(x,'#c44',5*T+2,9*T+3,2*T-4,2);S(0,0,IW,2);S(0,2,1,8);S(11,2,1,8);for(let i=0;i<IW;i++)if(i!==5&&i!==6)S(i,9,1,1);
 I.exit=[5,6];
 const ob=(a,b,w,h,fn,front)=>{(front?fx:x).save();fn(front?fx:x,a*T,b*T,w*T,h*T);(front?fx:x).restore();};
 th.build(I,{x,fx,R,S,ob,r});
 return I;}
const shelfFn=(cols)=>(c,X,Y,w,h)=>{R(c,INK,X,Y+2,w,h-2);R(c,'#d8c8a8',X+1,Y+3,w-2,h-5);R(c,'#a8946a',X+1,Y+h-5,w-2,3);for(let i=0;i<w-6;i+=5)R(c,cols[(i/5|0)%cols.length],X+3+i,Y+5,4,5),R(c,cols[((i/5|0)+1)%cols.length],X+3+i,Y+h-11,4,5);R(c,'rgba(0,0,0,.2)',X,Y+h-1,w,3);};
const counterFn=(top,body)=>(c,X,Y,w,h)=>{R(c,INK,X,Y+2,w,h-1);R(c,body,X+1,Y+6,w-2,h-8);R(c,top,X+1,Y+3,w-2,5);R(c,shade(top,.3),X+1,Y+3,w-2,1);R(c,'rgba(0,0,0,.2)',X,Y+h,w,3);};
const INTDEF={
 konbini:{floor:'check',wall:'#f4f6fa',trim:'#3ab070',build(I,{x,ob,S}){
  for(let i=0;i<8;i++){R(x,INK,(2+i)*T+1,T-2,T-2,T);R(x,'#cfeaff',(2+i)*T+2,T-1,T-4,T-3);R(x,['#e0524f','#4a7fe0','#f2c230','#4cb87a'][i%4],(2+i)*T+4,T+4,T-8,5);}
  ob(2,4,3,1,shelfFn(['#e0524f','#f2c230','#4cb87a']));S(2,4,3,1);ob(2,6,3,1,shelfFn(['#4a7fe0','#e868a8','#f2c230']));S(2,6,3,1);ob(6,5,3,1,shelfFn(['#4cb87a','#e0524f']));S(6,5,3,1);
  ob(8,3,3,1,counterFn('#e8e8f0','#3ab070'),0);S(8,3,3,1);R(x,INK,9*T+4,3*T-2,8,6);R(x,'#7fe0a0',9*T+5,3*T-1,6,3);
  I.npcs.push({id:'kon',name:'Tenin Aoi',job:'Kasir Konbini',x:9*T+8,y:3*T-2,dir:0,svc:'konbini',look:lk({top:'#3ab070',bot:'#2a3a5a',hs:3,prop:'apron',hat:'#3ab070'})});}},
 cloth:{floor:'#e0b890',wall:'#fbe8f0',trim:'#d95a9a',build(I,{x,ob,S}){
  const rack=(c,X,Y,w,h)=>{R(c,INK,X,Y+10,w,3);R(c,'#8a6a4a',X+1,Y+5,w-2,2);const cc=TOPC;for(let i=0;i<w-5;i+=6){R(c,cc[(i/6+X/7|0)%12],X+2+i,Y+7,5,9);R(c,shade(cc[(i/6+X/7|0)%12],-.2),X+2+i,Y+13,5,3);}R(c,'rgba(0,0,0,.2)',X,Y+h,w,3);};
  ob(1,3,3,1,rack);S(1,3,3,1);ob(1,5,3,1,rack);S(1,5,3,1);ob(7,6,3,1,rack);S(7,6,3,1);
  R(x,INK,6*T,T-4,2*T,T+2);R(x,'#cfeaff',6*T+2,T-2,2*T-4,T-2);R(x,'#fff',6*T+4,T,3,3);
  ob(8,3,3,1,counterFn('#fbe8f0','#d95a9a'));S(8,3,3,1);
  I.npcs.push({id:'tailor',name:'Bu Hana',job:'Penjahit & Penjual Baju',x:9*T+8,y:3*T-2,dir:0,svc:'clothes',look:lk({top:'#f4f4f8',bot:'#8a3a6a',hs:3,ac:3})});}},
 dealer:{floor:'gray',wall:'#eef2fa',trim:'#2a6ad9',build(I,{x,ob,S}){
  const cols=['#e0303a','#f2c230','#4a7fe0'];[[2,4],[5,4],[8,4]].forEach(([a,b],i)=>{const s=carSpr(cols[i],0,i===0?1:0);I.cars.push({c:s.c,x:a*T+16,y:b*T+22,ox:s.ox,oy:s.oy});R(x,'#d8dbe6',a*T-4,b*T-4,2*T+8,2*T+10);R(x,'#aab0c4',a*T-4,b*T-4,2*T+8,2);});S(2,3,2,2);S(5,3,2,2);S(8,3,2,2);
  ob(8,7,3,1,counterFn('#eef2fa','#2a6ad9'));S(8,7,3,1);
  I.npcs.push({id:'dealerin',name:'Dealer Kenji',job:'Penjual Kendaraan',x:9*T+8,y:7*T-2,dir:0,svc:'dealer',look:lk({top:'#2e3446',bot:'#2e3446',collar:'#fff',tie:'#d9382e'})});}},
 school:{floor:'#d9b27a',wall:'#f0ece0',trim:'#4a6aa8',build(I,{x,fx,ob,S}){
  R(x,INK,3*T,T-4,6*T,T+2);R(x,'#2a6a3a',3*T+1,T-3,6*T-2,T);R(x,'#8a6a3a',3*T+1,2*T-2,6*T-2,2);for(let i=0;i<5;i++)R(x,'#fff',3*T+6+i*14,T+2,8,1);drawText(x,'ABC あいう 123',6*T,T-1,'#fff',null);
  const desk=(c,X,Y,w,h)=>{R(c,INK,X,Y+4,w,h-3);R(c,'#c8964a',X+1,Y+5,w-2,6);R(c,'#e0b068',X+1,Y+5,w-2,1);R(c,'#8a6030',X+2,Y+11,3,5);R(c,'#8a6030',X+w-5,Y+11,3,5);};
  const lkS=(t)=>lk({top:'#fff',collar:'#2a3a6a',tie:'#d9382e',bot:'#2a3a6a',hs:t%4});
  [[2,5],[5,5],[8,5],[2,7],[5,7],[8,7]].forEach(([a,b],i)=>{ob(a,b,2,1,desk,1);S(a,b,2,1);if(i!==1&&i!==4)I.npcs.push({id:'sw'+i,name:'Murid',job:'Pelajar',x:a*T+16,y:b*T+10,dir:3,svc:'talk',look:lkS(i),lines:['Sensei lagi mengajar, jangan ribut ya!','Aku mau jadi juara kelas.','Ssst, ujian sebentar lagi...','Ayo ikut pelajaran biar dapat uang saku!'],sit:1});});
  I.npcs.push({id:'sensei',name:'Sensei Mori',job:'Guru',x:6*T,y:3*T+8,dir:0,svc:'school',look:lk({top:'#7a5a3a',bot:'#4a4a56',ac:2,hs:0})});}},
 ramen:{floor:'#b0794a',wall:'#f0d8b0',trim:'#d9382e',build(I,{x,ob,S}){
  R(x,INK,2*T,T-6,3*T,T);R(x,'#f4e8c0',2*T+1,T-5,3*T-2,T-2);drawText(x,'お品書き',3*T+8,T-5,'#8a2a1a',null);R(x,INK,7*T,T-6,3*T,T);R(x,'#d9382e',7*T+1,T-5,3*T-2,T-2);drawText(x,'ラーメン',8*T+8,T-5,'#fff',null);
  ob(3,3,6,1,counterFn('#e8c890','#8a4a2a'));S(3,3,6,1);for(let i=0;i<5;i++){R(x,INK,(3+i)*T+16,4*T+4,10,10);R(x,'#d9382e',(3+i)*T+17,4*T+5,8,5);}
  for(let i=0;i<4;i++){R(x,'#fff',(3+i*2)*T+8,3*T+2,8,4);R(x,'#e0a040',(3+i*2)*T+9,3*T+2,6,2);}
  S(3,4,6,1);ob(2,7,2,1,(c,X,Y,w,h)=>{R(c,INK,X,Y+3,w,h-3);R(c,'#c8964a',X+1,Y+4,w-2,5);},0);S(2,7,2,1);ob(8,7,2,1,(c,X,Y,w,h)=>{R(c,INK,X,Y+3,w,h-3);R(c,'#c8964a',X+1,Y+4,w-2,5);},0);S(8,7,2,1);
  I.npcs.push({id:'chef',name:'Chef Taro',job:'Koki Ramen',x:6*T,y:3*T-1,dir:0,svc:'ramen',look:lk({top:'#fff',bot:'#2a2a3a',hat:'#fff',hs:0})});}},
 clinic:{floor:'check',wall:'#eaf6f2',trim:'#2aa66a',build(I,{x,ob,S}){
  const bed=(c,X,Y,w,h)=>{R(c,INK,X,Y,w,h);R(c,'#fff',X+1,Y+1,w-2,h-2);R(c,'#9fd6c8',X+1,Y+h/2,w-2,h/2-1);R(c,'#e8eef4',X+2,Y+3,w-4,6);};
  ob(2,3,2,2,bed);S(2,3,2,2);ob(5,3,2,2,bed);S(5,3,2,2);ob(8,3,3,1,counterFn('#fff','#2aa66a'));S(8,3,3,1);R(x,INK,7*T+2,T-4,3*T,T);R(x,'#fff',7*T+3,T-3,3*T-2,T-2);R(x,'#2aa66a',8*T+4,T-1,10,3);R(x,'#2aa66a',8*T+8,T-3,3,9);
  I.npcs.push({id:'nurse',name:'Suster Mika',job:'Perawat',x:9*T+8,y:3*T-2,dir:0,svc:'talk',look:lk({top:'#fff',bot:'#fff',hat:'#f08aa8',hs:3}),lines:['Jaga kesehatan ya! Jangan lari terus-terusan.','Kalau capek, duduk saja di bangku taman.','Makan takoyaki juga bikin semangat!']});}},
 koban:{floor:'gray',wall:'#e4ecf8',trim:'#3a4a8a',build(I,{x,ob,S}){
  R(x,INK,2*T,T-4,3*T,T);R(x,'#fff',2*T+1,T-3,3*T-2,T-2);R(x,'#3a6ad9',2*T+3,T-1,3*T-6,2);R(x,'#d9382e',3*T,T+3,8,6);
  ob(4,4,4,1,counterFn('#c8ccd8','#3a4a8a'));S(4,4,4,1);ob(8,6,2,2,(c,X,Y,w,h)=>{R(c,INK,X,Y+2,w,h-2);R(c,'#aab0c4',X+1,Y+3,w-2,h-5);R(c,'#8a90a8',X+3,Y+6,w-6,3);});S(8,6,2,2);
  I.npcs.push({id:'koban',name:'Polisi Sato',job:'Polisi',x:6*T,y:4*T-1,dir:0,svc:'talk',look:lk({top:'#3a5a9a',bot:'#2a3a6a',hat:'#2a3a6a',badge:1}),lines:['Kota ini aman! Ada lahan kosong bertanda 売地 — beli dan bangun rumahmu.','Naik kendaraan boleh, tapi hati-hati di zebra cross.','Selamat datang di Machi-Iro!']});}},
 house:{floor:'tatami',wall:'#f4ead4',trim:'#8a5a3a',build(I,{x,ob,S}){
  ob(2,3,2,3,(c,X,Y,w,h)=>{R(c,INK,X,Y,w,h);R(c,'#f4f0e8',X+1,Y+1,w-2,h-2);R(c,'#e868a8',X+1,Y+14,w-2,h-15);R(c,'#fff',X+3,Y+3,w-6,8);});S(2,3,2,3);
  ob(6,4,3,2,(c,X,Y,w,h)=>{R(c,INK,X+4,Y+4,w-8,h-8);R(c,'#a8683a',X+5,Y+5,w-10,h-12);R(c,'#c88a52',X+5,Y+5,w-10,2);R(c,'#e0524f',X+2,Y+12,6,6);R(c,'#4a7fe0',X+w-8,Y+12,6,6);R(c,'#e0524f',X+w-24,Y,6,5);});S(7,4,2,2);
  R(x,INK,8*T,T-4,2*T,T);R(x,'#cfeaff',8*T+2,T-2,2*T-4,T-4);R(x,'#fff',8*T+4,T-1,3,3);R(x,INK,3*T,T-6,T,T+4);R(x,'#f4f0e0',3*T+2,T-4,T-4,T);R(x,'#2a2030',3*T+6,T-2,2,10);
  ob(9,6,1,2,(c,X,Y,w,h)=>{R(c,INK,X,Y,w,h);R(c,'#a8683a',X+1,Y+1,w-2,h-2);for(let k=0;k<4;k++)R(c,['#e0524f','#4a7fe0','#f2c230','#4cb87a'][k],X+3,Y+3+k*7,w-6,4);});S(9,6,1,2);}}
};
function getInt(key){const base=key.startsWith('h:')?'house':key;let I=INT[key];if(I)return I;const th=INTDEF[base];I=makeInt(key,th);INT[key]=I;return I;}

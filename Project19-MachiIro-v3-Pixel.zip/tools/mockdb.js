// Mock Firebase Realtime DB (REST + SSE) untuk tes lokal: node mockdb.js [port]
const http=require('http'),url=require('url');let tree=null;const subs=[];
const pp=s=>s.split('/').filter(Boolean);
function getAt(parts){let o=tree;for(const k of parts){if(o==null||typeof o!=='object')return null;o=o[k];}return o===undefined?null:o;}
function setAt(parts,val){if(!parts.length){tree=val;return;}if(tree==null||typeof tree!=='object')tree={};let o=tree;for(let i=0;i<parts.length-1;i++){if(o[parts[i]]==null||typeof o[parts[i]]!=='object')o[parts[i]]={};o=o[parts[i]];}const k=parts[parts.length-1];if(val===null)delete o[k];else o[k]=val;}
function clean(v){if(v&&typeof v==='object'){for(const k of Object.keys(v)){v[k]=clean(v[k]);if(v[k]===null)delete v[k];}if(!Object.keys(v).length)return null;}return v;}
function view(s){let v=getAt(s.parts);if(s.start&&v&&typeof v==='object'){const o={};for(const k of Object.keys(v))if(k>=s.start)o[k]=v[k];v=Object.keys(o).length?o:null;}return v;}
function push(s){s.res.write('event: put\ndata: '+JSON.stringify({path:'/',data:view(s)})+'\n\n');}
http.createServer((req,res)=>{const u=url.parse(req.url,true);res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('Access-Control-Allow-Headers','*');res.setHeader('Access-Control-Allow-Methods','GET,PUT,PATCH,DELETE,OPTIONS');
 if(req.method==='OPTIONS'){res.writeHead(204);return res.end();}
 const parts=pp(decodeURIComponent(u.pathname).replace(/\.json$/,''));
 if(req.method==='GET'&&(req.headers.accept||'').includes('text/event-stream')){res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache'});const s={parts,res,start:u.query.startAt?String(u.query.startAt).replace(/"/g,''):null};subs.push(s);push(s);req.on('close',()=>{const i=subs.indexOf(s);if(i>=0)subs.splice(i,1);});return;}
 if(req.method==='GET'){res.writeHead(200,{'Content-Type':'application/json'});return res.end(JSON.stringify(getAt(parts)));}
 let b='';req.on('data',d=>b+=d);req.on('end',()=>{const v=b?JSON.parse(b):null;
  if(req.method==='PUT')setAt(parts,clean(v));else if(req.method==='PATCH'){for(const k of Object.keys(v))setAt(parts.concat(pp(k)),clean(v[k]));}else if(req.method==='DELETE')setAt(parts,null);
  res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(v));
  subs.forEach(s=>{const a=s.parts.join('/'),w=parts.join('/');if(a.startsWith(w)||w.startsWith(a))push(s);});});
}).listen(+process.argv[2]||9000,()=>console.log('mockdb on',process.argv[2]||9000));

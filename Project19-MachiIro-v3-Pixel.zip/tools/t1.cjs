module.exports=async p=>{const D='/tmp/claude-0/-home-claude/c0abfcb4-d4e7-5838-80b2-837f447da839/scratchpad/p20/';
 await p.waitForTimeout(1200);await p.screenshot({path:D+'shots/menu.png'});
 await p.click('#bPlay');await p.waitForTimeout(1500);
 console.log('LOG',JSON.stringify(await p.evaluate(()=>({pl:__g.playing,x:__g.M.x,y:__g.M.y,slot:__g.slot}))));
 await p.screenshot({path:D+'shots/g1.png'});
};

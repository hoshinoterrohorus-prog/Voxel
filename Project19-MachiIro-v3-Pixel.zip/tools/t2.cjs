module.exports=async p=>{const D='/tmp/claude-0/-home-claude/c0abfcb4-d4e7-5838-80b2-837f447da839/scratchpad/p20/';
 await p.click('#bPlay');await p.waitForTimeout(800);
 const tp=async(x,y,n,ms)=>{await p.evaluate(([x,y])=>{__g.M.x=x;__g.M.y=y;},[x,y]);await p.waitForTimeout(ms||900);await p.screenshot({path:D+'shots/'+n+'.png'});};
 // pintu-pintu
 const doors=await p.evaluate(()=>[...__g.doors.entries()].map(([k,v])=>[k%108,(k/108)|0,v.to]));
 console.log('LOG doors',JSON.stringify(doors.filter(d=>!d[2].startsWith('h:'))));
 const find=n=>doors.find(d=>d[2]===n);
 for(const n of ['konbini','cloth','dealer','school']){const d=find(n);if(!d)continue;await tp(d[0]*16+8,(d[1]+1)*16+10,'o_'+n,700);await p.evaluate(([x,y])=>{__g.M.x=x;__g.M.y=y-4;},[d[0]*16+8,d[1]*16+10]);await p.waitForTimeout(1000);await p.screenshot({path:D+'shots/i_'+n+'.png'});
  console.log('LOG in',n,await p.evaluate(()=>__g.M.ii));await p.evaluate(()=>{__g.M.x=6*16;__g.M.y=9*16+6;});await p.waitForTimeout(1000);console.log('LOG out',await p.evaluate(()=>__g.M.ii));}
};

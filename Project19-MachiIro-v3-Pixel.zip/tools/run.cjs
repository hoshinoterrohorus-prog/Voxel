const {chromium}=require('playwright');
(async()=>{const [,,file,script]=process.argv;
const b=await chromium.launch({args:['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream']});
const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,permissions:[]});
const p=await ctx.newPage();
p.on('console',m=>{const t=m.text();if(m.type()==='error'||/^LOG/.test(t))console.log('['+m.type()+']',t.slice(0,300));});p.on('pageerror',e=>console.log('PAGEERR',e.message.slice(0,400),(e.stack||'').slice(0,300)));
await p.goto('file://'+file);await p.waitForFunction('window.__ready',null,{timeout:20000});
await require(script)(p);await b.close();})().catch(e=>{console.log('FAIL',e.message.slice(0,500));process.exit(1)});

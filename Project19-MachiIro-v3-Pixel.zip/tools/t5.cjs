module.exports=async p=>{const D='/tmp/claude-0/-home-claude/c0abfcb4-d4e7-5838-80b2-837f447da839/scratchpad/p20/';
 await p.fill('#nm','Rina');await p.click('#bPlay');await p.waitForTimeout(800);
 await p.evaluate(()=>{__g.M.inv=[1,2,3,4];__g.addCoins(0);__g.M.x=20*16;__g.M.y=7*16+8;});await p.waitForTimeout(300);
 await p.evaluate(()=>__g.toggleRide());await p.evaluate(()=>{__g.joy.x=1;});await p.waitForTimeout(1800);await p.screenshot({path:D+'shots/v_car.png'});
 await p.evaluate(()=>{__g.joy.x=0;__g.M.vd=1;});await p.waitForTimeout(400);await p.evaluate(()=>{__g.joy.y=1;});await p.waitForTimeout(500);await p.screenshot({path:D+'shots/v_bike.png'});await p.evaluate(()=>{__g.joy.y=0;__g.M.vd=0;});
 // job game
 await p.evaluate(()=>__g.jobGame('konbini'));await p.waitForTimeout(400);for(let i=0;i<9;i++){await p.click('#panel .big button:nth-child('+(1+i%3)+')').catch(()=>{});await p.waitForTimeout(120);}await p.screenshot({path:D+'shots/v_job.png'});
 console.log('LOG coins',await p.evaluate(()=>__g.M.coins));
 // quiz selesai
 await p.evaluate(()=>{document.querySelector('#panel .ok')&&document.querySelector('#panel .ok').click();__g.quiz();});for(let i=0;i<5;i++){await p.waitForTimeout(100);await p.click('#panel .box>button:nth-child(3)').catch(()=>{});}await p.screenshot({path:D+'shots/v_quiz.png'});
 console.log('LOG iq',await p.evaluate(()=>__g.M.iq));
};

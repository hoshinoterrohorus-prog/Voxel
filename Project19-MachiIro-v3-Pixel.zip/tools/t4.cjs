const {chromium}=require('playwright');const {spawn}=require('child_process');
const D='/tmp/claude-0/-home-claude/c0abfcb4-d4e7-5838-80b2-837f447da839/scratchpad/p20/';
(async()=>{
 const db=spawn('node',[D+'tools/mockdb.js','9000']);const srv=spawn('python3',['-m','http.server','8766','-d',D]);await new Promise(r=>setTimeout(r,900));
 const b=await chromium.launch();
 const mk=async n=>{const ctx=await b.newContext({viewport:{width:390,height:844}});const p=await ctx.newPage();p.on('console',m=>{if(m.type()==='error')console.log('['+n+'] ERR',m.text().slice(0,200));});p.on('pageerror',e=>console.log('['+n+'] PAGEERR',e.message.slice(0,300)));await p.goto('http://localhost:8766/out.html?db=http://localhost:9000');await p.waitForFunction('window.__ready');return p;};
 const A=await mk('A'),B=await mk('B');
 for(const [p,n] of [[A,'Aditya'],[B,'Budi']]){await p.fill('#nm',n);await p.click('#bPlay');await p.waitForTimeout(1300);}
 await A.waitForTimeout(6000);
 const st=p=>p.evaluate(()=>({slot:__g.slot,cnt:document.querySelector('#cnt').textContent,pl:Object.values(__g.players()).map(r=>r.n+':'+r.s)}));
 console.log('LOG A',JSON.stringify(await st(A)));console.log('LOG B',JSON.stringify(await st(B)));
 // B jalan ke dekat A
 await B.evaluate(()=>{const g=__g;const a=Object.values(g.players()).find(r=>r.n==='Aditya');g.M.x=a.x+30;g.M.y=a.y;});await B.waitForTimeout(1500);
 await A.evaluate(()=>{__g.joy.x=1;});await A.waitForTimeout(1500);await A.evaluate(()=>{__g.joy.x=0;});await B.waitForTimeout(800);
 await B.screenshot({path:D+'shots/m_B.png'});
 // lot claim oleh A
 await A.evaluate(()=>{const l=__g.LOTS.find(l=>!l.owner);__g.M.x=(l.x+3)*16+8;__g.M.y=(l.y+4)*16;});await A.waitForTimeout(500);
 await A.evaluate(()=>__g.interact());await A.waitForTimeout(300);await A.screenshot({path:D+'shots/m_dlg.png'});
 await A.click('#dc button:first-child');await A.waitForTimeout(2200);
 console.log('LOG lots A',await A.evaluate(()=>JSON.stringify(__g.lots())),'coins',await A.evaluate(()=>__g.M.coins));
 console.log('LOG lots B',await B.evaluate(()=>Object.keys(__g.lots()).length));
 await A.screenshot({path:D+'shots/m_house.png'});
 // panel baju
 await A.evaluate(()=>__g.clothesPanel());await A.waitForTimeout(300);await A.screenshot({path:D+'shots/m_cloth.png'});await A.click('#panel .no');
 await A.evaluate(()=>__g.dealerPanel());await A.waitForTimeout(300);await A.screenshot({path:D+'shots/m_dealer.png'});await A.click('#panel .no');
 await A.evaluate(()=>__g.quiz());await A.waitForTimeout(300);await A.screenshot({path:D+'shots/m_quiz.png'});
 await b.close();srv.kill();db.kill();
})().catch(e=>{console.log('FAIL',e.message);process.exit(1)});

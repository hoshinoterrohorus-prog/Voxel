module.exports=async p=>{const D='/tmp/claude-0/-home-claude/c0abfcb4-d4e7-5838-80b2-837f447da839/scratchpad/p20/';
 await p.fill('#nm','Aditya');await p.click('#bPlay');await p.waitForTimeout(900);
 await p.evaluate(()=>{__g.M.x=62*16;__g.M.y=20*16;});await p.waitForTimeout(1500);
 await p.evaluate(()=>{const g=__g;g.A.get('r:'+g.slot);});await p.screenshot({path:D+'shots/p1.png'});
 // park
 await p.evaluate(()=>{__g.M.x=(1*18+2+4)*16;__g.M.y=(6+1*16+2+7)*16;});await p.waitForTimeout(1500);await p.screenshot({path:D+'shots/p2.png'});
 // shrine
 await p.evaluate(()=>{__g.M.x=(3*18+2+7)*16;__g.M.y=(6+2*16+2+9)*16;});await p.waitForTimeout(1500);await p.screenshot({path:D+'shots/p3.png'});
 // school front
 await p.evaluate(()=>{__g.M.x=(4*18+2+7)*16+8;__g.M.y=(6+1*16+2+7)*16;});await p.waitForTimeout(1500);await p.screenshot({path:D+'shots/p4.png'});
};

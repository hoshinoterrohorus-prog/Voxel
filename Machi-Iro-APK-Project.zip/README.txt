Machi-Iro -> APK lewat GitHub Actions

1. Buat repo baru di GitHub (boleh private), upload SEMUA isi folder ini (termasuk folder .github).
2. Buka tab Actions -> workflow "Build APK" jalan otomatis (atau tekan Run workflow). Tunggu sekitar 5-8 menit.
3. Selesai -> klik run-nya -> bagian Artifacts -> unduh Machi-Iro-APK (zip) -> ekstrak -> app-debug.apk.
4. Pindah ke HP, instal (izinkan "sumber tak dikenal"). Game fullscreen, landscape.

Mau update game: ganti www/index.html, commit, APK baru dibuat otomatis.
Catatan: ini APK debug (bisa dipasang langsung, belum untuk Play Store).
